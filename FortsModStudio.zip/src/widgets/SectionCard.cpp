#include "SectionCard.h"

#include "ToggleSwitch.h"

#include <QGridLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QSignalBlocker>
#include <QVBoxLayout>

SectionCard::SectionCard(const QIcon &icon, const QString &title, QWidget *parent)
    : QWidget(parent)
{
    auto *outer = new QVBoxLayout(this);
    outer->setContentsMargins(0, 0, 0, 0);
    outer->setSpacing(14);

    auto *header = new QHBoxLayout();
    header->setContentsMargins(0, 0, 0, 0);
    header->setSpacing(10);

    auto *iconLabel = new QLabel(this);
    iconLabel->setPixmap(icon.pixmap(18, 18));
    iconLabel->setFixedSize(18, 18);
    header->addWidget(iconLabel, 0, Qt::AlignVCenter);

    m_titleLabel = new QLabel(title, this);
    m_titleLabel->setObjectName(QStringLiteral("SectionTitle"));
    header->addWidget(m_titleLabel, 0, Qt::AlignVCenter);
    header->addStretch(1);

    // Group switch: off = the whole table is absent from the file.
    m_toggle = new ToggleSwitch(this);
    m_toggle->setVisible(false);
    header->addWidget(m_toggle, 0, Qt::AlignVCenter);
    connect(m_toggle, &ToggleSwitch::toggled, this, &SectionCard::toggleChanged);

    outer->addLayout(header);

    m_grid = new QGridLayout();
    m_grid->setContentsMargins(0, 0, 0, 0);
    m_grid->setHorizontalSpacing(14);
    m_grid->setVerticalSpacing(10);
    m_grid->setColumnStretch(0, 1);
    m_grid->setColumnStretch(1, 1);
    outer->addLayout(m_grid);
}

void SectionCard::setToggleVisible(bool visible)
{
    m_toggle->setVisible(visible);
}

void SectionCard::setToggleChecked(bool on)
{
    if (m_toggle->isChecked() == on)
        return;
    QSignalBlocker blocker(m_toggle);
    m_toggle->setChecked(on);
}

bool SectionCard::isToggleVisible() const
{
    return m_toggle->isVisibleTo(const_cast<SectionCard *>(this));
}

void SectionCard::setToggleHint(const QString &text)
{
    m_toggle->setToolTip(text);
}

void SectionCard::setTitle(const QString &text)
{
    m_titleLabel->setText(text);
}
