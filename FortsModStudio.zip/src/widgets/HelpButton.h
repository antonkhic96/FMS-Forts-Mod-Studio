#pragma once

#include <QPushButton>

// Small round "?" button that explains what a parameter changes.
// It shows the text on hover (tooltip) and pins it next to the button on click.
// The button hides itself when no hint is set.
class HelpButton : public QPushButton
{
    Q_OBJECT

public:
    explicit HelpButton(QWidget *parent = nullptr);

    void setHint(const QString &text);
    QString hint() const { return m_hint; }

private:
    void showHint();

    QString m_hint;
};
