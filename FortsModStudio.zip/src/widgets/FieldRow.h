#pragma once

#include <QWidget>

class QFrame;
class QLabel;
class QComboBox;
class HelpButton;
class QHBoxLayout;
class QLineEdit;
class QPushButton;

// A labelled input with the unit shown inside the field on the right, e.g.
//   Урон  (?) 
//   [ 240              ед. ]
// The "?" button explains what the parameter changes.
class FieldRow : public QWidget
{
    Q_OBJECT

public:
    FieldRow(const QString &label, const QString &unit, QWidget *parent = nullptr);

    QString value() const;
    void setValue(const QString &v);

    // "number" restricts input to numeric text, "text" accepts anything.
    void setKind(const QString &kind) { m_kind = kind; }

    // Read-only fields show derived/script values that must not be edited.
    void setReadOnly(bool readOnly);

    bool isReadOnly() const { return m_readOnly; }

    // Marks the field as "not defined in the file yet" (muted, dashed border).
    void setUnset(bool unset);
    void setPlaceholder(const QString &text);

    // Description shown by the "?" button (hidden when empty).
    void setHint(const QString &text);

    // Turns the field into a pick-list (e.g. "Снаряд" -> existing projectiles).
    // With `editable` the value can also be typed by hand.
    void setChoices(const QStringList &choices, bool editable = false);

    // Shows a "Выбрать" button that asks for a file (see browseRequested).
    void setBrowseVisible(bool visible);

    // Shows a small "×" that deletes the parameter from the file.
    void setRemoveVisible(bool visible);

    // Allowed range for a numeric field. `max < 0` means "no upper limit".
    // Out-of-range input is rejected and the field reverts.
    void setRange(double min, double max, bool integer);

signals:
    void edited(const QString &value);
    // The "Выбрать" button was pressed; the panel opens the file dialog.
    void browseRequested();
    // The "×" was pressed: delete this parameter from the file.
    void removeRequested();

protected:
    bool eventFilter(QObject *obj, QEvent *event) override;

private:
    void commit();

    QLabel *m_label = nullptr;
    HelpButton *m_help = nullptr;
    QFrame *m_box = nullptr;
    QLineEdit *m_edit = nullptr;
    QComboBox *m_combo = nullptr;
    QPushButton *m_browse = nullptr;
    QPushButton *m_remove = nullptr;
    QHBoxLayout *m_boxLay = nullptr;
    QLabel *m_unit = nullptr;
    QString m_hint;
    QString m_kind = QStringLiteral("number");
    double m_min = 0;
    double m_max = -1;
    bool m_integer = false;
    bool m_hasRange = false;
    QString m_last;
    bool m_readOnly = false;
};
