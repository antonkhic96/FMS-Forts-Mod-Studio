#pragma once

#include <QAbstractItemView>
#include <QComboBox>
#include <QWheelEvent>

// A combo box that ignores the mouse wheel while its list is closed.
//
// Plain QComboBox changes the value as soon as the wheel rolls over it, so
// scrolling a long card with the pointer over a pick-list silently rewrites the
// setting. Here the wheel scrolls the page instead; the value only changes when
// the list is actually open, or by clicking / keyboard.
class WheelSafeComboBox : public QComboBox
{
    Q_OBJECT

public:
    explicit WheelSafeComboBox(QWidget *parent = nullptr)
        : QComboBox(parent)
    {
        // The list itself still scrolls normally.
        setFocusPolicy(Qt::StrongFocus);
    }

protected:
    void wheelEvent(QWheelEvent *e) override
    {
        if (!view() || !view()->isVisible()) {
            e->ignore();   // let the surrounding scroll area handle it
            return;
        }
        QComboBox::wheelEvent(e);
    }
};
