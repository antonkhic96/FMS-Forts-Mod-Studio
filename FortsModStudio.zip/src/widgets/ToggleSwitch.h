#pragma once

#include <QAbstractButton>

class QPropertyAnimation;

// A pill-shaped on/off switch with an animated knob (as in the design's
// "Включить перегрев" control).
class ToggleSwitch : public QAbstractButton
{
    Q_OBJECT
    Q_PROPERTY(qreal position READ position WRITE setPosition)

public:
    explicit ToggleSwitch(QWidget *parent = nullptr);

    QSize sizeHint() const override;
    QSize minimumSizeHint() const override { return sizeHint(); }

    qreal position() const { return m_position; }
    void setPosition(qreal p);

protected:
    void paintEvent(QPaintEvent *event) override;

private:
    qreal m_position = 0.0;
    QPropertyAnimation *m_anim = nullptr;
};
