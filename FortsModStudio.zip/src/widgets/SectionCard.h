#pragma once

#include <QIcon>
#include <QWidget>

class QGridLayout;
class ToggleSwitch;

// A titled group of fields inside the properties card, e.g. "Взрыв пушки".
//
// An optional switch can sit in the header: some Forts settings are whole
// tables (ReloadBank = { … }) that are either present or absent, so the group
// as a whole has to be switchable.
class SectionCard : public QWidget
{
    Q_OBJECT

public:
    SectionCard(const QIcon &icon, const QString &title, QWidget *parent = nullptr);

    QGridLayout *grid() const { return m_grid; }

    // Shows a switch on the right of the header. `on` is the current state;
    // the card does not act on it - the owner connects toggleChanged().
    void setToggleVisible(bool visible);
    void setToggleChecked(bool on);
    bool isToggleVisible() const;
    void setToggleHint(const QString &text);

    // Title text, e.g. when the group reflects a value ("Магазин (8)").
    void setTitle(const QString &text);

signals:
    void toggleChanged(bool on);

private:
    QGridLayout *m_grid = nullptr;
    class QLabel *m_titleLabel = nullptr;
    ToggleSwitch *m_toggle = nullptr;
};
