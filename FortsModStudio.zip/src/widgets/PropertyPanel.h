#pragma once

#include <QWidget>

class FieldRow;
class ModProject;
class QLabel;
class QPlainTextEdit;
class QPushButton;
class QScrollArea;
class QStackedWidget;
class QTimer;
class QVBoxLayout;
class ToggleSwitch;

// The centre column: breadcrumb, page title, tabs, and either the properties
// card or the raw Lua code editor.
class PropertyPanel : public QWidget
{
    Q_OBJECT

public:
    explicit PropertyPanel(QWidget *parent = nullptr);

    void setProject(ModProject *project);
    void showFile(const QString &relPath);

    // File currently shown in the properties card (empty when none).
    QString currentFile() const { return m_relPath; }

    // Deletes a parameter from the current file. The field stays visible as
    // "не задано" so a value can be typed to bring the setting back.
    bool removeParameter(const QString &path);
    void clearSelection();

signals:
    void fileChanged(const QString &relPath);

private:
    QWidget *buildCard(const QString &relPath, int *paramCountOut);
    QWidget *buildPlaceholder(const QString &title, const QString &message,
                              const QPixmap &pix = QPixmap());
    void rebuildCard();
    void addNewComponent(const QString &arrayName);

    // Turns a texture expression (`path .. "/weapons/x/base.png"`) into a real
    // file path, or an empty string.
    QString resolveAssetPath(const QString &expr) const;

    // Turns an absolute file path into a Forts expression:
    //   inside the mod       -> path .. "/weapons/x/base.png"
    //   inside the game data -> "weapons/cannon/base.dds"
    // Returns an empty string when the file is neither.
    QString toFortsExpression(const QString &absPath) const;

    // Opens a file dialog and writes the chosen file into a texture field.
    void browseForTexture(FieldRow *field, int line, const std::function<void()> &refresh);
    void showTab(int index);
    void updateTitleCount(int count);

    ModProject *m_project = nullptr;
    QString m_relPath;
    bool m_syncing = false;
    bool m_showUnset = true;
    QString m_array;       // selected component array (e.g. Weapons)
    QString m_component;   // selected entry of that array (e.g. Weapons[3])
    // Keys the user removed with "×" while this file is open. Their fields stay
    // visible as "не задано" so a value can be typed to bring the setting back.
    QSet<QString> m_removedKeys;
    ToggleSwitch *m_unsetToggle = nullptr;

    QLabel *m_breadcrumb = nullptr;
    QLabel *m_title = nullptr;
    QLabel *m_titleSup = nullptr;
    QWidget *m_tabBar = nullptr;
    QPushButton *m_tabProps = nullptr;
    QPushButton *m_tabCode = nullptr;
    QLabel *m_description = nullptr;
    QStackedWidget *m_stack = nullptr;
    QScrollArea *m_scroll = nullptr;
    QPlainTextEdit *m_code = nullptr;
    QTimer *m_codeTimer = nullptr;
    QLabel *m_footerIcon = nullptr;
    QLabel *m_footerText = nullptr;
    QPushButton *m_reset = nullptr;
};
