#pragma once

#include <QWidget>

// A plain container that behaves like a button: it shows a pointer cursor,
// reports hover state through a `hovered` property (so QSS can style it) and
// emits clicked() on a left-button release inside its bounds.
class ClickableWidget : public QWidget
{
    Q_OBJECT

public:
    explicit ClickableWidget(QWidget *parent = nullptr);

signals:
    void clicked();

protected:
    void mouseReleaseEvent(QMouseEvent *event) override;
    void enterEvent(QEnterEvent *event) override;
    void leaveEvent(QEvent *event) override;

private:
    void setHovered(bool on);
};
