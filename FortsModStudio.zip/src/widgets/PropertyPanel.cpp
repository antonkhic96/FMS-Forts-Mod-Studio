#include "PropertyPanel.h"

#include "../GameCatalog.h"
#include "../Icons.h"
#include "../LuaFile.h"
#include "../ModModel.h"
#include "../ParamCatalog.h"
#include "../Theme.h"
#include "FieldRow.h"
#include "HelpButton.h"
#include "WheelSafeComboBox.h"
#include "SectionCard.h"
#include "ToggleSwitch.h"

#include <QComboBox>
#include <QDir>
#include <QFileDialog>
#include <QFileInfo>
#include <QFontMetricsF>
#include <QFrame>
#include <QGridLayout>
#include <QHash>
#include <QHBoxLayout>
#include <QMap>
#include <QLabel>
#include <QMessageBox>
#include <QListWidget>
#include <QPlainTextEdit>
#include <QPushButton>
#include <QRegularExpression>
#include <QScrollArea>
#include <QScrollBar>
#include <QSet>
#include <QSettings>
#include <QStackedWidget>
#include <QStyle>
#include <QTimer>
#include <QVBoxLayout>

#include <algorithm>

namespace {

constexpr int kPageMargin = 24;

QFrame *hline(QWidget *parent)
{
    auto *f = new QFrame(parent);
    f->setFixedHeight(1);
    f->setStyleSheet(QStringLiteral("background:#2b3237;"));
    return f;
}

void setTabActive(QPushButton *b, bool on)
{
    b->setProperty("active", on);
    b->style()->unpolish(b);
    b->style()->polish(b);
}

bool isLuaPath(const QString &relPath)
{
    return QFileInfo(relPath).suffix().compare(QLatin1String("lua"), Qt::CaseInsensitive) == 0;
}

bool isImagePath(const QString &relPath)
{
    const QString ext = QFileInfo(relPath).suffix().toLower();
    return ext == QLatin1String("png") || ext == QLatin1String("jpg") || ext == QLatin1String("jpeg");
}

QIcon iconForGroup(const QString &id)
{
    if (id == QLatin1String("overheat"))
        return Icons::thermometer(19);
    if (id == QLatin1String("damage") || id == QLatin1String("firing")
        || id == QLatin1String("projectile"))
        return Icons::target(19);
    return Icons::gear(19);
}

// One rendered row of the properties card. `unset` marks a parameter that the
// file does not define yet (offered from the component template).
struct Entry {
    const LuaProp *prop = nullptr;
    QString key;
    QString path;
    QString table;     // owning table (set for template-only entries)
    QString defValue;  // template default (template-only entries)
    LuaKind kind = LuaKind::Expression;
    bool unset = false;
};

// One rendered section of the properties card.
struct Group {
    QString id;
    QString title;
    int order = 0;
    QVector<Entry> entries;
    // Set when this group is an optional nested table (ReloadBank): the header
    // gets a switch that adds / deletes the whole block.
    QString toggleTable;      // "" when the group is not switchable
    bool tablePresent = false; // whether the table exists in the file
};

// Display name of one entry of a component array: its SaveName when present.
QString componentLabel(const LuaFile &lf, const QString &table)
{
    for (const LuaProp &p : lf.properties()) {
        if (p.table == table && p.key == QLatin1String("SaveName"))
            return p.value;
    }
    static const QRegularExpression re(QStringLiteral(R"(\[(\d+)\]$)"));
    const QRegularExpressionMatch m = re.match(table);
    return m.hasMatch() ? QStringLiteral("Элемент %1").arg(m.captured(1)) : table;
}

// Kind of a template default value.
LuaKind kindOfDefault(const QString &v)
{
    if (v == QLatin1String("true") || v == QLatin1String("false"))
        return LuaKind::Bool;
    if (v.startsWith(QLatin1Char('"')))
        return LuaKind::String;
    if (v.startsWith(QLatin1Char('{')))
        return LuaKind::List;
    static const QRegularExpression numRe(QStringLiteral(R"(-?\d+(\.\d+)?)"));
    if (numRe.match(v).hasMatch())
        return LuaKind::Number;
    return LuaKind::Expression;
}

} // namespace

PropertyPanel::PropertyPanel(QWidget *parent)
    : QWidget(parent)
{
    setObjectName(QStringLiteral("Content"));
    setAttribute(Qt::WA_StyledBackground, true);

    m_showUnset = QSettings().value(QStringLiteral("showUnset"), true).toBool();

    auto *root = new QVBoxLayout(this);
    root->setContentsMargins(kPageMargin, 22, kPageMargin, 0);
    root->setSpacing(0);

    m_breadcrumb = new QLabel(this);
    m_breadcrumb->setObjectName(QStringLiteral("Breadcrumb"));
    root->addWidget(m_breadcrumb);
    root->addSpacing(8);

    auto *titleRow = new QHBoxLayout();
    titleRow->setContentsMargins(0, 0, 0, 0);
    titleRow->setSpacing(8);
    m_title = new QLabel(QStringLiteral("Свойства"), this);
    m_title->setObjectName(QStringLiteral("PageTitle"));
    m_titleSup = new QLabel(this);
    m_titleSup->setObjectName(QStringLiteral("PageTitleSup"));
    titleRow->addWidget(m_title, 0, Qt::AlignBottom);
    titleRow->addWidget(m_titleSup, 0, Qt::AlignBottom);
    titleRow->addStretch(1);
    root->addLayout(titleRow);
    root->addSpacing(14);

    // Centred segmented tab control.
    m_tabBar = new QWidget(this);
    auto *barLay = new QHBoxLayout(m_tabBar);
    barLay->setContentsMargins(0, 0, 0, 0);
    barLay->setSpacing(0);
    barLay->addStretch(1);

    auto *seg = new QWidget(m_tabBar);
    seg->setObjectName(QStringLiteral("TabSeg"));
    auto *segLay = new QHBoxLayout(seg);
    segLay->setContentsMargins(3, 3, 3, 3);
    segLay->setSpacing(2);

    m_tabProps = new QPushButton(QStringLiteral("Свойства"), seg);
    m_tabProps->setObjectName(QStringLiteral("Tab"));
    m_tabProps->setCursor(Qt::PointingHandCursor);
    m_tabCode = new QPushButton(QStringLiteral("Редактор кода"), seg);
    m_tabCode->setObjectName(QStringLiteral("Tab"));
    m_tabCode->setCursor(Qt::PointingHandCursor);
    segLay->addWidget(m_tabProps);
    segLay->addWidget(m_tabCode);

    barLay->addWidget(seg);
    barLay->addStretch(1);
    root->addWidget(m_tabBar);
    root->addSpacing(16);

    m_description = new QLabel(this);
    m_description->setObjectName(QStringLiteral("Description"));
    m_description->setWordWrap(true);
    root->addWidget(m_description);
    root->addSpacing(12);

    // Toggle: also list the settings the file does not define yet.
    auto *unsetRow = new QHBoxLayout();
    unsetRow->setContentsMargins(0, 0, 0, 0);
    unsetRow->setSpacing(10);
    auto *unsetLabel = new QLabel(
        QStringLiteral("Показывать параметры, которых нет в файле"), this);
    unsetLabel->setObjectName(QStringLiteral("UnsetToggleLabel"));
    unsetRow->addWidget(unsetLabel, 0, Qt::AlignVCenter);
    m_unsetToggle = new ToggleSwitch(this);
    m_unsetToggle->setChecked(m_showUnset);
    unsetRow->addWidget(m_unsetToggle, 0, Qt::AlignVCenter);
    unsetRow->addStretch(1);
    root->addLayout(unsetRow);
    root->addSpacing(16);

    m_stack = new QStackedWidget(this);
    root->addWidget(m_stack, 1);

    // ---- page 0: properties -------------------------------------------------
    auto *propsPage = new QWidget(this);
    auto *propsLay = new QVBoxLayout(propsPage);
    propsLay->setContentsMargins(0, 0, 0, 0);
    propsLay->setSpacing(0);

    m_scroll = new QScrollArea(propsPage);
    m_scroll->setWidgetResizable(true);
    m_scroll->setFrameShape(QFrame::NoFrame);
    m_scroll->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    m_scroll->viewport()->setAutoFillBackground(false);
    propsLay->addWidget(m_scroll, 1);

    auto *footer = new QWidget(propsPage);
    footer->setObjectName(QStringLiteral("FooterBar"));
    auto *footerLay = new QHBoxLayout(footer);
    footerLay->setContentsMargins(0, 14, 0, 14);
    footerLay->setSpacing(9);
    m_footerIcon = new QLabel(footer);
    m_footerIcon->setFixedSize(16, 16);
    m_footerText = new QLabel(footer);
    m_footerText->setObjectName(QStringLiteral("FooterOk"));
    footerLay->addWidget(m_footerIcon, 0, Qt::AlignVCenter);
    footerLay->addWidget(m_footerText, 0, Qt::AlignVCenter);
    footerLay->addStretch(1);
    m_reset = new QPushButton(QStringLiteral("Сбросить"), footer);
    m_reset->setObjectName(QStringLiteral("Link"));
    m_reset->setCursor(Qt::PointingHandCursor);
    footerLay->addWidget(m_reset, 0, Qt::AlignVCenter);
    propsLay->addWidget(footer, 0);

    m_stack->addWidget(propsPage);

    // ---- page 1: code editor ------------------------------------------------
    auto *codePage = new QWidget(this);
    auto *codeLay = new QVBoxLayout(codePage);
    codeLay->setContentsMargins(0, 0, 0, 16);
    codeLay->setSpacing(0);

    m_code = new QPlainTextEdit(codePage);
    QFont mono(QStringLiteral("Cascadia Mono"));
    mono.setStyleHint(QFont::Monospace);
    mono.setPointSize(10);
    m_code->setFont(mono);
    m_code->setFrameShape(QFrame::NoFrame);
    m_code->setTabStopDistance(4 * QFontMetricsF(mono).horizontalAdvance(QLatin1Char(' ')));
    m_code->setStyleSheet(QStringLiteral(
        "QPlainTextEdit{background:#111517;color:#cfd6da;border:1px solid #2b3237;"
        "border-radius:9px;padding:14px;selection-background-color:#496557;}"));
    codeLay->addWidget(m_code);
    m_stack->addWidget(codePage);

    m_codeTimer = new QTimer(this);
    m_codeTimer->setSingleShot(true);
    m_codeTimer->setInterval(500);

    connect(m_tabProps, &QPushButton::clicked, this, [this] { showTab(0); });
    connect(m_tabCode, &QPushButton::clicked, this, [this] { showTab(1); });
    connect(m_code, &QPlainTextEdit::textChanged, this, [this] {
        if (!m_syncing && m_code->hasFocus())
            m_codeTimer->start();
    });
    connect(m_codeTimer, &QTimer::timeout, this, [this] {
        if (!m_project || m_relPath.isEmpty() || m_syncing)
            return;
        LuaFile &f = m_project->file(m_relPath);
        const QString text = m_code->toPlainText();
        if (text == f.rawText())
            return;
        f.setRawText(text);
        m_project->markDirty(m_relPath);
        emit fileChanged(m_relPath);
        rebuildCard();
    });
    connect(m_reset, &QPushButton::clicked, this, [this] {
        if (!m_project || m_relPath.isEmpty())
            return;
        LuaFile &f = m_project->file(m_relPath);

        // Reloading throws away in-memory edits, so ask first.
        if (f.isModified()) {
            const auto answer = QMessageBox::question(
                this, QStringLiteral("Сбросить файл"),
                QStringLiteral("Вернуть «%1» к состоянию на диске?\n\n"
                               "Несохранённые правки этого файла будут потеряны. "
                               "Отменить это действие нельзя.")
                    .arg(ModProject::displayNameForFile(m_relPath)),
                QMessageBox::Yes | QMessageBox::No, QMessageBox::No);
            if (answer != QMessageBox::Yes)
                return;
        }

        f.reload();
        emit fileChanged(m_relPath);
        showFile(m_relPath);
    });
    connect(m_unsetToggle, &ToggleSwitch::toggled, this, [this](bool on) {
        m_showUnset = on;
        QSettings().setValue(QStringLiteral("showUnset"), on);
        rebuildCard();
    });

    showTab(0);
    clearSelection();
}

void PropertyPanel::setProject(ModProject *project)
{
    m_project = project;
}

void PropertyPanel::updateTitleCount(int count)
{
    m_titleSup->setText(count > 0
                            ? QStringLiteral("%1").arg(count, 2, 10, QLatin1Char('0'))
                            : QString());
}

void PropertyPanel::showTab(int index)
{
    m_stack->setCurrentIndex(index);
    setTabActive(m_tabProps, index == 0);
    setTabActive(m_tabCode, index == 1);

    if (index == 1 && m_project && !m_relPath.isEmpty()) {
        m_syncing = true;
        m_code->setPlainText(m_project->file(m_relPath).rawText());
        m_syncing = false;
    }
}

void PropertyPanel::rebuildCard()
{
    if (!m_project || m_relPath.isEmpty() || !isLuaPath(m_relPath))
        return;

    // Replacing the scroll area's widget resets the scroll position, which makes
    // the card jump to the top after every edit (and hides the field that was
    // just changed). Remember where the user was and put it back.
    QScrollBar *bar = m_scroll->verticalScrollBar();
    const int scroll = bar->value();

    int count = 0;
    QWidget *card = buildCard(m_relPath, &count);
    m_scroll->setWidget(card);
    updateTitleCount(count);

    bar->setValue(qMin(scroll, bar->maximum()));
    // The new layout is measured on the next event-loop pass.
    QTimer::singleShot(0, this, [this, scroll] {
        QScrollBar *b = m_scroll->verticalScrollBar();
        b->setValue(qMin(scroll, b->maximum()));
    });
}

QString PropertyPanel::resolveAssetPath(const QString &expr) const
{
    if (!m_project)
        return QString();

    QString s = expr.trimmed();
    const int q1 = s.indexOf(QLatin1Char('"'));
    if (q1 < 0)
        return QString();
    const int q2 = s.indexOf(QLatin1Char('"'), q1 + 1);
    if (q2 <= q1)
        return QString();

    // Only files inside the mod are considered: a texture must live in the mod.
    QString rel = s.mid(q1 + 1, q2 - q1 - 1);
    if (!rel.startsWith(QLatin1Char('/')))
        rel.prepend(QLatin1Char('/'));
    return m_project->rootPath() + rel;
}

QString PropertyPanel::toFortsExpression(const QString &absPath) const
{
    if (!m_project || absPath.isEmpty())
        return QString();

    // Only files inside the mod are allowed: the path is written as
    // .
    const QString file = QDir::cleanPath(QFileInfo(absPath).absoluteFilePath());
    const QString modRoot = QDir(m_project->rootPath()).absolutePath();
    if (!file.startsWith(modRoot + QLatin1Char('/'), Qt::CaseInsensitive))
        return QString();

    return QStringLiteral("path .. \"/%1\"").arg(file.mid(modRoot.size() + 1));
}

bool PropertyPanel::removeParameter(const QString &path)
{
    if (!m_project || m_relPath.isEmpty() || path.isEmpty())
        return false;

    LuaFile &f = m_project->file(m_relPath);
    if (!f.removeProperty(path))
        return false;

    // Remember the key: its field must stay reachable so the setting can be
    // restored by typing a value again.
    m_removedKeys.insert(path.section(QLatin1Char('.'), -1));
    m_project->markDirty(m_relPath);
    emit fileChanged(m_relPath);
    rebuildCard();
    return true;
}

void PropertyPanel::browseForTexture(FieldRow *field, int line,
                                     const std::function<void()> &refresh)
{
    if (!field || !m_project)
        return;

    // Always start inside the mod: only mod files may be referenced.
    const QString modRoot = QDir(m_project->rootPath()).absolutePath();
    QString start = resolveAssetPath(field->value());
    if (!start.isEmpty())
        start = QFileInfo(start).absolutePath();
    if (start.isEmpty() || !QDir(start).exists()
        || !QDir::cleanPath(start).startsWith(modRoot, Qt::CaseInsensitive)) {
        start = modRoot;
    }

    const QString file = QFileDialog::getOpenFileName(
        this, QStringLiteral("Выбрать текстуру"), start,
        QStringLiteral("Изображения (*.png *.dds *.tga *.jpg *.jpeg);;Все файлы (*)"));
    if (file.isEmpty())
        return;

    const QString expr = toFortsExpression(file);
    if (expr.isEmpty()) {
        QMessageBox::warning(
            this, QStringLiteral("Выбрать текстуру"),
            QStringLiteral("Картинка должна лежать внутри мода.\n\n"
                           "Выбрано:\n%1\n\nПапка мода:\n%2\n\n"
                           "Скопируйте файл в мод и выберите его снова.")
                .arg(file, modRoot));
        return;
    }

    field->setValue(expr);
    LuaFile &f = m_project->file(m_relPath);
    if (f.setTexture(line, expr)) {
        m_project->markDirty(m_relPath);
        emit fileChanged(m_relPath);
        if (refresh)
            refresh();
    }
}

void PropertyPanel::addNewComponent(const QString &arrayName)
{
    if (!m_project || m_relPath.isEmpty() || arrayName.isEmpty())
        return;

    LuaFile &f = m_project->file(m_relPath);

    // Pick a free internal name like new_projectile / new_projectile2.
    QString stem = arrayName.toLower();
    if (stem.endsWith(QLatin1Char('s')))
        stem.chop(1);
    QSet<QString> taken;
    for (const LuaProp &p : f.properties()) {
        if (p.key == QLatin1String("SaveName"))
            taken.insert(p.value);
    }
    QString name = QStringLiteral("new_%1").arg(stem);
    for (int n = 2; taken.contains(name); ++n)
        name = QStringLiteral("new_%1%2").arg(stem).arg(n);

    QVector<QPair<QString, QString>> props;
    props.append(qMakePair(QStringLiteral("SaveName"), QStringLiteral("\"%1\"").arg(name)));
    const QVector<ParamCatalog::TemplateParam> &tmpl =
        ParamCatalog::templateForFile(m_relPath, arrayName);
    for (const ParamCatalog::TemplateParam &t : tmpl) {
        if (t.key == QLatin1String("SaveName"))
            continue;
        props.append(qMakePair(t.key, t.value));
    }

    const QString created = f.addComponent(arrayName, props);
    if (created.isEmpty())
        return;

    m_component = created;
    m_project->markDirty(m_relPath);
    emit fileChanged(m_relPath);
    rebuildCard();
}

void PropertyPanel::showFile(const QString &relPath)
{
    if (relPath != m_relPath)
        m_removedKeys.clear();
    m_relPath = relPath;

    if (!m_project || !m_project->isOpen() || relPath.isEmpty()) {
        clearSelection();
        return;
    }

    const QFileInfo fi(relPath);
    const QString folder = fi.path() == QLatin1String(".") ? QString() : fi.path().section(QLatin1Char('/'), 0, 0);
    const QString category = folder.isEmpty() ? QStringLiteral("Корень")
                                              : ModProject::categoryForFolder(folder);

    m_breadcrumb->setText(
        QStringLiteral("<span style='color:#c6cdd1'>%1</span>&nbsp;&nbsp;›&nbsp;&nbsp;%2")
            .arg(m_project->name().toHtmlEscaped(), category.toHtmlEscaped()));

    const bool lua = isLuaPath(relPath);
    m_tabBar->setVisible(true);
    m_tabCode->setEnabled(lua);
    m_description->setVisible(true);

    if (lua) {
        m_description->setText(QStringLiteral(
            "Параметры выбранного компонента сгруппированы в разделы и доступны для редактирования."));
        int count = 0;
        m_scroll->setWidget(buildCard(relPath, &count));
        updateTitleCount(count);
        m_footerIcon->setPixmap(Icons::check(16).pixmap(16, 16));
        m_footerText->setText(QStringLiteral("Применено к проекту"));
        m_footerIcon->parentWidget()->setVisible(true);
        showTab(0);
    } else {
        m_description->setText(QStringLiteral("Для этого типа файлов нет редактора свойств."));
        QPixmap pix;
        if (isImagePath(relPath))
            pix.load(m_project->rootPath() + QLatin1Char('/') + relPath);
        m_scroll->setWidget(buildPlaceholder(ModProject::displayNameForFile(relPath),
                                             QStringLiteral("%1 · %2").arg(
                                                 ModProject::typeLabelFor(relPath),
                                                 ModProject::humanSize(fi.size())),
                                             pix));
        updateTitleCount(0);
        m_footerIcon->parentWidget()->setVisible(false);
        showTab(0);
    }
}

void PropertyPanel::clearSelection()
{
    m_relPath.clear();
    m_breadcrumb->clear();
    m_tabBar->setVisible(false);
    m_description->setText(QStringLiteral(
        "Выберите файл в дереве слева, чтобы отредактировать его параметры без кода."));
    m_scroll->setWidget(buildPlaceholder(QStringLiteral("Файл не выбран"),
                                         QStringLiteral("Откройте компонент в директории мода.")));
    updateTitleCount(0);
    if (m_footerIcon->parentWidget())
        m_footerIcon->parentWidget()->setVisible(false);
    showTab(0);
}

QWidget *PropertyPanel::buildPlaceholder(const QString &title, const QString &message, const QPixmap &pix)
{
    auto *card = new QFrame;
    card->setObjectName(QStringLiteral("Card"));
    auto *lay = new QVBoxLayout(card);
    lay->setContentsMargins(40, 80, 40, 80);
    lay->setSpacing(12);
    lay->setAlignment(Qt::AlignCenter);

    if (!pix.isNull()) {
        auto *img = new QLabel(card);
        img->setPixmap(pix.scaled(360, 220, Qt::KeepAspectRatio, Qt::SmoothTransformation));
        img->setAlignment(Qt::AlignCenter);
        lay->addWidget(img, 0, Qt::AlignCenter);
    }

    auto *t = new QLabel(title, card);
    t->setObjectName(QStringLiteral("CardTitle"));
    t->setAlignment(Qt::AlignCenter);
    lay->addWidget(t);

    auto *m = new QLabel(message, card);
    m->setObjectName(QStringLiteral("CardSubtitle"));
    m->setAlignment(Qt::AlignCenter);
    m->setWordWrap(true);
    lay->addWidget(m);

    return card;
}

QWidget *PropertyPanel::buildCard(const QString &relPath, int *paramCountOut)
{
    LuaFile &lf = m_project->file(relPath);
    const QFileInfo fi(relPath);
    const QString folder = fi.path() == QLatin1String(".") ? QString() : fi.path().section(QLatin1Char('/'), 0, 0);

    // ---- component arrays (projectile_list.lua, weapon_list.lua, …) --------
    QMap<QString, QStringList> arrays;
    {
        static const QRegularExpression arrRe(
            QStringLiteral(R"(^([A-Za-z_][A-Za-z0-9_]*)\[(\d+)\]$)"));
        for (const LuaProp &p : lf.properties()) {
            const QRegularExpressionMatch m = arrRe.match(p.table);
            if (!m.hasMatch())
                continue;
            QStringList &list = arrays[m.captured(1)];
            if (!list.contains(p.table))
                list << p.table;
        }
    }

    // Pick which array to edit: the remembered one, otherwise the biggest.
    QString activeArray;
    QStringList components;
    if (arrays.isEmpty()) {
        // A list file with no entries yet (fresh mod): still offer the picker
        // and the "Добавить" button, otherwise there is no way to start.
        activeArray = ParamCatalog::expectedArrayFor(relPath);
    } else {
        if (!arrays.contains(m_array)) {
            int bestCount = -1;
            for (auto it = arrays.constBegin(); it != arrays.constEnd(); ++it) {
                if (it.value().size() > bestCount) {
                    bestCount = it.value().size();
                    m_array = it.key();
                }
            }
        }
        activeArray = m_array;
        components = arrays.value(activeArray);
    }
    if (!arrays.contains(activeArray))
        m_array.clear();

    QString activeComponent;
    if (!activeArray.isEmpty()) {
        if (!components.contains(m_component))
            m_component = components.value(0);
        activeComponent = m_component;
    } else {
        m_component.clear();
    }

    const ParamCatalog::Kind kind = ParamCatalog::kindFor(relPath, activeArray);

    const auto inComponent = [&](const LuaProp &p) {
        // No list in this file: everything at the top level is shown.
        if (activeComponent.isEmpty())
            return true;
        // Inside a list: only the selected entry, plus file-level constants.
        if (p.table.isEmpty())
            return ParamCatalog::isConstantName(p.key);
        return p.table == activeComponent
               || p.table.startsWith(activeComponent + QLatin1Char('.'));
    };

    // ---- group the properties -------------------------------------------------
    QVector<Group> groups;
    QHash<QString, int> groupIndex;
    int tableOrder = 100;
    int count = 0;

    const auto groupFor = [&](const QString &id, const QString &title, int order) -> int {
        const auto it = groupIndex.constFind(id);
        if (it != groupIndex.constEnd())
            return it.value();
        Group g;
        g.id = id;
        g.title = title;
        g.order = order;
        groups.push_back(g);
        groupIndex.insert(id, groups.size() - 1);
        return groups.size() - 1;
    };

    for (const LuaProp &p : lf.properties()) {
        if (ParamCatalog::isTechnicalKey(p.key))
            continue;
        // "@name" tables are helper locals that were never added to a list,
        // "[n]" tables come from anonymous blocks inside helper functions.
        if (p.table.startsWith(QLatin1Char('@')) || p.table.startsWith(QLatin1Char('[')))
            continue;
        if (!inComponent(p))
            continue;

        // Inside a component the entry itself acts as the root.
        QString table = p.table;
        if (!activeComponent.isEmpty() && table.startsWith(activeComponent)) {
            table = table.mid(activeComponent.size());
            if (table.startsWith(QLatin1Char('.')))
                table = table.mid(1);
        }

        int gi = -1;
        if (table.isEmpty()) {
            const QString cat = ParamCatalog::categoryFor(kind, p.key);
            gi = groupFor(cat, ParamCatalog::categoryTitle(cat), ParamCatalog::categoryOrder(cat));
        } else {
            const QString last = table.section(QLatin1Char('.'), -1);
            gi = groupFor(QStringLiteral("t:") + table, ParamCatalog::tableTitle(last), tableOrder++);
            if (ParamCatalog::isToggleableTable(last)) {
                groups[gi].toggleTable = last;
                groups[gi].tablePresent = true;
            }
        }

        Entry e;
        e.prop = &p;
        e.key = p.key;
        e.path = p.path;
        e.kind = p.kind;
        e.table = table;   // relative to the active component, "" at top level
        groups[gi].entries.push_back(e);
        ++count;
    }

    // ---- offer the settings the file does not define yet ---------------------
    // Removed keys are always offered back, even when unset fields are hidden:
    // deleting a line must not make the setting unreachable.
    if (m_showUnset || !m_removedKeys.isEmpty()) {
        const QVector<ParamCatalog::TemplateParam> &tmpl =
            ParamCatalog::templateForFile(relPath, activeArray);
        for (const ParamCatalog::TemplateParam &t : tmpl) {
            if (ParamCatalog::isTechnicalKey(t.key))
                continue;

            // An optional nested table (ReloadBank): offer it as a switchable
            // group even when the file has no such block.
            if (ParamCatalog::isToggleableTable(t.key)) {
                if (lf.hasTable(t.key))
                    continue;   // already rendered above
                const int gi = groupFor(QStringLiteral("t:") + t.key,
                                        ParamCatalog::tableTitle(t.key), tableOrder++);
                groups[gi].toggleTable = t.key;
                groups[gi].tablePresent = false;
                // Ghost rows so the user sees what the block contains.
                for (const QPair<QString, QString> &d : ParamCatalog::tableTemplate(t.key)) {
                    Entry e;
                    e.key = d.first;
                    e.path = activeComponent.isEmpty()
                                 ? t.key + QLatin1Char('.') + d.first
                                 : activeComponent + QLatin1Char('.') + t.key
                                       + QLatin1Char('.') + d.first;
                    e.kind = kindOfDefault(d.second);
                    e.unset = true;
                    e.defValue = d.second;
                    e.table = activeComponent.isEmpty()
                                  ? t.key
                                  : activeComponent + QLatin1Char('.') + t.key;
                    groups[gi].entries.push_back(e);
                    ++count;
                }
                continue;
            }

            bool present = false;
            for (const LuaProp &p : lf.properties()) {
                if (inComponent(p) && p.key == t.key) {
                    present = true;
                    break;
                }
            }
            if (present)
                continue;
            if (!m_showUnset && !m_removedKeys.contains(t.key))
                continue;

            const QString cat = ParamCatalog::categoryFor(kind, t.key);
            const int gi = groupFor(cat, ParamCatalog::categoryTitle(cat),
                                    ParamCatalog::categoryOrder(cat));
            Entry e;
            e.key = t.key;
            e.path = activeComponent.isEmpty()
                         ? t.key
                         : activeComponent + QLatin1Char('.') + t.key;
            e.kind = kindOfDefault(t.value);
            e.unset = true;
            e.table = activeComponent;
            e.defValue = t.value;
            groups[gi].entries.push_back(e);
            ++count;
        }
    }

    if (paramCountOut)
        *paramCountOut = count;

    // ---- card ----------------------------------------------------------------
    auto *card = new QWidget;
    card->setObjectName(QStringLiteral("Card"));
    auto *cardLay = new QVBoxLayout(card);
    cardLay->setContentsMargins(0, 0, 0, 0);
    cardLay->setSpacing(0);

    auto *header = new QWidget(card);
    auto *hLay = new QHBoxLayout(header);
    hLay->setContentsMargins(0, 0, 0, 0);
    hLay->setSpacing(16);

    auto *iconBox = new QLabel(header);
    iconBox->setObjectName(QStringLiteral("IconBox"));
    iconBox->setFixedSize(42, 42);
    iconBox->setAlignment(Qt::AlignCenter);
    iconBox->setPixmap(Icons::target(22).pixmap(22, 22));
    hLay->addWidget(iconBox, 0, Qt::AlignVCenter);

    auto *titleCol = new QVBoxLayout();
    titleCol->setContentsMargins(0, 0, 0, 0);
    titleCol->setSpacing(2);
    auto *cardTitle = new QLabel(ModProject::displayNameForFile(relPath), header);
    cardTitle->setObjectName(QStringLiteral("CardTitle"));
    auto *cardSub = new QLabel(QStringLiteral("%1 / %2").arg(folder, fi.fileName()), header);
    cardSub->setObjectName(QStringLiteral("CardSubtitle"));
    titleCol->addWidget(cardTitle);
    titleCol->addWidget(cardSub);
    hLay->addLayout(titleCol);
    hLay->addStretch(1);

    const bool overrides = m_project->overridesBaseFile(relPath);
    auto *badge = new QLabel(overrides ? QStringLiteral("Изменён") : QStringLiteral("Новый"), header);
    badge->setObjectName(QStringLiteral("BadgeGreen"));
    hLay->addWidget(badge, 0, Qt::AlignVCenter);

    cardLay->addWidget(header);

    if (!activeArray.isEmpty()) {
        auto *panel = new QWidget(card);
        auto *pl = new QVBoxLayout(panel);
        pl->setContentsMargins(0, 0, 0, 0);
        pl->setSpacing(10);

        auto *head = new QHBoxLayout();
        head->setContentsMargins(0, 0, 0, 0);
        head->setSpacing(10);

        if (arrays.size() > 1) {
            auto *arrCombo = new WheelSafeComboBox(panel);
            arrCombo->setObjectName(QStringLiteral("ComponentPick"));
            arrCombo->setCursor(Qt::PointingHandCursor);
            for (auto it = arrays.constBegin(); it != arrays.constEnd(); ++it) {
                arrCombo->addItem(QStringLiteral("%1 (%2)")
                                      .arg(ParamCatalog::label(it.key()))
                                      .arg(it.value().size()),
                                  it.key());
            }
            arrCombo->setCurrentIndex(arrCombo->findData(activeArray));
            connect(arrCombo, QOverload<int>::of(&QComboBox::currentIndexChanged), this,
                    [this, arrCombo](int idx) {
                        const QString name = arrCombo->itemData(idx).toString();
                        if (name.isEmpty() || name == m_array)
                            return;
                        m_array = name;
                        m_component.clear();
                        QTimer::singleShot(0, this, [this] { rebuildCard(); });
                    });
            head->addWidget(arrCombo, 0, Qt::AlignVCenter);
        }

        auto *lbl = new QLabel(
            QStringLiteral("%1 · %2").arg(ParamCatalog::label(activeArray)).arg(components.size()),
            panel);
        lbl->setObjectName(QStringLiteral("FieldLabel"));
        head->addWidget(lbl, 0, Qt::AlignVCenter);
        head->addStretch(1);

        auto *addBtn = new QPushButton(QStringLiteral("  Добавить"), panel);
        addBtn->setObjectName(QStringLiteral("Ghost"));
        addBtn->setIcon(Icons::plus(16));
        addBtn->setIconSize(QSize(16, 16));
        addBtn->setCursor(Qt::PointingHandCursor);
        addBtn->setToolTip(QStringLiteral("Создать новый элемент списка"));
        connect(addBtn, &QPushButton::clicked, this, [this, activeArray] {
            addNewComponent(activeArray);
        });
        head->addWidget(addBtn, 0, Qt::AlignVCenter);
        pl->addLayout(head);

        if (components.isEmpty()) {
            auto *hint = new QLabel(
                QStringLiteral("Список пуст — нажмите «Добавить», чтобы создать первый элемент."),
                panel);
            hint->setObjectName(QStringLiteral("Unit"));
            hint->setWordWrap(true);
            pl->addWidget(hint);
        }

        auto *list = new QListWidget(panel);
        list->setObjectName(QStringLiteral("ComponentList"));
        list->setUniformItemSizes(true);
        list->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        list->setFixedHeight(qMin(components.size(), 6) * 30 + 10);
        for (const QString &comp : components) {
            auto *item = new QListWidgetItem(componentLabel(lf, comp), list);
            item->setData(Qt::UserRole, comp);
        }
        list->setCurrentRow(components.indexOf(activeComponent));
        connect(list, &QListWidget::currentItemChanged, this,
                [this](QListWidgetItem *cur, QListWidgetItem *) {
                    if (!cur)
                        return;
                    const QString comp = cur->data(Qt::UserRole).toString();
                    if (comp.isEmpty() || comp == m_component)
                        return;
                    m_component = comp;
                    QTimer::singleShot(0, this, [this] { rebuildCard(); });
                });
        pl->addWidget(list);

        cardLay->addWidget(panel);
        cardLay->addSpacing(26);
    } else {
        cardLay->addSpacing(20);
    }

    // ---- script warning -------------------------------------------------------
    if (lf.looksLikeScript()) {
        auto *warn = new QWidget(card);
        warn->setObjectName(QStringLiteral("WarnBox"));
        auto *wl = new QHBoxLayout(warn);
        wl->setContentsMargins(13, 11, 13, 11);
        wl->setSpacing(11);
        auto *wi = new QLabel(warn);
        wi->setFixedSize(16, 16);
        wi->setPixmap(Icons::info(16).pixmap(16, 16));
        wl->addWidget(wi, 0, Qt::AlignTop);
        auto *wt = new QLabel(
            QStringLiteral("Это скрипт-файл: часть значений вычисляется в коде. "
                           "Такие поля показаны только для чтения."), warn);
        wt->setWordWrap(true);
        wl->addWidget(wt, 1);
        cardLay->addWidget(warn);
        cardLay->addSpacing(22);
    }

    // ---- sections -------------------------------------------------------------
    bool first = true;
    for (const Group &g : groups) {
        if (!first) {
            cardLay->addSpacing(30);
            cardLay->addWidget(hline(card));
            cardLay->addSpacing(30);
        }
        first = false;

        auto *section = new SectionCard(iconForGroup(g.id), g.title, card);
        auto *grid = section->grid();

        // Optional block (ReloadBank): a switch in the header adds or deletes
        // the whole table. When it is off the fields below are ghost rows.
        if (!g.toggleTable.isEmpty()) {
            section->setToggleVisible(true);
            section->setToggleChecked(g.tablePresent);
            section->setToggleHint(g.tablePresent
                                       ? QStringLiteral("Убрать блок «%1» из файла").arg(g.title)
                                       : QStringLiteral("Добавить блок «%1» в файл").arg(g.title));
            const QString table = g.toggleTable;
            connect(section, &SectionCard::toggleChanged, this, [this, table](bool on) {
                LuaFile &f = m_project->file(m_relPath);
                bool ok = false;
                if (on)
                    ok = f.addTable(table, ParamCatalog::tableTemplate(table));
                else
                    ok = f.removeProperty(table);
                if (ok) {
                    m_project->markDirty(m_relPath);
                    emit fileChanged(m_relPath);
                    QTimer::singleShot(0, this, [this] { rebuildCard(); });
                }
            });
        }

        int row = 0;
        int col = 0;
        for (const Entry &e : g.entries) {
            const QString path = e.path;
            const QString key = e.key;

            if (e.kind == LuaKind::Bool) {
                if (col != 0) {
                    col = 0;
                    ++row;
                }

                auto *w = new QWidget(section);
                auto *lay = new QHBoxLayout(w);
                lay->setContentsMargins(0, 4, 0, 4);
                lay->setSpacing(16);

                auto *col2 = new QVBoxLayout();
                col2->setContentsMargins(0, 0, 0, 0);
                col2->setSpacing(3);

                auto *titleRow = new QHBoxLayout();
                titleRow->setContentsMargins(0, 0, 0, 0);
                titleRow->setSpacing(6);

                auto *t = new QLabel(ParamCatalog::tableChildLabel(e.table, key), w);
                t->setStyleSheet(e.unset
                                     ? QStringLiteral("color:#6b7378;font-size:14px;font-weight:600;")
                                     : QStringLiteral("color:#e2e6e8;font-size:14px;font-weight:600;"));
                titleRow->addWidget(t, 0, Qt::AlignVCenter);

                auto *help = new HelpButton(w);
                help->setHint(ParamCatalog::tableChildHint(e.table, key));
                titleRow->addWidget(help, 0, Qt::AlignVCenter);
                titleRow->addStretch(1);
                col2->addLayout(titleRow);

                lay->addLayout(col2, 1);

                auto *sw = new ToggleSwitch(w);
                sw->setChecked(!e.unset
                               && e.prop->value.compare(QLatin1String("true"), Qt::CaseInsensitive) == 0);
                lay->addWidget(sw, 0, Qt::AlignVCenter);

                const bool unset = e.unset;
                const QString table = e.table;
                connect(sw, &ToggleSwitch::toggled, this, [this, path, unset, table, key](bool on) {
                    LuaFile &f = m_project->file(m_relPath);
                    bool ok = false;
                    if (unset)
                        ok = f.addProperty(path.section(QLatin1Char('.'), -1),
                                           on ? QStringLiteral("true") : QStringLiteral("false"),
                                           table);
                        if (ok)
                            m_removedKeys.remove(key);
                    else
                        ok = f.setValue(path, on ? QStringLiteral("true") : QStringLiteral("false"));
                    if (ok) {
                        m_project->markDirty(m_relPath);
                        emit fileChanged(m_relPath);
                        if (unset)
                            QTimer::singleShot(0, this, [this] { rebuildCard(); });
                    }
                });

                grid->addWidget(w, row, 0, 1, 1);
                col = 1;
                continue;
            }

            auto *field = new FieldRow(ParamCatalog::tableChildLabel(e.table, key),
                                       ParamCatalog::unit(key), section);
            field->setHint(ParamCatalog::tableChildHint(e.table, key));
            // Pick-lists: game values, the mod's own files, effect files.
            const QString shown = e.unset ? e.defValue : e.prop->value;
            QStringList choices = GameCatalog::instance().choicesFor(key);
            if (key == QLatin1String("FileName")) {
                choices.clear();
                const QStringList files = kind == ParamCatalog::Kind::DeviceList
                                              ? m_project->deviceFiles()
                                              : m_project->weaponFiles();
                for (const QString &w : files)
                    choices << QStringLiteral("path .. \"/%1\"").arg(w);
            } else if (key.endsWith(QLatin1String("Effect"))
                       && shown.contains(QLatin1String(".lua"))) {
                // FireEffect / DestroyEffect / … point at effect files.
                choices = m_project->effectChoices();
                choices += GameCatalog::instance().effects();
            } else if (key == QLatin1String("Prerequisite")
                       || key == QLatin1String("PrerequisiteAlt")
                       || key == QLatin1String("Tech")) {
                // Devices / technologies are referenced by SaveName. Offer the
                // mod's own names first, then whatever the base game ships.
                const QStringList own = m_project->technologyChoices();
                const QStringList base = GameCatalog::instance().technologies();
                choices = own;                       // mod entries come first
                for (const QString &b : base)
                    if (!choices.contains(b))
                        choices << b;
            }
            field->setChoices(choices);
            if (e.kind == LuaKind::Number) {
                const ParamCatalog::Range r = ParamCatalog::rangeFor(key);
                if (r.defined)
                    field->setRange(r.min, r.max, r.integer);
            }

            if (e.unset) {
                field->setUnset(true);
                field->setPlaceholder(m_removedKeys.contains(key)
                                          ? QStringLiteral("убран — введите значение, чтобы вернуть")
                                          : QStringLiteral("не задано"));
                field->setKind(e.kind == LuaKind::Number ? QStringLiteral("number")
                                                         : QStringLiteral("text"));
                field->setToolTip(QStringLiteral("Этого параметра нет в файле. "
                                                 "Введите значение, чтобы добавить его."));
                const QString table = e.table;
                connect(field, &FieldRow::edited, this, [this, path, table, key](const QString &v) {
                    LuaFile &f = m_project->file(m_relPath);
                    // A value inside an optional block: switching the block on
                    // happens first so the line has somewhere to go.
                    if (!table.isEmpty() && !f.hasTable(table)
                        && ParamCatalog::isToggleableTable(table)) {
                        f.addTable(table, ParamCatalog::tableTemplate(table));
                    }
                    if (f.addProperty(path.section(QLatin1Char('.'), -1), v, table)) {
                        m_removedKeys.remove(key);
                        m_project->markDirty(m_relPath);
                        emit fileChanged(m_relPath);
                        QTimer::singleShot(0, this, [this] { rebuildCard(); });
                    }
                });
            } else {
                field->setValue(e.prop->value);
                if (e.kind == LuaKind::Expression) {
                    field->setReadOnly(true);
                    field->setToolTip(QStringLiteral("Значение вычисляется в коде и не редактируется"));
                } else {
                    field->setKind(e.kind == LuaKind::Number ? QStringLiteral("number")
                                                             : QStringLiteral("text"));
                    connect(field, &FieldRow::edited, this, [this, path](const QString &v) {
                        LuaFile &f = m_project->file(m_relPath);
                        if (f.setValue(path, v)) {
                            m_project->markDirty(m_relPath);
                            emit fileChanged(m_relPath);
                        }
                    });
                }
            }

            // Existing parameters can be deleted from the file entirely.
            if (!e.unset) {
                field->setRemoveVisible(true);
                const QString propPath = e.path;
                connect(field, &FieldRow::removeRequested, this, [this, propPath] {
                    removeParameter(propPath);
                });
            }

            grid->addWidget(field, row, col, 1, 1);
            if (++col == 2) {
                col = 0;
                ++row;
            }
        }

        cardLay->addWidget(section);
    }

    if (groups.isEmpty()) {
        auto *empty = new QLabel(
            QStringLiteral("В этом файле не найдено редактируемых параметров. "
                           "Откройте вкладку «Редактор кода»."), card);
        empty->setObjectName(QStringLiteral("CardSubtitle"));
        empty->setWordWrap(true);
        cardLay->addWidget(empty);
    }

    // ---- textures ------------------------------------------------------------
    if (!lf.textures().isEmpty()) {
        if (!groups.isEmpty() || !activeArray.isEmpty()) {
            cardLay->addSpacing(30);
            cardLay->addWidget(hline(card));
            cardLay->addSpacing(30);
        }

        auto *section = new SectionCard(Icons::fileImage(19), QStringLiteral("Текстуры"), card);
        auto *grid = section->grid();

        static const QHash<QString, QString> kRoleNames = {
            {QStringLiteral("base"), QStringLiteral("Текстура основы")},
            {QStringLiteral("head"), QStringLiteral("Текстура головы")},
            {QStringLiteral("barrel"), QStringLiteral("Текстура ствола")},
        };
        static const QHash<QString, QString> kRoleHints = {
            {QStringLiteral("base"), QStringLiteral("Спрайт основания орудия")},
            {QStringLiteral("head"), QStringLiteral("Спрайт поворотной части")},
            {QStringLiteral("barrel"), QStringLiteral("Спрайт ствола")},
        };

        const QStringList texChoices = m_project->textureChoices();
        int textureRow = 0;
        for (const TextureRef &t : lf.textures()) {
            const QString role = LuaFile::textureRole(t);
            const QString label = kRoleNames.value(
                role, t.sprite.isEmpty() ? QStringLiteral("Текстура") : t.sprite);

            auto *row = new QWidget(section);
            auto *rowLay = new QVBoxLayout(row);
            rowLay->setContentsMargins(0, 0, 0, 0);
            rowLay->setSpacing(8);

            auto *field = new FieldRow(label, QString(), row);
            field->setValue(t.value);
            field->setKind(QStringLiteral("text"));
            field->setHint(kRoleHints.value(role, QStringLiteral("Файл текстуры спрайта")));
            field->setChoices(texChoices, /*editable=*/true);
            field->setBrowseVisible(true);
            rowLay->addWidget(field);

            // Thumbnail of whatever the field currently points at.
            auto *preview = new QLabel(row);
            preview->setObjectName(QStringLiteral("TexturePreview"));
            preview->setFixedSize(340, 96);
            preview->setAlignment(Qt::AlignCenter);
            preview->setAttribute(Qt::WA_StyledBackground, true);
            rowLay->addWidget(preview, 0, Qt::AlignLeft);

            const auto refresh = [this, preview, field] {
                const QString file = resolveAssetPath(field->value());
                QPixmap pm;
                if (!file.isEmpty())
                    pm = QPixmap(file);

                if (pm.isNull()) {
                    preview->setPixmap(QPixmap());
                    preview->setText(QStringLiteral("нет файла"));
                    preview->setToolTip(file.isEmpty()
                                            ? QStringLiteral("Путь не распознан")
                                            : QStringLiteral("Файл не найден:\n%1").arg(file));
                    return;
                }
                preview->setText(QString());
                preview->setToolTip(QStringLiteral("%1\n%2×%3")
                                        .arg(file)
                                        .arg(pm.width())
                                        .arg(pm.height()));
                preview->setPixmap(pm.scaled(preview->size() - QSize(8, 8),
                                             Qt::KeepAspectRatio, Qt::SmoothTransformation));
            };
            refresh();

            const int line = t.line;
            connect(field, &FieldRow::edited, this, [this, line, refresh](const QString &v) {
                LuaFile &f = m_project->file(m_relPath);
                if (f.setTexture(line, v)) {
                    m_project->markDirty(m_relPath);
                    emit fileChanged(m_relPath);
                    refresh();
                }
            });
            connect(field, &FieldRow::browseRequested, this,
                    [this, field, line, refresh] { browseForTexture(field, line, refresh); });

            grid->addWidget(row, textureRow++, 0, 1, 2);
        }

        cardLay->addWidget(section);
    }

    // ---- info note ------------------------------------------------------------
    cardLay->addSpacing(22);
    auto *info = new QWidget(card);
    info->setObjectName(QStringLiteral("InfoBox"));
    auto *infoLay = new QHBoxLayout(info);
    infoLay->setContentsMargins(13, 11, 13, 11);
    infoLay->setSpacing(11);
    auto *infoIcon = new QLabel(info);
    infoIcon->setFixedSize(16, 16);
    infoIcon->setPixmap(Icons::info(16).pixmap(16, 16));
    infoLay->addWidget(infoIcon, 0, Qt::AlignTop);
    auto *infoText = new QLabel(
        QStringLiteral("Подписи переводятся автоматически и не меняют сам мод — "
                       "правки затрагивают только значения."), info);
    infoText->setWordWrap(true);
    infoLay->addWidget(infoText, 1);
    cardLay->addWidget(info);
    cardLay->addStretch(1);

    return card;
}
