#pragma once

#include <QWidget>

class ModEntry;
class ModProject;
class QLabel;
class QLineEdit;
class QListWidget;
class QPushButton;
class QTimer;
class QTreeWidget;
class QTreeWidgetItem;

// Left column: the mod's file tree, a filter box and the selected-file summary.
class Sidebar : public QWidget
{
    Q_OBJECT

public:
    explicit Sidebar(QWidget *parent = nullptr);

    void setProject(ModProject *project);
    void refreshDirty();
    void selectPath(const QString &relPath);

signals:
    void fileSelected(const QString &relPath);
    // Right-click actions
    void renameRequested(const QString &relPath, bool isDir);
    void addWeaponRequested(const QString &folderRelPath);
    void addDeviceRequested(const QString &folderRelPath);

private:
    void populate();
    void addEntry(QTreeWidgetItem *parentItem, const ModEntry &entry);
    void onItemActivated(QTreeWidgetItem *item, int column);
    void updateSelectedPanel(const QString &relPath);
    void applyFilter(const QString &needle);
    bool filterItem(QTreeWidgetItem *item, const QString &needle);
    void runContentSearch(const QString &needle);

    ModProject *m_project = nullptr;
    QTreeWidget *m_tree = nullptr;
    QLineEdit *m_search = nullptr;
    QLabel *m_selPath = nullptr;
    QLabel *m_selMeta = nullptr;
    QPushButton *m_editBtn = nullptr;
    QWidget *m_selPanel = nullptr;

    // "Search inside files" results, shown under the search box.
    QListWidget *m_results = nullptr;
    QLabel *m_resultsTitle = nullptr;
    QTimer *m_searchTimer = nullptr;
};
