#include "Sidebar.h"

#include "../Icons.h"
#include "../ModModel.h"
#include "../Theme.h"

#include <QFileInfo>
#include <QElapsedTimer>
#include <QFile>
#include <QListWidget>
#include <QMenu>
#include <QTimer>
#include <QHBoxLayout>
#include <QHeaderView>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QDesktopServices>
#include <QDirIterator>
#include <QTreeWidget>
#include <QUrl>
#include <QTreeWidgetItemIterator>
#include <QVBoxLayout>

namespace {
constexpr int kRelPathRole = Qt::UserRole;
constexpr int kIsDirRole = Qt::UserRole + 1;
} // namespace

Sidebar::Sidebar(QWidget *parent)
    : QWidget(parent)
{
    setObjectName(QStringLiteral("Sidebar"));
    setAttribute(Qt::WA_StyledBackground, true);
    setMinimumWidth(224);
    setMaximumWidth(340);

    auto *root = new QVBoxLayout(this);
    root->setContentsMargins(0, 0, 0, 0);
    root->setSpacing(0);

    // ---- header -------------------------------------------------------------
    auto *headerWrap = new QWidget(this);
    auto *hl = new QHBoxLayout(headerWrap);
    hl->setContentsMargins(16, 14, 12, 8);
    hl->setSpacing(2);

    auto *hdr = new QLabel(QStringLiteral("ДИРЕКТОРИЯ"), headerWrap);
    hdr->setObjectName(QStringLiteral("SidebarHeader"));
    hl->addWidget(hdr);
    hl->addStretch(1);

    auto *refreshBtn = new QPushButton(headerWrap);
    refreshBtn->setObjectName(QStringLiteral("IconGhost"));
    refreshBtn->setIcon(Icons::refresh(16));
    refreshBtn->setIconSize(QSize(16, 16));
    refreshBtn->setCursor(Qt::PointingHandCursor);
    refreshBtn->setToolTip(QStringLiteral("Обновить"));
    hl->addWidget(refreshBtn);

    auto *collapseBtn = new QPushButton(headerWrap);
    collapseBtn->setObjectName(QStringLiteral("IconGhost"));
    collapseBtn->setIcon(Icons::collapseAll(16));
    collapseBtn->setIconSize(QSize(16, 16));
    collapseBtn->setCursor(Qt::PointingHandCursor);
    collapseBtn->setToolTip(QStringLiteral("Свернуть всё"));
    hl->addWidget(collapseBtn);

    root->addWidget(headerWrap);

    // ---- search -------------------------------------------------------------
    auto *searchWrap = new QWidget(this);
    auto *sl = new QHBoxLayout(searchWrap);
    sl->setContentsMargins(12, 0, 12, 10);
    m_search = new QLineEdit(searchWrap);
    m_search->setObjectName(QStringLiteral("Search"));
    m_search->setPlaceholderText(QStringLiteral("Поиск файлов..."));
    m_search->addAction(Icons::search(15), QLineEdit::LeadingPosition);
    sl->addWidget(m_search);
    root->addWidget(searchWrap);

    // Matches found inside file contents.
    m_resultsTitle = new QLabel(this);
    m_resultsTitle->setObjectName(QStringLiteral("Unit"));
    m_resultsTitle->setVisible(false);
    root->addWidget(m_resultsTitle);

    m_results = new QListWidget(this);
    m_results->setObjectName(QStringLiteral("SearchResults"));
    m_results->setVisible(false);
    m_results->setMaximumHeight(210);
    m_results->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    m_results->setToolTip(QStringLiteral("Совпадения внутри файлов — нажмите, чтобы открыть"));
    connect(m_results, &QListWidget::itemClicked, this, [this](QListWidgetItem *item) {
        if (!item)
            return;
        const QString rel = item->data(Qt::UserRole).toString();
        if (rel.isEmpty())
            return;
        selectPath(rel);
        emit fileSelected(rel);
    });
    root->addWidget(m_results);

    // Debounce: scanning file contents on every keystroke would be wasteful.
    m_searchTimer = new QTimer(this);
    m_searchTimer->setSingleShot(true);
    m_searchTimer->setInterval(300);
    connect(m_searchTimer, &QTimer::timeout, this, [this] {
        runContentSearch(m_search->text().trimmed());
    });

    // ---- tree ---------------------------------------------------------------
    m_tree = new QTreeWidget(this);
    m_tree->setObjectName(QStringLiteral("Tree"));
    m_tree->setHeaderHidden(true);
    m_tree->setColumnCount(2);
    m_tree->setIndentation(16);
    m_tree->setAnimated(true);
    m_tree->setRootIsDecorated(true);
    m_tree->setUniformRowHeights(true);
    m_tree->setSelectionMode(QAbstractItemView::SingleSelection);
    m_tree->setEditTriggers(QAbstractItemView::NoEditTriggers);
    m_tree->setFocusPolicy(Qt::NoFocus);
    m_tree->header()->setStretchLastSection(false);
    m_tree->header()->setSectionResizeMode(0, QHeaderView::Stretch);
    m_tree->header()->setSectionResizeMode(1, QHeaderView::Fixed);
    m_tree->setColumnWidth(1, 36);
    root->addWidget(m_tree, 1);

    // ---- selected file ------------------------------------------------------
    m_selPanel = new QWidget(this);
    m_selPanel->setObjectName(QStringLiteral("SelectedFile"));
    auto *pl = new QVBoxLayout(m_selPanel);
    pl->setContentsMargins(16, 12, 16, 12);
    pl->setSpacing(5);

    auto *cap = new QLabel(QStringLiteral("ВЫБРАННЫЙ ФАЙЛ"), m_selPanel);
    cap->setObjectName(QStringLiteral("SelectedFileHeader"));
    pl->addWidget(cap);

    m_selPath = new QLabel(m_selPanel);
    m_selPath->setObjectName(QStringLiteral("SelectedFileTitle"));
    pl->addWidget(m_selPath);

    auto *row = new QHBoxLayout();
    row->setContentsMargins(0, 0, 0, 0);
    m_selMeta = new QLabel(m_selPanel);
    m_selMeta->setObjectName(QStringLiteral("SelectedFileMeta"));
    row->addWidget(m_selMeta);
    row->addStretch(1);

    m_editBtn = new QPushButton(QStringLiteral("Изменить"), m_selPanel);
    m_editBtn->setObjectName(QStringLiteral("Link"));
    m_editBtn->setCursor(Qt::PointingHandCursor);
    row->addWidget(m_editBtn);
    pl->addLayout(row);

    root->addWidget(m_selPanel);
    m_selPanel->setVisible(false);

    // ---- wiring -------------------------------------------------------------
    connect(m_tree, &QTreeWidget::itemClicked, this,
            [this](QTreeWidgetItem *item, int) { onItemActivated(item, 0); });
    connect(m_search, &QLineEdit::textChanged, this, [this](const QString &t) {
        applyFilter(t);
        m_searchTimer->start();
    });
    connect(collapseBtn, &QPushButton::clicked, this, [this] { m_tree->collapseAll(); });
    connect(refreshBtn, &QPushButton::clicked, this, [this] { populate(); });
    // Right-click menu on tree items.
    m_tree->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(m_tree, &QTreeWidget::customContextMenuRequested, this, [this](const QPoint &pos) {
        QTreeWidgetItem *item = m_tree->itemAt(pos);
        if (!item || !m_project)
            return;

        const QString rel = item->data(0, kRelPathRole).toString();
        const bool isDir = item->data(0, kIsDirRole).toBool();

        QMenu menu(this);
        if (!rel.isEmpty()) {
            menu.addAction(QStringLiteral("Переименовать"), this,
                           [this, rel, isDir] { emit renameRequested(rel, isDir); });
        }
        if (isDir && (rel.isEmpty() || rel == QLatin1String("weapons"))) {
            menu.addAction(QStringLiteral("Добавить новую пушку"), this,
                           [this, rel] { emit addWeaponRequested(rel); });
        }
        if (isDir && (rel.isEmpty() || rel == QLatin1String("devices"))) {
            menu.addAction(QStringLiteral("Добавить устройство"), this,
                           [this, rel] { emit addDeviceRequested(rel); });
        }
        if (!rel.isEmpty()) {
            menu.addSeparator();
            menu.addAction(QStringLiteral("Показать в проводнике"), this, [this, rel] {
                QDesktopServices::openUrl(
                    QUrl::fromLocalFile(m_project->rootPath() + QLatin1Char('/') + rel));
            });
        }
        if (menu.isEmpty())
            return;
        menu.exec(m_tree->viewport()->mapToGlobal(pos));
    });

    connect(m_editBtn, &QPushButton::clicked, this, [this] {
        const QString p = m_selPath->text();
        if (!p.isEmpty())
            emit fileSelected(p);
    });
}

void Sidebar::setProject(ModProject *project)
{
    m_project = project;
    populate();
}

void Sidebar::populate()
{
    m_tree->clear();
    if (!m_project || !m_project->isOpen())
        return;

    const ModEntry &rootEntry = m_project->tree();
    auto *rootItem = new QTreeWidgetItem(m_tree);
    rootItem->setText(0, rootEntry.name);
    rootItem->setIcon(0, Icons::modBox(18));
    rootItem->setData(0, kRelPathRole, QString());
    rootItem->setData(0, kIsDirRole, true);
    rootItem->setToolTip(0, m_project->rootPath());

    for (const ModEntry &child : rootEntry.children)
        addEntry(rootItem, child);

    rootItem->setExpanded(true);
    for (int i = 0; i < rootItem->childCount(); ++i) {
        if (rootItem->child(i)->text(0) == QLatin1String("weapons"))
            rootItem->child(i)->setExpanded(true);
    }

    refreshDirty();
    if (!m_search->text().isEmpty())
        applyFilter(m_search->text());
}

void Sidebar::addEntry(QTreeWidgetItem *parentItem, const ModEntry &entry)
{
    auto *item = new QTreeWidgetItem(parentItem);
    item->setText(0, entry.name);
    item->setToolTip(0, entry.relPath);

    if (entry.isDir) {
        item->setIcon(0, Icons::folder(18));
    } else {
        const QString kind = ModProject::iconKindFor(entry.relPath);
        if (kind == QLatin1String("lua"))
            item->setIcon(0, Icons::fileLua(18));
        else if (kind == QLatin1String("image"))
            item->setIcon(0, Icons::fileImage(18));
        else
            item->setIcon(0, Icons::fileGeneric(18));
    }

    item->setData(0, kRelPathRole, entry.relPath);
    item->setData(0, kIsDirRole, entry.isDir);

    if (entry.isDir && entry.count > 0) {
        item->setText(1, QString::number(entry.count));
        item->setForeground(1, Theme::TextMute);
        item->setTextAlignment(1, Qt::AlignRight | Qt::AlignVCenter);
    }

    for (const ModEntry &child : entry.children)
        addEntry(item, child);
}

void Sidebar::onItemActivated(QTreeWidgetItem *item, int)
{
    if (!item)
        return;

    const QString rel = item->data(0, kRelPathRole).toString();
    const bool isDir = item->data(0, kIsDirRole).toBool();

    if (isDir) {
        item->setExpanded(!item->isExpanded());
        return;
    }

    updateSelectedPanel(rel);
    emit fileSelected(rel);
}

void Sidebar::updateSelectedPanel(const QString &relPath)
{
    if (relPath.isEmpty() || !m_project) {
        m_selPanel->setVisible(false);
        return;
    }

    m_selPanel->setVisible(true);
    m_selPath->setText(relPath);

    const QFileInfo fi(m_project->rootPath() + QLatin1Char('/') + relPath);
    m_selMeta->setText(QStringLiteral("%1 · %2")
                           .arg(ModProject::typeLabelFor(relPath), ModProject::humanSize(fi.size())));
}

void Sidebar::selectPath(const QString &relPath)
{
    QTreeWidgetItemIterator it(m_tree);
    while (*it) {
        QTreeWidgetItem *item = *it;
        if (item->data(0, kRelPathRole).toString() == relPath) {
            for (QTreeWidgetItem *p = item->parent(); p; p = p->parent())
                p->setExpanded(true);
            m_tree->setCurrentItem(item);
            updateSelectedPanel(relPath);
            return;
        }
        ++it;
    }
}

void Sidebar::refreshDirty()
{
    QTreeWidgetItemIterator it(m_tree);
    while (*it) {
        QTreeWidgetItem *item = *it;
        if (!item->data(0, kIsDirRole).toBool()) {
            const QString rel = item->data(0, kRelPathRole).toString();
            if (m_project && m_project->isDirty(rel))
                item->setIcon(1, Icons::dot(10, Theme::Warn));
            else
                item->setIcon(1, QIcon());
        }
        ++it;
    }
}

void Sidebar::runContentSearch(const QString &needle)
{
    m_results->clear();

    if (!m_project || needle.size() < 3) {
        m_results->setVisible(false);
        m_resultsTitle->setVisible(false);
        return;
    }

    const int kMaxResults = 200;
    const int kMaxMillis = 1500;

    QElapsedTimer clock;
    clock.start();

    int total = 0;
    const QDir root(m_project->rootPath());
    QDirIterator it(root.absolutePath(), QStringList{QStringLiteral("*.lua")},
                    QDir::Files, QDirIterator::Subdirectories);
    while (it.hasNext() && total < kMaxResults) {
        const QString file = it.next();
        if (clock.elapsed() > kMaxMillis)
            break;

        QFile f(file);
        if (!f.open(QIODevice::ReadOnly))
            continue;
        const QStringList lines = QString::fromUtf8(f.readAll()).split(QLatin1Char('\n'));
        f.close();

        const QString rel = root.relativeFilePath(file);
        for (int i = 0; i < lines.size() && total < kMaxResults; ++i) {
            if (!lines.at(i).contains(needle, Qt::CaseInsensitive))
                continue;
            auto *item = new QListWidgetItem(
                QStringLiteral("%1 : %2").arg(rel).arg(i + 1), m_results);
            item->setData(Qt::UserRole, rel);
            item->setToolTip(lines.at(i).trimmed());
            ++total;
        }
    }

    m_resultsTitle->setText(total == 0
                                ? QStringLiteral("Внутри файлов ничего не найдено")
                                : QStringLiteral("Найдено в файлах: %1%2")
                                      .arg(total)
                                      .arg(total >= kMaxResults ? QStringLiteral("+")
                                                                : QString()));
    m_resultsTitle->setVisible(true);
    m_results->setVisible(total > 0);
}

void Sidebar::applyFilter(const QString &needle)
{
    for (int i = 0; i < m_tree->topLevelItemCount(); ++i)
        filterItem(m_tree->topLevelItem(i), needle);
}

bool Sidebar::filterItem(QTreeWidgetItem *item, const QString &needle)
{
    bool anyChildVisible = false;
    for (int i = 0; i < item->childCount(); ++i)
        anyChildVisible |= filterItem(item->child(i), needle);

    const bool selfMatch = needle.isEmpty()
                           || item->text(0).contains(needle, Qt::CaseInsensitive);
    const bool visible = selfMatch || anyChildVisible;

    item->setHidden(!visible);
    if (!needle.isEmpty() && anyChildVisible)
        item->setExpanded(true);

    return visible;
}
