#include "ClickableWidget.h"

#include <QEnterEvent>
#include <QMouseEvent>
#include <QStyle>

ClickableWidget::ClickableWidget(QWidget *parent)
    : QWidget(parent)
{
    setCursor(Qt::PointingHandCursor);
    setAttribute(Qt::WA_StyledBackground, true);
    setProperty("hovered", false);
}

void ClickableWidget::setHovered(bool on)
{
    if (property("hovered").toBool() == on)
        return;
    setProperty("hovered", on);
    style()->unpolish(this);
    style()->polish(this);
}

void ClickableWidget::mouseReleaseEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton && rect().contains(event->position().toPoint()))
        emit clicked();
    QWidget::mouseReleaseEvent(event);
}

void ClickableWidget::enterEvent(QEnterEvent *event)
{
    setHovered(true);
    QWidget::enterEvent(event);
}

void ClickableWidget::leaveEvent(QEvent *event)
{
    setHovered(false);
    QWidget::leaveEvent(event);
}
