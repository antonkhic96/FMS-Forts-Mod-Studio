#include "ToggleSwitch.h"

#include "../Theme.h"

#include <QPainter>
#include <QPropertyAnimation>

namespace {

QColor mix(const QColor &a, const QColor &b, qreal t)
{
    return QColor::fromRgbF(a.redF() + (b.redF() - a.redF()) * t,
                            a.greenF() + (b.greenF() - a.greenF()) * t,
                            a.blueF() + (b.blueF() - a.blueF()) * t);
}

} // namespace

ToggleSwitch::ToggleSwitch(QWidget *parent)
    : QAbstractButton(parent)
{
    setCheckable(true);
    setCursor(Qt::PointingHandCursor);
    setFocusPolicy(Qt::NoFocus);

    m_anim = new QPropertyAnimation(this, "position", this);
    m_anim->setDuration(140);
    m_anim->setEasingCurve(QEasingCurve::InOutQuad);

    connect(this, &QAbstractButton::toggled, this, [this](bool on) {
        m_anim->stop();
        m_anim->setStartValue(m_position);
        m_anim->setEndValue(on ? 1.0 : 0.0);
        m_anim->start();
    });
}

QSize ToggleSwitch::sizeHint() const
{
    return QSize(46, 26);
}

void ToggleSwitch::setPosition(qreal p)
{
    m_position = qBound(0.0, p, 1.0);
    update();
}

void ToggleSwitch::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing, true);

    const QRectF r = QRectF(rect()).adjusted(0.5, 0.5, -0.5, -0.5);
    const qreal radius = r.height() / 2.0;

    const QColor off = QColor(0x33, 0x3a, 0x40);
    const QColor on = Theme::Accent;

    p.setPen(Qt::NoPen);
    p.setBrush(mix(off, on, m_position));
    p.drawRoundedRect(r, radius, radius);

    const qreal margin = 4.0;
    const qreal d = r.height() - margin * 2.0;
    const qreal x = r.left() + margin + m_position * (r.width() - d - margin * 2.0);

    p.setBrush(QColor(0x1d, 0x23, 0x27));
    p.drawEllipse(QRectF(x, r.top() + margin, d, d));
}
