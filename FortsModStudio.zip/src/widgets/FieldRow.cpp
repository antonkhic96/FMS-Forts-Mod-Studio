#include "FieldRow.h"

#include "HelpButton.h"
#include "WheelSafeComboBox.h"

#include "../Icons.h"

#include <QComboBox>
#include <QEvent>
#include <QFrame>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QRegularExpression>
#include <QSignalBlocker>
#include <QStyle>
#include <QToolTip>
#include <QVBoxLayout>

FieldRow::FieldRow(const QString &label, const QString &unit, QWidget *parent)
    : QWidget(parent)
{
    auto *outer = new QVBoxLayout(this);
    outer->setContentsMargins(0, 0, 0, 0);
    outer->setSpacing(5);

    // Label row: text + "?" button explaining the parameter.
    auto *labelRow = new QHBoxLayout();
    labelRow->setContentsMargins(0, 0, 0, 0);
    labelRow->setSpacing(6);

    m_label = new QLabel(label, this);
    m_label->setObjectName(QStringLiteral("FieldLabel"));
    labelRow->addWidget(m_label, 0, Qt::AlignVCenter);

    m_help = new HelpButton(this);
    labelRow->addWidget(m_help, 0, Qt::AlignVCenter);

    // "×" - deletes the parameter from the file (writing 0/false is not the
    // same as not having the setting at all).
    m_remove = new QPushButton(this);
    m_remove->setObjectName(QStringLiteral("RemoveBtn"));
    m_remove->setIcon(Icons::remove(13));
    m_remove->setIconSize(QSize(13, 13));
    m_remove->setFixedSize(18, 18);
    m_remove->setCursor(Qt::PointingHandCursor);
    m_remove->setFocusPolicy(Qt::NoFocus);
    m_remove->setVisible(false);
    m_remove->setToolTip(QStringLiteral("Убрать параметр из файла\n(Ctrl+Z — вернуть)"));
    labelRow->addWidget(m_remove, 0, Qt::AlignVCenter);
    labelRow->addStretch(1);

    outer->addLayout(labelRow);

    // The visible input is a frame so the unit can sit inside it, exactly like
    // the design.
    m_box = new QFrame(this);
    m_box->setObjectName(QStringLiteral("Field"));
    m_box->setMinimumHeight(32);
    m_box->setProperty("focused", false);

    auto *boxLay = new QHBoxLayout(m_box);
    m_boxLay = boxLay;
    boxLay->setContentsMargins(11, 0, 12, 0);
    boxLay->setSpacing(8);

    m_edit = new QLineEdit(m_box);
    m_edit->setObjectName(QStringLiteral("FieldInput"));
    m_edit->setFrame(false);
    boxLay->addWidget(m_edit, 1);

    m_unit = new QLabel(unit, m_box);
    m_unit->setObjectName(QStringLiteral("Unit"));
    m_unit->setVisible(!unit.isEmpty());
    boxLay->addWidget(m_unit, 0, Qt::AlignVCenter);

    // "Выбрать" - opens a file dialog (the panel decides what to do with it).
    m_browse = new QPushButton(QStringLiteral("Выбрать"), m_box);
    m_browse->setObjectName(QStringLiteral("BrowseBtn"));
    m_browse->setCursor(Qt::PointingHandCursor);
    m_browse->setFocusPolicy(Qt::NoFocus);
    m_browse->setVisible(false);
    boxLay->addWidget(m_browse, 0, Qt::AlignVCenter);

    outer->addWidget(m_box);

    m_edit->installEventFilter(this);

    connect(m_edit, &QLineEdit::editingFinished, this, &FieldRow::commit);
    connect(m_edit, &QLineEdit::returnPressed, this, &FieldRow::commit);
    connect(m_browse, &QPushButton::clicked, this, &FieldRow::browseRequested);
    connect(m_remove, &QPushButton::clicked, this, &FieldRow::removeRequested);
}

void FieldRow::setRemoveVisible(bool visible)
{
    m_remove->setVisible(visible);
}

void FieldRow::setBrowseVisible(bool visible)
{
    m_browse->setVisible(visible);
}

void FieldRow::setHint(const QString &text)
{
    m_hint = text;
    m_help->setHint(text);
}

QString FieldRow::value() const
{
    if (m_combo)
        return m_combo->currentText().trimmed();
    return m_edit->text().trimmed();
}

void FieldRow::setValue(const QString &v)
{
    m_last = v;
    if (m_combo) {
        if (!v.isEmpty() && m_combo->findText(v) < 0)
            m_combo->insertItem(0, v);
        m_combo->setCurrentText(v);
        return;
    }
    m_edit->setText(v);
}

void FieldRow::setRange(double min, double max, bool integer)
{
    m_min = min;
    m_max = max;
    m_integer = integer;
    m_hasRange = true;
}

void FieldRow::setChoices(const QStringList &choices, bool editable)
{
    if (choices.isEmpty())
        return;

    if (!m_combo) {
        m_combo = new WheelSafeComboBox(m_box);
        m_combo->setObjectName(QStringLiteral("FieldCombo"));
        m_combo->setCursor(Qt::PointingHandCursor);
        m_combo->setEditable(editable);
        if (editable) {
            // Typed values must not be added to the list, and a value only
            // counts as an edit when the user is done with it.
            m_combo->setInsertPolicy(QComboBox::NoInsert);
            m_combo->lineEdit()->setPlaceholderText(QStringLiteral("введите путь"));
            connect(m_combo->lineEdit(), &QLineEdit::editingFinished, this, [this] {
                const QString t = m_combo->currentText().trimmed();
                if (t.isEmpty() || t == m_last)
                    return;
                m_last = t;
                emit edited(t);
            });
            connect(m_combo, QOverload<int>::of(&QComboBox::activated), this, [this] {
                const QString t = m_combo->currentText().trimmed();
                if (t.isEmpty() || t == m_last)
                    return;
                m_last = t;
                emit edited(t);
            });
        } else {
            connect(m_combo, &QComboBox::currentTextChanged, this, [this](const QString &t) {
                if (t.isEmpty() || t == m_last)
                    return;
                m_last = t;
                emit edited(t);
            });
        }
        m_boxLay->insertWidget(0, m_combo, 1);
        m_edit->setVisible(false);
    }

    // Populating the list must not look like the user picked something: without
    // blocking, addItems would fire currentTextChanged and overwrite the value.
    const QSignalBlocker blocker(m_combo);
    m_combo->clear();
    m_combo->addItems(choices);
    if (!m_last.isEmpty() && m_combo->findText(m_last) < 0)
        m_combo->insertItem(0, m_last);
    m_combo->setCurrentText(m_last);
}

void FieldRow::setReadOnly(bool readOnly)
{
    m_readOnly = readOnly;
    m_edit->setReadOnly(readOnly);
    m_edit->setCursor(readOnly ? Qt::ArrowCursor : Qt::IBeamCursor);
    m_box->setProperty("readonly", readOnly);
    m_box->style()->unpolish(m_box);
    m_box->style()->polish(m_box);
}

void FieldRow::setUnset(bool unset)
{
    m_box->setProperty("unset", unset);
    m_box->style()->unpolish(m_box);
    m_box->style()->polish(m_box);
    m_label->setProperty("unset", unset);
    m_label->style()->unpolish(m_label);
    m_label->style()->polish(m_label);
}

void FieldRow::setPlaceholder(const QString &text)
{
    m_edit->setPlaceholderText(text);
}

bool FieldRow::eventFilter(QObject *obj, QEvent *event)
{
    if (obj == m_edit
        && (event->type() == QEvent::FocusIn || event->type() == QEvent::FocusOut)) {
        m_box->setProperty("focused", event->type() == QEvent::FocusIn);
        m_box->style()->unpolish(m_box);
        m_box->style()->polish(m_box);
    }
    return QWidget::eventFilter(obj, event);
}

void FieldRow::commit()
{
    const QString text = m_edit->text().trimmed();

    if (text.isEmpty()) {
        m_edit->setText(m_last);
        return;
    }

    if (m_kind == QLatin1String("number")) {
        static const QRegularExpression numRe(QStringLiteral(R"(^-?\d+(\.\d+)?$)"));
        if (!numRe.match(text).hasMatch()) {
            m_edit->setText(m_last);
            return;
        }

        if (m_hasRange) {
            bool ok = false;
            const double v = text.toDouble(&ok);
            QString problem;
            if (!ok)
                problem = QStringLiteral("Нужно число");
            else if (m_integer && v != qFloor(v))
                problem = QStringLiteral("Только целое число");
            else if (v < m_min)
                problem = QStringLiteral("Минимум %1").arg(m_min);
            else if (m_max >= 0 && v > m_max)
                problem = QStringLiteral("Максимум %1").arg(m_max);

            if (!problem.isEmpty()) {
                QToolTip::showText(m_edit->mapToGlobal(QPoint(0, m_edit->height())), problem, m_edit);
                m_edit->setText(m_last);
                return;
            }
        }
    }

    if (text == m_last)
        return;

    m_last = text;
    emit edited(text);
}
