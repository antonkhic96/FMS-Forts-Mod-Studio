#include "HelpButton.h"

#include "../Icons.h"

#include <QToolTip>

HelpButton::HelpButton(QWidget *parent)
    : QPushButton(parent)
{
    setObjectName(QStringLiteral("HelpDot"));
    setIcon(Icons::help(14));
    setIconSize(QSize(14, 14));
    setFixedSize(16, 16);
    setCursor(Qt::PointingHandCursor);
    setFocusPolicy(Qt::NoFocus);
    setVisible(false);

    connect(this, &QPushButton::clicked, this, &HelpButton::showHint);
}

void HelpButton::setHint(const QString &text)
{
    m_hint = text;
    setVisible(!text.isEmpty());
    setToolTip(text);
}

void HelpButton::showHint()
{
    if (m_hint.isEmpty())
        return;
    QToolTip::showText(mapToGlobal(QPoint(width() + 4, -2)), m_hint, this);
}
