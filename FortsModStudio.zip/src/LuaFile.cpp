#include "LuaFile.h"
#include "ParamCatalog.h"

#include <QFile>
#include <QFileInfo>
#include <QRegularExpression>
#include <QSet>

namespace {

enum class Encoding { Utf8 = 0, Utf16LE = 1, Utf16BE = 2 };

// Removes `--` line comments and `--[[ ]]` block comments, respecting string
// literals. `inBlock` is carried across lines.
QString cleanLine(const QString &raw, bool &inBlock)
{
    QString out;
    int i = 0;
    const int n = raw.size();
    bool inSingle = false;
    bool inDouble = false;

    while (i < n) {
        if (inBlock) {
            const int end = raw.indexOf(QLatin1String("]]"), i);
            if (end < 0)
                return out;
            i = end + 2;
            inBlock = false;
            continue;
        }

        const QChar c = raw.at(i);
        if (c == QLatin1Char('"') && !inSingle) {
            inDouble = !inDouble;
            out += c;
            ++i;
            continue;
        }
        if (c == QLatin1Char('\'') && !inDouble) {
            inSingle = !inSingle;
            out += c;
            ++i;
            continue;
        }
        if (!inSingle && !inDouble && c == QLatin1Char('-') && i + 1 < n
            && raw.at(i + 1) == QLatin1Char('-')) {
            if (i + 3 < n && raw.at(i + 2) == QLatin1Char('[') && raw.at(i + 3) == QLatin1Char('[')) {
                inBlock = true;
                i += 4;
                continue;
            }
            break;
        }
        out += c;
        ++i;
    }
    return out;
}

// Index of a `--` comment that is not inside a string literal, or -1.
int commentIndex(const QString &line)
{
    bool inSingle = false;
    bool inDouble = false;
    for (int i = 0; i < line.size(); ++i) {
        const QChar c = line.at(i);
        if (c == QLatin1Char('"') && !inSingle)
            inDouble = !inDouble;
        else if (c == QLatin1Char('\'') && !inDouble)
            inSingle = !inSingle;
        else if (!inSingle && !inDouble && c == QLatin1Char('-') && i + 1 < line.size()
                 && line.at(i + 1) == QLatin1Char('-'))
            return i;
    }
    return -1;
}

QString unquote(const QString &raw)
{
    QString v = raw.trimmed();
    if (v.startsWith(QLatin1Char('L')) && v.size() > 1
        && (v.at(1) == QLatin1Char('"') || v.at(1) == QLatin1Char('\'')))
        v = v.mid(1);
    if (v.size() >= 2) {
        const QChar a = v.front();
        const QChar b = v.back();
        if ((a == QLatin1Char('"') && b == QLatin1Char('"'))
            || (a == QLatin1Char('\'') && b == QLatin1Char('\'')))
            return v.mid(1, v.size() - 2);
    }
    return v;
}

LuaKind kindOf(const QString &value)
{
    const QString v = value.trimmed();
    if (v == QLatin1String("true") || v == QLatin1String("false"))
        return LuaKind::Bool;
    if (v.startsWith(QLatin1Char('"')) || v.startsWith(QLatin1Char('\''))
        || v.startsWith(QLatin1String("L\"")) || v.startsWith(QLatin1String("L'")))
        return LuaKind::String;
    if (v.startsWith(QLatin1Char('{')))
        return LuaKind::List;

    static const QRegularExpression numRe(QStringLiteral(R"(^-?\d+(\.\d+)?$)"));
    if (numRe.match(v).hasMatch())
        return LuaKind::Number;

    return LuaKind::Expression;
}

} // namespace

bool LuaFile::load(const QString &path)
{
    QFile f(path);
    if (!f.open(QIODevice::ReadOnly))
        return false;

    const QByteArray data = f.readAll();
    f.close();

    Encoding enc = Encoding::Utf8;
    bool bom = false;
    QString text;

    const auto u = [&data](int i) { return static_cast<unsigned char>(data.at(i)); };

    if (data.size() >= 2 && u(0) == 0xFF && u(1) == 0xFE) {
        enc = Encoding::Utf16LE;
        bom = true;
        const QByteArray body = data.mid(2);
        text = QString::fromUtf16(reinterpret_cast<const char16_t *>(body.constData()),
                                  body.size() / 2);
    } else if (data.size() >= 2 && u(0) == 0xFE && u(1) == 0xFF) {
        enc = Encoding::Utf16BE;
        bom = true;
        const QByteArray body = data.mid(2);
        QString s = QString::fromUtf16(reinterpret_cast<const char16_t *>(body.constData()),
                                       body.size() / 2);
        for (int i = 0; i < s.size(); ++i) {
            const ushort v = s.at(i).unicode();
            s[i] = QChar(static_cast<ushort>((v >> 8) | (v << 8)));
        }
        text = s;
    } else if (data.size() >= 3 && u(0) == 0xEF && u(1) == 0xBB && u(2) == 0xBF) {
        bom = true;
        text = QString::fromUtf8(data.mid(3));
    } else {
        text = QString::fromUtf8(data);
    }

    m_path = path;
    m_encoding = static_cast<int>(enc);
    m_bom = bom;
    m_newline = text.contains(QLatin1String("\r\n")) ? QStringLiteral("\r\n") : QStringLiteral("\n");

    m_lines = text.split(QLatin1Char('\n'));
    if (!m_lines.isEmpty() && m_lines.last().isEmpty())
        m_lines.removeLast();
    for (QString &line : m_lines) {
        if (line.endsWith(QLatin1Char('\r')))
            line.chop(1);
    }

    parse();
    m_modified = false;
    return true;
}

QString LuaFile::fileName() const
{
    return QFileInfo(m_path).fileName();
}

int LuaFile::byteSize() const
{
    return QFileInfo(m_path).size();
}

bool LuaFile::save()
{
    if (m_path.isEmpty())
        return false;

    QString text = m_lines.join(m_newline);
    if (!m_lines.isEmpty())
        text += m_newline;

    QByteArray out;
    const Encoding enc = static_cast<Encoding>(m_encoding);
    if (enc == Encoding::Utf16LE) {
        if (m_bom)
            out.append("\xFF\xFE", 2);
        out.append(reinterpret_cast<const char *>(text.utf16()), text.size() * 2);
    } else if (enc == Encoding::Utf16BE) {
        if (m_bom)
            out.append("\xFE\xFF", 2);
        for (int i = 0; i < text.size(); ++i) {
            const ushort v = text.at(i).unicode();
            const ushort sw = static_cast<ushort>((v >> 8) | (v << 8));
            out.append(static_cast<char>(sw & 0xFF));
            out.append(static_cast<char>((sw >> 8) & 0xFF));
        }
    } else {
        if (m_bom)
            out.append("\xEF\xBB\xBF", 3);
        out.append(text.toUtf8());
    }

    QFile f(m_path);
    if (!f.open(QIODevice::WriteOnly | QIODevice::Truncate))
        return false;
    f.write(out);
    f.close();

    m_modified = false;
    return true;
}

QString LuaFile::rawText() const
{
    return m_lines.join(m_newline);
}

void LuaFile::setRawText(const QString &text)
{
    m_lines = text.split(QLatin1Char('\n'));
    if (!m_lines.isEmpty() && m_lines.last().isEmpty())
        m_lines.removeLast();
    for (QString &line : m_lines) {
        if (line.endsWith(QLatin1Char('\r')))
            line.chop(1);
    }
    parse();
    m_modified = true;
}

QString LuaFile::value(const QString &path) const
{
    for (const LuaProp &p : m_props) {
        if (p.path == path)
            return p.value;
    }
    return QString();
}

bool LuaFile::setValue(const QString &path, const QString &value)
{
    snapshot();
    for (LuaProp &p : m_props) {
        if (p.path != path)
            continue;
        if (p.line < 0 || p.line >= m_lines.size())
            return false;

        const QString old = m_lines.at(p.line);
        static const QRegularExpression re(
            QStringLiteral(R"(^(\s*(?:local\s+)?[A-Za-z_][A-Za-z0-9_]*\s*=\s*)(.*)$)"));
        const QRegularExpressionMatch m = re.match(old);
        if (!m.hasMatch())
            return false;

        QString rhs = m.captured(2);

        // Keep a trailing comment untouched.
        QString comment;
        const int cpos = commentIndex(rhs);
        if (cpos >= 0) {
            comment = rhs.mid(cpos);
            rhs = rhs.left(cpos);
        }

        // Keep trailing whitespace and an optional trailing comma.
        int end = rhs.size();
        while (end > 0 && rhs.at(end - 1).isSpace())
            --end;
        const QString trailingWs = rhs.mid(end);
        rhs = rhs.left(end);
        const bool hadComma = rhs.endsWith(QLatin1Char(','));
        if (hadComma)
            rhs.chop(1);

        const QString newValue = p.quoted ? QStringLiteral("\"%1\"").arg(value) : value;
        m_lines[p.line] = m.captured(1) + newValue
                        + (hadComma ? QStringLiteral(",") : QString())
                        + trailingWs + comment;

        p.value = value;
        m_modified = true;
        return true;
    }
    return false;
}

void LuaFile::snapshot()
{
    if (m_lines.isEmpty())
        return;
    Snapshot s;
    s.lines = m_lines;
    s.modified = m_modified;
    m_undo.push_back(s);
    if (m_undo.size() > 100)
        m_undo.removeFirst();
    m_redo.clear();   // a new edit invalidates the redo branch
}

bool LuaFile::undo()
{
    if (m_undo.isEmpty())
        return false;

    Snapshot current;
    current.lines = m_lines;
    current.modified = m_modified;
    m_redo.push_back(current);

    const Snapshot s = m_undo.takeLast();
    m_lines = s.lines;
    parse();
    m_modified = s.modified;
    return true;
}

bool LuaFile::redo()
{
    if (m_redo.isEmpty())
        return false;

    Snapshot current;
    current.lines = m_lines;
    current.modified = m_modified;
    m_undo.push_back(current);

    const Snapshot s = m_redo.takeLast();
    m_lines = s.lines;
    parse();
    m_modified = s.modified;
    return true;
}

bool LuaFile::addProperty(const QString &key, const QString &value, const QString &table)
{
    snapshot();
    if (key.isEmpty())
        return false;

    const QString full = table.isEmpty() ? key : table + QLatin1Char('.') + key;
    for (const LuaProp &p : m_props) {
        if (p.path == full)
            return false;   // already defined
    }

    if (table.isEmpty()) {
        // Top level: append after every table has closed.
        if (!m_lines.isEmpty() && !m_lines.last().trimmed().isEmpty())
            m_lines.append(QString());
        m_lines.append(key + QStringLiteral(" = ") + value);
    } else {
        // Inside a table: put it right after the last property of that table so
        // the value lands in the right component.
        int last = -1;
        for (const LuaProp &p : m_props) {
            if (p.table == table || p.table.startsWith(table + QLatin1Char('.')))
                last = qMax(last, p.line);
        }
        if (last < 0 || last >= m_lines.size())
            return false;

        const QString ref = m_lines.at(last);
        QString indent;
        for (const QChar &c : ref) {
            if (c.isSpace())
                indent += c;
            else
                break;
        }
        m_lines.insert(last + 1, indent + key + QStringLiteral(" = ") + value + QStringLiteral(","));
    }

    parse();
    m_modified = true;
    return true;
}

QString LuaFile::textureRole(const TextureRef &t)
{
    const QString s = (t.sprite + QLatin1Char(' ') + t.value).toLower();
    if (s.contains(QLatin1String("barrel")) || s.contains(QStringLiteral("ствол")))
        return QStringLiteral("barrel");
    if (s.contains(QLatin1String("head")) || s.contains(QStringLiteral("голов")))
        return QStringLiteral("head");
    if (s.contains(QLatin1String("base")) || s.contains(QStringLiteral("основ")))
        return QStringLiteral("base");
    return QString();
}

bool LuaFile::removeProperty(const QString &path)
{
    int first = -1;
    for (const LuaProp &p : m_props) {
        if (p.path == path) {
            first = p.line;
            break;
        }
    }

    // A bare table (`ReloadBank = { … }`) has no property of its own: find the
    // line that opens it and take the whole block.
    if (first < 0 && m_tableClose.contains(path)) {
        static const QRegularExpression openRe(
            QStringLiteral(R"(^\s*%1\s*=\s*\{?\s*$)").arg(QRegularExpression::escape(path)));
        for (int i = 0; i < m_lines.size(); ++i) {
            if (openRe.match(m_lines.at(i)).hasMatch()) {
                first = i;
                break;
            }
        }
    }

    if (first < 0 || first >= m_lines.size())
        return false;

    // A parameter that opens a table goes away together with the whole table.
    int last = first;
    const int closeLine = m_tableClose.value(path, -1);
    if (closeLine > first)
        last = closeLine;

    snapshot();
    for (int i = last; i >= first; --i)
        m_lines.removeAt(i);

    // Do not leave a growing pile of blank lines behind.
    if (first < m_lines.size() && m_lines.at(first).trimmed().isEmpty()
        && first > 0 && m_lines.at(first - 1).trimmed().isEmpty()) {
        m_lines.removeAt(first);
    }

    parse();
    m_modified = true;
    return true;
}

bool LuaFile::setTexture(int line, const QString &value)
{
    snapshot();
    if (line < 0 || line >= m_lines.size())
        return false;

    static const QRegularExpression re(QStringLiteral(R"((texture\s*=\s*)([^,}]+))"));
    const QString src = m_lines.at(line);
    const QRegularExpressionMatch m = re.match(src);
    if (!m.hasMatch())
        return false;

    QString out = src;
    out.replace(m.capturedStart(2), m.capturedLength(2), value);
    m_lines[line] = out;

    parse();
    m_modified = true;
    return true;
}

int LuaFile::tableCloseLine(const QString &table) const
{
    return m_tableClose.value(table, -1);
}

bool LuaFile::hasTable(const QString &key) const
{
    return m_tableClose.contains(key);
}

bool LuaFile::addTable(const QString &key, const QVector<QPair<QString, QString>> &props)
{
    snapshot();
    if (key.isEmpty())
        return false;

    for (const LuaProp &p : m_props) {
        if (p.table == key)
            return false;   // the table already exists
    }

    if (!m_lines.isEmpty() && !m_lines.last().trimmed().isEmpty())
        m_lines.append(QString());
    m_lines.append(key + QStringLiteral(" ="));
    m_lines.append(QStringLiteral("{"));
    for (const QPair<QString, QString> &p : props)
        m_lines.append(QLatin1Char('\t') + p.first + QStringLiteral(" = ") + p.second
                       + QStringLiteral(","));
    m_lines.append(QStringLiteral("}"));

    parse();
    m_modified = true;
    return true;
}

QString LuaFile::addComponent(const QString &arrayName,
                              const QVector<QPair<QString, QString>> &props)
{
    snapshot();
    if (arrayName.isEmpty() || props.isEmpty())
        return QString();

    const int closeLine = tableCloseLine(arrayName);

    // Lists built with `table.insert(Array, { … })` have no literal table, so
    // the new entry is appended as another insert call.
    if (closeLine < 0) {
        m_lines.append(QString());
        m_lines.append(QStringLiteral("table.insert(%1,").arg(arrayName));
        m_lines.append(QStringLiteral("{"));
        for (const QPair<QString, QString> &p : props)
            m_lines.append(QLatin1Char('\t') + p.first + QStringLiteral(" = ") + p.second
                           + QStringLiteral(","));
        m_lines.append(QStringLiteral("})"));

        parse();
        m_modified = true;

        QString last;
        for (const LuaProp &p : m_props) {
            if (p.table.startsWith(arrayName + QLatin1Char('[')))
                last = p.table;
        }
        return last;
    }

    if (closeLine >= m_lines.size())
        return QString();

    // Indentation: one level deeper than the array's closing brace.
    QString base;
    for (const QChar &c : m_lines.at(closeLine)) {
        if (c.isSpace())
            base += c;
        else
            break;
    }
    const QString entryIndent = base + QLatin1Char('\t');
    const QString propIndent = entryIndent + QLatin1Char('\t');

    QStringList block;
    block << entryIndent + QStringLiteral("{");
    for (const QPair<QString, QString> &p : props)
        block << propIndent + p.first + QStringLiteral(" = ") + p.second + QStringLiteral(",");
    block << entryIndent + QStringLiteral("},");

    for (int k = block.size() - 1; k >= 0; --k)
        m_lines.insert(closeLine, block.at(k));

    parse();
    m_modified = true;

    // Report the path of the entry we just created.
    QString last;
    for (const LuaProp &p : m_props) {
        if (p.table.startsWith(arrayName + QLatin1Char('[')))
            last = p.table;
    }
    return last;
}

void LuaFile::parse()
{
    m_props.clear();
    m_textures.clear();
    m_tableClose.clear();
    m_isScript = false;
    QString currentSprite;

    static const QRegularExpression assignRe(
        QStringLiteral(R"(^\s*([A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*)\s*=\s*(.*)$)"));
    static const QRegularExpression localRe(
        QStringLiteral(R"(^\s*local\s+([A-Za-z_][A-Za-z0-9_]*))"));
    static const QRegularExpression insertRe(
        QStringLiteral(R"(^\s*table\.insert\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*,(.*)$)"));

    QVector<QString> names;   // open table names ("" -> marker frame)
    QVector<bool> skips;
    QVector<int> anonCount;
    QVector<bool> replaces;
    bool inBlock = false;

    // Forts mods build their lists imperatively:
    //   table.insert(Weapons, IndexOfWeapon("cannon") + 1, { ... })
    //   local proj = DeepCopy(base) ; proj.X = 1 ; table.insert(Projectiles, proj)
    // We model both so the editor can show and edit every entry.
    QHash<QString, int> arrayCount;        // per-array insert counter
    QHash<QString, QString> varPath;       // local variable -> "@name"
    QSet<QString> locals;

    const auto skipping = [&skips]() { return !skips.isEmpty() && skips.last(); };

    const auto pushNamed = [&](const QString &key) {
        names.push_back(key);
        skips.push_back(skipping() || ParamCatalog::isTechnicalTable(key));
        anonCount.push_back(0);
        replaces.push_back(false);
    };

    const auto pushAnon = [&]() {
        int owner = -1;
        for (int i = names.size() - 1; i >= 0; --i) {
            if (!names.at(i).isEmpty()) {
                owner = i;
                break;
            }
        }
        if (owner < 0) {
            names.push_back(QStringLiteral("[1]"));
            skips.push_back(false);
            anonCount.push_back(0);
            replaces.push_back(true);
            return;
        }
        ++anonCount[owner];
        names.push_back(names.at(owner) + QStringLiteral("[%1]").arg(anonCount.at(owner)));
        skips.push_back(skips.at(owner));
        anonCount.push_back(0);
        replaces.push_back(true);
    };

    // An entry created by `table.insert(Array, …)`: named Array[N] and used as
    // the path root for everything inside it.
    const auto pushInsertEntry = [&](const QString &arrayName, bool skip) {
        const int n = ++arrayCount[arrayName];
        names.push_back(arrayName + QStringLiteral("[%1]").arg(n));
        skips.push_back(skip);
        anonCount.push_back(0);
        replaces.push_back(true);
    };

    const auto tablePath = [&]() {
        QString path;
        for (int i = 0; i < names.size(); ++i) {
            if (replaces.at(i))
                path = names.at(i);
            else if (!names.at(i).isEmpty())
                path += (path.isEmpty() ? QString() : QStringLiteral(".")) + names.at(i);
        }
        return path;
    };

    const auto popFrames = [&](int n, int line) {
        for (int k = 0; k < n && !names.isEmpty(); ++k) {
            const QString path = tablePath();
            if (!path.isEmpty())
                m_tableClose[path] = line;
            names.removeLast();
            skips.removeLast();
            anonCount.removeLast();
            replaces.removeLast();
        }
    };

    const auto addPropAt = [&](const QString &table, const QString &key,
                               const QString &rawValue, LuaKind kind, int line) {
        if (skipping() || key.isEmpty())
            return;
        LuaProp p;
        p.key = key;
        p.table = table;
        p.path = table.isEmpty() ? key : table + QLatin1Char('.') + key;
        for (const LuaProp &e : m_props) {
            if (e.path == p.path)
                return;   // repeated assignment: keep the first
        }
        p.value = kind == LuaKind::String ? unquote(rawValue) : rawValue.trimmed();
        p.kind = kind;
        p.quoted = kind == LuaKind::String;
        p.line = line;
        m_props.push_back(p);
    };

    const auto addProp = [&](const QString &key, const QString &rawValue, LuaKind kind, int line) {
        addPropAt(tablePath(), key, rawValue, kind, line);
    };

    // Moves everything collected for a local variable into a component entry.
    const auto adoptVariable = [&](const QString &arrayName, const QString &var) {
        const auto it = varPath.constFind(var);
        if (it == varPath.constEnd())
            return false;
        const QString from = it.value();

        // Only take a number when the variable actually carries properties -
        // the same variable is often inserted twice (if/else branches).
        bool any = false;
        for (const LuaProp &p : m_props) {
            if (p.table == from || p.table.startsWith(from + QLatin1Char('.'))) {
                any = true;
                break;
            }
        }
        if (!any)
            return false;

        const int n = ++arrayCount[arrayName];
        const QString to = arrayName + QStringLiteral("[%1]").arg(n);
        bool moved = false;
        for (LuaProp &p : m_props) {
            if (p.table == from) {
                p.table = to;
            } else if (p.table.startsWith(from + QLatin1Char('.'))) {
                p.table = to + p.table.mid(from.size());
            } else {
                continue;
            }
            p.path = p.table + QLatin1Char('.') + p.key;
            moved = true;
        }
        return moved;
    };

    // Counts braces outside string literals.
    const auto countBraces = [](const QString &line, int &opens, int &closes) {
        bool inSingle = false;
        bool inDouble = false;
        for (const QChar &c : line) {
            if (c == QLatin1Char('"') && !inSingle)
                inDouble = !inDouble;
            else if (c == QLatin1Char('\'') && !inDouble)
                inSingle = !inSingle;
            else if (!inSingle && !inDouble) {
                if (c == QLatin1Char('{'))
                    ++opens;
                else if (c == QLatin1Char('}'))
                    ++closes;
            }
        }
    };

    for (int i = 0; i < m_lines.size(); ++i) {
        const QString t = cleanLine(m_lines.at(i), inBlock).trimmed();
        if (t.isEmpty())
            continue;

        if (t.contains(QLatin1String("function")) || t.contains(QLatin1String("RegisterApplyMod")))
            m_isScript = true;

        // Texture references live inside the (skipped) Sprites table. They are
        // what the "Текстуры" section edits, so collect them separately.
        if (!names.isEmpty() && names.first() == QLatin1String("Sprites")) {
            static const QRegularExpression texRe(
                QStringLiteral(R"(texture\s*=\s*([^,}]+))"));
            auto texIt = texRe.globalMatch(t);
            while (texIt.hasNext()) {
                const QRegularExpressionMatch tm = texIt.next();
                TextureRef r;
                r.sprite = currentSprite;
                r.value = tm.captured(1).trimmed();
                r.line = i;
                m_textures.push_back(r);
            }
            static const QRegularExpression spriteNameRe(
                QStringLiteral(R"re(^\s*Name\s*=\s*"([^"]*)")re"));
            const QRegularExpressionMatch nm = spriteNameRe.match(t);
            if (nm.hasMatch())
                currentSprite = nm.captured(1);
        }

        int consumedBrace = 0;
        bool handled = false;

        // ---- table.insert(Array, …) -----------------------------------------
        const QRegularExpressionMatch im = insertRe.match(t);
        if (im.hasMatch()) {
            handled = true;
            const QString arrayName = im.captured(1);
            const QString rest = im.captured(2);
            const bool technical = ParamCatalog::isTechnicalTable(arrayName);

            // Text after the last top-level comma = the payload argument.
            int depth = 0;
            int lastComma = -1;
            bool inS = false;
            bool inD = false;
            for (int k = 0; k < rest.size(); ++k) {
                const QChar c = rest.at(k);
                if (c == QLatin1Char('"') && !inS)
                    inD = !inD;
                else if (c == QLatin1Char('\'') && !inD)
                    inS = !inS;
                else if (!inS && !inD) {
                    if (c == QLatin1Char('(') || c == QLatin1Char('{'))
                        ++depth;
                    else if (c == QLatin1Char(')') || c == QLatin1Char('}'))
                        --depth;
                    else if (c == QLatin1Char(',') && depth == 0)
                        lastComma = k;
                }
            }
            QString payload = rest.mid(lastComma + 1).trimmed();
            while (payload.endsWith(QLatin1Char(')')))
                payload.chop(1);
            payload = payload.trimmed();

            if (payload.isEmpty()) {
                // The payload starts on one of the following lines.
                int j = i + 1;
                bool blk = false;
                while (j < m_lines.size()) {
                    const QString next = cleanLine(m_lines.at(j), blk).trimmed();
                    if (next.isEmpty()) {
                        ++j;
                        continue;
                    }
                    if (next.startsWith(QLatin1Char('{'))) {
                        pushInsertEntry(arrayName, technical);
                    } else if (!next.contains(QLatin1Char('(')) && !technical) {
                        adoptVariable(arrayName, next);
                    }
                    i = j;
                    break;
                }
            } else if (payload.startsWith(QLatin1Char('{'))) {
                const int close = payload.lastIndexOf(QLatin1Char('}'));
                if (close <= 0) {
                    pushInsertEntry(arrayName, technical);
                    consumedBrace = 1;
                }
            } else if (!technical) {
                static const QRegularExpression identRe(QStringLiteral(R"(^[A-Za-z_][A-Za-z0-9_]*$)"));
                if (identRe.match(payload).hasMatch())
                    adoptVariable(arrayName, payload);
            }
        }

        // ---- local declarations ---------------------------------------------
        if (!handled) {
            const QRegularExpressionMatch lm = localRe.match(t);
            if (lm.hasMatch()) {
                const QString var = lm.captured(1);
                locals.insert(var);
                varPath[var] = QStringLiteral("@") + var;
                const int eq = t.indexOf(QLatin1Char('='));
                if (eq > 0) {
                    const QString rhs = t.mid(eq + 1).trimmed();
                    if (rhs.startsWith(QLatin1Char('{')) && rhs.lastIndexOf(QLatin1Char('}')) <= 0) {
                        pushNamed(varPath.value(var));
                        consumedBrace = 1;
                    } else if (names.isEmpty() && !rhs.isEmpty()) {
                        // Top-level tuning constant (`local FRAG_COUNT = 24`):
                        // show it so it can be edited without touching the code.
                        const LuaKind k = kindOf(rhs);
                        if (k == LuaKind::Number || k == LuaKind::Bool || k == LuaKind::String)
                            addPropAt(QString(), var, rhs, k, i);
                    }
                }
            }
        }

        // ---- assignments ------------------------------------------------------
        if (!handled && !t.startsWith(QLatin1Char('}')) && !t.startsWith(QLatin1String("local"))) {
            static const QStringList kKeywords = {
                QStringLiteral("for"),    QStringLiteral("if"),      QStringLiteral("while"),
                QStringLiteral("return"), QStringLiteral("elseif"),  QStringLiteral("else"),
                QStringLiteral("until"),  QStringLiteral("then"),    QStringLiteral("end"),
                QStringLiteral("repeat"), QStringLiteral("function"),
            };
            bool keywordLine = false;
            for (const QString &kw : kKeywords) {
                if (t.startsWith(kw)
                    && (t.size() == kw.size() || !t.at(kw.size()).isLetterOrNumber())) {
                    keywordLine = true;
                    break;
                }
            }

            if (!keywordLine) {
                const QRegularExpressionMatch m = assignRe.match(t);
                if (m.hasMatch()) {
                    handled = true;
                    const QString lhs = m.captured(1);
                    QString rhs = m.captured(2).trimmed();
                    if (rhs.endsWith(QLatin1Char(',')))
                        rhs.chop(1);
                    rhs = rhs.trimmed();

                    const QString root = lhs.section(QLatin1Char('.'), 0, 0);
                    const QString sub = lhs.section(QLatin1Char('.'), 1);

                    if (locals.contains(root)) {
                        // Field of a local variable: `proj.SaveName = "…"`.
                        if (sub.isEmpty()) {
                            // Plain reassignment of the variable itself - ignore.
                        } else if (rhs.startsWith(QLatin1Char('{'))
                                   && rhs.lastIndexOf(QLatin1Char('}')) <= 0) {
                            pushNamed(varPath.value(root) + QLatin1Char('.') + sub);
                            consumedBrace = 1;
                        } else {
                            addPropAt(varPath.value(root), sub, rhs, kindOf(rhs), i);
                        }
                    } else if (rhs.isEmpty()) {
                        // `Key =` with the value on a following line.
                        int j = i + 1;
                        bool blk = false;
                        while (j < m_lines.size()) {
                            const QString next = cleanLine(m_lines.at(j), blk).trimmed();
                            if (next.isEmpty()) {
                                ++j;
                                continue;
                            }
                            if (next.startsWith(QLatin1Char('{'))) {
                                const int close = next.lastIndexOf(QLatin1Char('}'));
                                if (close > 0) {
                                    const QString inner = next.mid(1, close - 1).trimmed();
                                    if (!inner.isEmpty())
                                        addProp(lhs, QStringLiteral("{ %1 }").arg(inner),
                                                LuaKind::List, j);
                                } else {
                                    pushNamed(lhs);
                                }
                                i = j;
                            }
                            break;
                        }
                    } else if (rhs.startsWith(QLatin1Char('{'))) {
                        const int close = rhs.lastIndexOf(QLatin1Char('}'));
                        if (close > 0) {
                            const QString inner = rhs.mid(1, close - 1).trimmed();
                            if (!inner.isEmpty())
                                addProp(lhs, QStringLiteral("{ %1 }").arg(inner), LuaKind::List, i);
                        } else {
                            pushNamed(lhs);
                            consumedBrace = 1;
                        }
                    } else if (!(lhs.size() >= 3 && lhs == lhs.toUpper())) {
                        addProp(lhs, rhs, kindOf(rhs), i);
                    }
                }
            }
        }

        // ---- keep the table stack balanced -----------------------------------
        int opens = 0;
        int closes = 0;
        countBraces(t, opens, closes);
        const int net = opens - closes - consumedBrace;
        if (net > 0) {
            for (int k = 0; k < net; ++k)
                pushAnon();
        } else if (net < 0) {
            popFrames(-net, i);
        }
    }
}
