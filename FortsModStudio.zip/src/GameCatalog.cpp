#include "GameCatalog.h"

#include "LuaFile.h"

#include <QDir>
#include <QDirIterator>
#include <QFile>
#include <QRegularExpression>
#include <QSet>

GameCatalog &GameCatalog::instance()
{
    static GameCatalog catalog;
    return catalog;
}

void GameCatalog::setDataPath(const QString &dataPath)
{
    if (m_dataPath == dataPath && m_loaded)
        return;
    m_dataPath = dataPath;
    reload();
}

void GameCatalog::reload()
{
    m_projectiles.clear();
    m_projectileTypes.clear();
    m_modCategories.clear();
    m_effects.clear();
    m_technologies.clear();
    m_loaded = false;

    if (m_dataPath.isEmpty() || !QDir(m_dataPath).exists())
        return;

    // ---- projectiles: SaveName / ProjectileType from projectile_list.lua ----
    LuaFile list;
    if (list.load(m_dataPath + QStringLiteral("/weapons/projectile_list.lua"))) {
        QSet<QString> names;
        QSet<QString> types;
        for (const LuaProp &p : list.properties()) {
            if (p.kind != LuaKind::String)
                continue;
            if (p.key == QLatin1String("SaveName"))
                names.insert(p.value);
            else if (p.key == QLatin1String("ProjectileType"))
                types.insert(p.value);
        }
        m_projectiles = QStringList(names.begin(), names.end());
        m_projectiles.sort(Qt::CaseInsensitive);
        m_projectileTypes = QStringList(types.begin(), types.end());
        m_projectileTypes.sort(Qt::CaseInsensitive);
    }

    // ---- mod categories used by the installed mods --------------------------
    QSet<QString> categories;
    QDir modsDir(m_dataPath + QStringLiteral("/mods"));
    const QFileInfoList mods =
        modsDir.entryInfoList(QDir::Dirs | QDir::NoDotAndDotDot, QDir::Name);
    static const QRegularExpression catRe(
        QStringLiteral(R"re(\bCategory\s*=\s*"([^"]*)")re"));
    for (const QFileInfo &mod : mods) {
        LuaFile ml;
        if (!ml.load(mod.absoluteFilePath() + QStringLiteral("/mod.lua")))
            continue;
        const QRegularExpressionMatch m = catRe.match(ml.rawText());
        if (m.hasMatch())
            categories.insert(m.captured(1));
    }
    m_modCategories = QStringList(categories.begin(), categories.end());
    m_modCategories.sort(Qt::CaseInsensitive);

    // ---- effect files the modder can point FireEffect/DestroyEffect at ------
    {
        const QString effectsDir = m_dataPath + QStringLiteral("/effects");
        QDirIterator it(effectsDir, QStringList{QStringLiteral("*.lua")}, QDir::Files,
                        QDirIterator::Subdirectories);
        while (it.hasNext()) {
            it.next();
            const QString rel = QDir(effectsDir).relativeFilePath(it.filePath());
            m_effects << QStringLiteral("\"effects/%1\"").arg(rel);
        }
        m_effects.sort(Qt::CaseInsensitive);
    }

    reloadTechnologies();

    m_loaded = true;
}

void GameCatalog::reloadTechnologies()
{
    // SaveName of every object the game ships: "workshop", "factory", "mine"…
    // Those are exactly the values a Prerequisite / Tech may point at.
    QSet<QString> names;
    static const QRegularExpression re(QStringLiteral(R"re(SaveName\s*=\s*"([^"]*)")re"));
    const QStringList files{
        m_dataPath + QStringLiteral("/devices/device_list.lua"),
        m_dataPath + QStringLiteral("/devices/ammo_list.lua"),
        m_dataPath + QStringLiteral("/weapons/weapon_list.lua"),
        m_dataPath + QStringLiteral("/weapons/projectile_list.lua"),
    };
    for (const QString &path : files) {
        QFile f(path);
        if (!f.open(QIODevice::ReadOnly))
            continue;
        const QString text = QString::fromUtf8(f.readAll());
        auto it = re.globalMatch(text);
        while (it.hasNext())
            names.insert(QStringLiteral("\"%1\"").arg(it.next().captured(1)));
    }
    m_technologies = QStringList(names.begin(), names.end());
    m_technologies.sort(Qt::CaseInsensitive);
}

QStringList GameCatalog::choicesFor(const QString &key) const
{
    if (!m_loaded)
        return QStringList();

    if (key == QLatin1String("Projectile"))
        return m_projectiles;
    if (key == QLatin1String("ProjectileType"))
        return m_projectileTypes;
    if (key == QLatin1String("Category"))
        return m_modCategories;

    return QStringList();
}
