#pragma once

#include "LuaFile.h"

#include <QMap>
#include <QSet>
#include <QString>
#include <QVector>

// One row in the mod's file tree.
struct ModEntry {
    QString name;     // shown text, e.g. "cannon.lua"
    QString relPath;  // "weapons/cannon.lua" (empty for the root)
    bool isDir = false;
    int count = -1;   // number of direct children for directories
    QVector<ModEntry> children;
};

// Represents an opened Forts mod folder (…/mods/<modname>).
class ModProject
{
public:
    bool open(const QString &root);
    bool isOpen() const { return !m_root.isEmpty(); }

    QString name() const { return m_name; }
    QString version() const { return m_version; }
    QString rootPath() const { return m_root; }
    const ModEntry &tree() const { return m_tree; }

    int dirtyCount() const { return m_dirty.size(); }
    bool isDirty(const QString &relPath) const { return m_dirty.contains(relPath); }
    void markDirty(const QString &relPath) { m_dirty.insert(relPath); }
    // Sets the changed flag explicitly (undo may go back to a clean state).
    void setDirty(const QString &relPath, bool dirty)
    {
        if (dirty)
            m_dirty.insert(relPath);
        else
            m_dirty.remove(relPath);
    }
    void clearDirty() { m_dirty.clear(); }

    // Cached, editable Lua file for a path relative to the mod root.
    LuaFile &file(const QString &relPath);

    // Persists every modified Lua file.
    bool saveAll(QStringList *errors = nullptr);

    // Expressions for every image inside the mod, e.g.
    // `path .. "/weapons/30mmCannon/base.png"` - used by the texture pick-lists.
    QStringList textureChoices() const;

    // Relative paths of the mod's weapon .lua files (used by weapon_list.lua).
    QStringList weaponFiles() const;

    // Relative paths of the mod's device .lua files (used by device_list.lua).
    QStringList deviceFiles() const;

    // Expressions for the mod's own effect files.
    QStringList effectChoices() const;

    // SaveName values declared by the mod itself (its weapons and devices).
    // Used by Prerequisite / Tech pick-lists so a freshly added device shows up.
    QStringList technologyChoices() const;

    // Root of the game's data folder; used to tell overrides from new files.
    void setGameDataPath(const QString &dataPath) { m_gameData = dataPath; }
    bool overridesBaseFile(const QString &relPath) const;

    // ---- presentation helpers -------------------------------------------------
    static QString categoryForFolder(const QString &folder);
    static QString displayNameForFile(const QString &relPath);
    static QString typeLabelFor(const QString &relPath);
    static QString humanSize(qint64 bytes);
    static QString iconKindFor(const QString &relPath); // "lua" | "image" | "file" | "dir"

private:
    void scanDir(const QString &absDir, const QString &relDir, ModEntry &out);
    void readModMeta();

    QString m_root;
    QString m_name;
    QString m_version;
    QString m_gameData;
    ModEntry m_tree;
    QSet<QString> m_dirty;
    QMap<QString, LuaFile> m_cache;
    mutable QStringList m_textureChoices;
};
