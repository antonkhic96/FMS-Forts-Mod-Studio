#include "ParamCatalog.h"

#include <QHash>
#include <QRegularExpression>
#include <QFileInfo>
#include <QSet>

namespace {

struct Info {
    const char *category;
    const char *ru;
};

// Exact key -> (section, Russian label). Covers the parameter names used by the
// Forts base game (weapons, devices, materials), so any mod reusing them is
// translated automatically.
const QHash<QString, Info> &dict()
{
    static const QHash<QString, Info> d = {
        // ---- Основные ----
        {QStringLiteral("Name"), {"general", "Название"}},
        {QStringLiteral("SaveName"), {"general", "Внутреннее имя"}},
        {QStringLiteral("Scale"), {"general", "Масштаб"}},
        {QStringLiteral("Icon"), {"general", "Иконка"}},
        {QStringLiteral("Mesh"), {"general", "Модель"}},
        {QStringLiteral("Detail"), {"general", "Детализация"}},

        // ---- Прочность ----
        {QStringLiteral("HitPoints"), {"health", "Прочность"}},
        {QStringLiteral("EMPVulnerability"), {"health", "Уязвимость к ЭМИ"}},

        // ---- Стрельба ----
        {QStringLiteral("ReloadTime"), {"firing", "Время перезарядки"}},
        {QStringLiteral("ReloadTimeIncludesBurst"), {"ammo", "Перезарядка с очередью"}},
        // ---- Магазин (ReloadBank) ----
        {QStringLiteral("ReloadBank"), {"bank", "Магазин"}},
        {QStringLiteral("Max"), {"bank", "Ёмкость магазина"}},
        {QStringLiteral("BaseMult"), {"bank", "Базовый множитель"}},
        {QStringLiteral("IndexMult"), {"bank", "Множитель за выстрел"}},
        {QStringLiteral("EnergyMult"), {"bank", "Множитель энергии"}},
        {QStringLiteral("MetalMult"), {"bank", "Множитель металла"}},
        {QStringLiteral("MinFireSpeed"), {"firing", "Мин. скорость снаряда"}},
        {QStringLiteral("MaxFireSpeed"), {"firing", "Макс. скорость снаряда"}},
        {QStringLiteral("MinFireRadius"), {"firing", "Мин. дальность"}},
        {QStringLiteral("MaxFireRadius"), {"firing", "Макс. дальность"}},
        {QStringLiteral("MinFireAngle"), {"firing", "Мин. угол наведения"}},
        {QStringLiteral("MaxFireAngle"), {"firing", "Макс. угол наведения"}},
        {QStringLiteral("DefaultFireAngle"), {"firing", "Угол по умолчанию"}},
        {QStringLiteral("ForceFireAngle"), {"firing", "Принудительный угол"}},
        {QStringLiteral("MaxFireClamp"), {"firing", "Ограничение угла"}},
        {QStringLiteral("FireStdDev"), {"firing", "Разброс"}},
        {QStringLiteral("FireStdDevAuto"), {"firing", "Разброс (авто)"}},
        {QStringLiteral("FireDelay"), {"firing", "Задержка выстрела"}},
        {QStringLiteral("Recoil"), {"firing", "Отдача"}},
        {QStringLiteral("KickbackMean"), {"firing", "Средний откат"}},
        {QStringLiteral("KickbackStdDev"), {"firing", "Разброс отката"}},
        {QStringLiteral("PanDuration"), {"firing", "Длительность панорамы"}},
        {QStringLiteral("MouseSensitivityFactor"), {"firing", "Чувствительность мыши"}},
        {QStringLiteral("BarrelLength"), {"firing", "Длина ствола"}},
        {QStringLiteral("MinFireClearance"), {"firing", "Мин. зазор выстрела"}},
        {QStringLiteral("FireClearanceOffsetInner"), {"firing", "Зазор изнутри"}},
        {QStringLiteral("FireClearanceOffsetOuter"), {"firing", "Зазор снаружи"}},
        {QStringLiteral("RoundsEachBurst"), {"ammo", "Выстрелов в очереди"}},
        {QStringLiteral("RoundPeriod"), {"ammo", "Интервал очереди"}},
        {QStringLiteral("AttractZoomOutDuration"), {"firing", "Отъезд камеры"}},
        {QStringLiteral("ShowFireAngle"), {"firing", "Показывать угол"}},
        {QStringLiteral("ShowFireSpeed"), {"firing", "Показывать скорость"}},
        {QStringLiteral("ShowAimingGizmo"), {"firing", "Показывать прицел"}},
        {QStringLiteral("HoldToFire"), {"firing", "Удержание для выстрела"}},
        {QStringLiteral("AutofireCloseDoorTicks"), {"firing", "Автозакрытие двери"}},
        {QStringLiteral("DoorCloseDelay"), {"firing", "Задержка двери"}},
        {QStringLiteral("MaxTestDistance"), {"firing", "Макс. дистанция теста"}},
        {QStringLiteral("MinTestDistance"), {"firing", "Мин. дистанция теста"}},
        {QStringLiteral("BarrelRecoilLimit"), {"firing", "Предел отката ствола"}},
        {QStringLiteral("BarrelRecoilSpeed"), {"firing", "Скорость отката ствола"}},
        {QStringLiteral("BarrelReturnForce"), {"firing", "Возврат ствола"}},
        {QStringLiteral("StandardMinLength"), {"firing", "Мин. длина"}},
        {QStringLiteral("StandardMaxLength"), {"firing", "Макс. длина"}},
        {QStringLiteral("StandardMaxLinkLength"), {"firing", "Макс. длина связи"}},
        {QStringLiteral("StandardMaxUpAngle"), {"firing", "Макс. угол вверх"}},
        {QStringLiteral("MaxUpAngle"), {"firing", "Макс. угол вверх"}},

        // ---- Урон ----
        {QStringLiteral("Damage"), {"damage", "Урон"}},
        {QStringLiteral("DamageRadius"), {"damage", "Радиус урона"}},
        {QStringLiteral("Incendiary"), {"damage", "Поджог"}},
        {QStringLiteral("IncendiaryRadius"), {"damage", "Радиус поджога"}},
        {QStringLiteral("IncendiaryRadiusHeated"), {"damage", "Радиус поджога (нагрев)"}},
        {QStringLiteral("DeviceSplashDamage"), {"damage", "Урон по устройствам"}},
        {QStringLiteral("DeviceSplashDamageMaxRadius"), {"damage", "Радиус урона по устройствам"}},
        {QStringLiteral("DeviceSplashDamageDelay"), {"damage", "Задержка урона"}},
        {QStringLiteral("StructureSplashDamage"), {"damage", "Урон по постройкам"}},
        {QStringLiteral("StructureSplashDamageMaxRadius"), {"damage", "Радиус урона по постройкам"}},
        {QStringLiteral("UnderwaterDamageRate"), {"damage", "Урон под водой"}},
        {QStringLiteral("UnderwaterDamageMinDepth"), {"damage", "Мин. глубина урона"}},
        {QStringLiteral("UnderwaterDamageMinAngle"), {"damage", "Мин. угол урона"}},
        {QStringLiteral("UnderwaterDamageMaxStructureRadius"), {"damage", "Радиус урона под водой"}},
        {QStringLiteral("BlockPenetration"), {"damage", "Блокирует пробитие"}},

        // ---- Перегрев ----
        {QStringLiteral("CanOverheat"), {"overheat", "Включить перегрев"}},
        {QStringLiteral("HeatPeriod"), {"overheat", "Время нагрева"}},
        {QStringLiteral("CoolPeriod"), {"overheat", "Время остывания"}},
        {QStringLiteral("CoolPeriodOverheated"), {"overheat", "Остывание после перегрева"}},
        {QStringLiteral("Overheated"), {"overheat", "Перегрето"}},
        {QStringLiteral("CooldownTime"), {"overheat", "Время остывания"}},
        {QStringLiteral("FullCooldownTime"), {"overheat", "Время полного остывания"}},
        {QStringLiteral("Cooldown"), {"overheat", "Остывание"}},

        // ---- Снаряд ----
        {QStringLiteral("Projectile"), {"projectile", "Снаряд"}},
        {QStringLiteral("ProjectileType"), {"projectile", "Тип снаряда"}},
        {QStringLiteral("ProjectileMass"), {"projectile", "Масса снаряда"}},
        {QStringLiteral("ProjectileDrag"), {"projectile", "Сопротивление снаряда"}},
        {QStringLiteral("ProjectileDamage"), {"projectile", "Урон снаряда"}},
        {QStringLiteral("ProjectileThickness"), {"projectile", "Толщина снаряда"}},
        {QStringLiteral("ProjectileShootDownRadius"), {"projectile", "Радиус перехвата"}},
        {QStringLiteral("DeflectedByShields"), {"projectile", "Отражается щитами"}},
        {QStringLiteral("ExplodeOnTouch"), {"projectile", "Взрыв при касании"}},
        {QStringLiteral("SpeedIndicatorFactor"), {"projectile", "Индикатор скорости"}},
        {QStringLiteral("BeamDuration"), {"projectile", "Длительность луча"}},
        {QStringLiteral("BeamDamageMultiplier"), {"projectile", "Множитель урона луча"}},
        {QStringLiteral("BeamThicknessMultiplier"), {"projectile", "Толщина луча"}},
        {QStringLiteral("BeamScrollRate"), {"projectile", "Прокрутка луча"}},
        {QStringLiteral("BeamTileRate"), {"projectile", "Частота плитки луча"}},
        {QStringLiteral("BeamEndEffectTime"), {"projectile", "Время конца луча"}},
        {QStringLiteral("BeamsCutOffEffects"), {"projectile", "Обрезать эффекты лучей"}},
        {QStringLiteral("BeamsRecycleEffects"), {"projectile", "Переиспользовать эффекты"}},
        {QStringLiteral("LaserScale"), {"projectile", "Масштаб лазера"}},
        {QStringLiteral("LaserSightDashed"), {"projectile", "Прицел (пунктир)"}},
        {QStringLiteral("LaserSightSolid"), {"projectile", "Прицел (сплошной)"}},
        {QStringLiteral("MissileDisruptionMin"), {"projectile", "Мин. срыв наведения"}},
        {QStringLiteral("MissileDisruptionStdDevMin"), {"projectile", "Срыв: мин. отклонение"}},
        {QStringLiteral("MissileDisruptionStdDevMax"), {"projectile", "Срыв: макс. отклонение"}},

        // ---- Экономика ----
        {QStringLiteral("WeaponMass"), {"economy", "Масса оружия"}},
        {QStringLiteral("Mass"), {"economy", "Масса"}},
        {QStringLiteral("Cost"), {"economy", "Стоимость"}},
        {QStringLiteral("EnergyProductionRate"), {"economy", "Выработка энергии"}},
        {QStringLiteral("MetalProductionRate"), {"economy", "Выработка металла"}},
        {QStringLiteral("EnergyStorageCapacity"), {"economy", "Запас энергии"}},
        {QStringLiteral("MetalStorageCapacity"), {"economy", "Запас металла"}},
        {QStringLiteral("EnergyFireCost"), {"economy", "Энергия на выстрел"}},
        {QStringLiteral("MetalFireCost"), {"economy", "Металл на выстрел"}},
        {QStringLiteral("EnergyBuildCost"), {"economy", "Энергия на постройку"}},
        {QStringLiteral("MetalBuildCost"), {"economy", "Металл на постройку"}},
        {QStringLiteral("EnergyRepairCost"), {"economy", "Энергия на ремонт"}},
        {QStringLiteral("MetalRepairCost"), {"economy", "Металл на ремонт"}},
        {QStringLiteral("EnergyReclaim"), {"economy", "Возврат энергии"}},
        {QStringLiteral("MetalReclaim"), {"economy", "Возврат металла"}},
        {QStringLiteral("NoReclaim"), {"economy", "Без возврата"}},
        {QStringLiteral("BuildTimeComplete"), {"economy", "Время постройки"}},
        {QStringLiteral("ScrapPeriod"), {"economy", "Период разбора"}},
        {QStringLiteral("Ammo"), {"economy", "Боезапас"}},
        {QStringLiteral("Range"), {"economy", "Дальность"}},
        {QStringLiteral("Speed"), {"economy", "Скорость"}},
        {QStringLiteral("Health"), {"economy", "Прочность"}},

        // ---- Ветер и вращение ----
        {QStringLiteral("MinWindEfficiency"), {"wind", "Мин. эффективность ветра"}},
        {QStringLiteral("MaxWindHeight"), {"wind", "Макс. высота ветра"}},
        {QStringLiteral("MaxRotationalSpeed"), {"wind", "Макс. скорость вращения"}},
        {QStringLiteral("MinWindAngle"), {"wind", "Мин. угол ветра"}},
        {QStringLiteral("MaxWindAngle"), {"wind", "Макс. угол ветра"}},
        {QStringLiteral("MinWindCrossFlow"), {"wind", "Мин. поперечный поток"}},
        {QStringLiteral("MinWindNoCrossFlow"), {"wind", "Порог поперечного потока"}},

        // ---- Поведение ----
        {QStringLiteral("Enabled"), {"behavior", "Включено"}},
        {QStringLiteral("Disabled"), {"behavior", "Отключено"}},
        {QStringLiteral("Visible"), {"behavior", "Видимость"}},
        {QStringLiteral("CanFlip"), {"behavior", "Можно переворачивать"}},
        {QStringLiteral("Inverted"), {"behavior", "Перевёрнутый"}},
        {QStringLiteral("TeamOwned"), {"behavior", "Принадлежит команде"}},
        {QStringLiteral("ClaimsStructures"), {"behavior", "Захватывает постройки"}},
        {QStringLiteral("Repairable"), {"behavior", "Ремонтируемый"}},
        {QStringLiteral("BuildOnGroundOnly"), {"behavior", "Только на земле"}},
        {QStringLiteral("IgnorePlatformSlope"), {"behavior", "Игнорировать наклон"}},
        {QStringLiteral("DisruptionBlocksFire"), {"behavior", "Блокировка огня"}},
        {QStringLiteral("ChildrenInFront"), {"behavior", "Дети спереди"}},
        {QStringLiteral("ChildrenBehind"), {"behavior", "Дети позади"}},
        {QStringLiteral("Prerequisite"), {"behavior", "Требование"}},
        {QStringLiteral("PrerequisiteAlt"), {"behavior", "Запасное требование"}},
        {QStringLiteral("GroupButton"), {"behavior", "Кнопка группы"}},
        {QStringLiteral("Priority"), {"behavior", "Приоритет"}},
        {QStringLiteral("Category"), {"behavior", "Категория"}},
        {QStringLiteral("Selectable"), {"behavior", "Выбираемый"}},
        {QStringLiteral("UserData"), {"behavior", "Пользовательские данные"}},
        {QStringLiteral("RequiresHighSeas"), {"behavior", "Требует High Seas"}},
        {QStringLiteral("RequiresMoonshot"), {"behavior", "Требует Moonshot"}},
        {QStringLiteral("ExcludeUnlockAll"), {"behavior", "Исключить из «открыть всё»"}},
        {QStringLiteral("SmokeEmitter"), {"effects", "Источник дыма"}},
        {QStringLiteral("ReloadFramePeriod"), {"firing", "Период кадра перезарядки"}},
        {QStringLiteral("Armor"), {"health", "Броня"}},
        {QStringLiteral("ReflectionMomentumThreshold"), {"health", "Порог отражения"}},
        {QStringLiteral("PenetrationMomentumThreshold"), {"health", "Порог пробития"}},
        {QStringLiteral("BuildQueueConcurrent"), {"economy", "Одновременная постройка"}},
        {QStringLiteral("UnderConstruction"), {"visual", "Строится"}},
        {QStringLiteral("RenderOrder"), {"visual", "Порядок отрисовки"}},
        // --- записи устройств в меню постройки ---
        {QStringLiteral("FileName"), {"general", "Файл объекта"}},
        {QStringLiteral("ShowDetails"), {"visual", "Показывать подробности"}},
        {QStringLiteral("AllowOverlap"), {"behavior", "Разрешить перекрытие"}},
        {QStringLiteral("ScoreWeight"), {"economy", "Вес в счёте"}},
        {QStringLiteral("SpotterTarget"), {"behavior", "Цель наводчика"}},
        {QStringLiteral("AlignToCursorNormal"), {"behavior", "Выравнивать по курсору"}},
        {QStringLiteral("BuildOnOreOnly"), {"behavior", "Только на руде"}},
        {QStringLiteral("CanMove"), {"behavior", "Можно перемещать"}},
        {QStringLiteral("HasDummy"), {"visual", "Есть макет"}},
        {QStringLiteral("PopulationCap"), {"economy", "Лимит населения"}},
        {QStringLiteral("Tech"), {"behavior", "Технология"}},
        {QStringLiteral("ValidityFlags"), {"behavior", "Флаги размещения"}},
        {QStringLiteral("MetalReclaimMin"), {"economy", "Возврат металла (мин)"}},
        {QStringLiteral("MetalReclaimMax"), {"economy", "Возврат металла (макс)"}},
        {QStringLiteral("EnergyReclaimMin"), {"economy", "Возврат энергии (мин)"}},
        {QStringLiteral("EnergyReclaimMax"), {"economy", "Возврат энергии (макс)"}},
        {QStringLiteral("Upgrades"), {"behavior", "Улучшения"}},
        {QStringLiteral("Detail"), {"visual", "Спрайт подробностей"}},
        // --- оружие: основные и служебные поля файла ---
        {QStringLiteral("Name"), {"general", "Название"}},
        {QStringLiteral("Tip"), {"general", "Подсказка"}},
        {QStringLiteral("RecessionBox"), {"visual", "Зона отката"}},
        {QStringLiteral("CanUpdateAimWhileFiring"), {"firing", "Наводить во время очереди"}},
        {QStringLiteral("ClearanceAngleStdDevFactor"), {"firing", "Разброс угла зазора"}},
        {QStringLiteral("FireEndEffect"), {"effects", "Эффект конца стрельбы"}},
        {QStringLiteral("MaxUpAngle"), {"behavior", "Максимальный угол подъёма"}},
        {QStringLiteral("ObserverBuildEvent"), {"behavior", "Событие постройки для наблюдателя"}},
        {QStringLiteral("MaxSpotterAssistance"), {"behavior", "Помощь наводчика"}},
        {QStringLiteral("CompatibleGroupTypes"), {"behavior", "Совместимые группы"}},
        {QStringLiteral("IsBehindDevices"), {"visual", "Рисовать позади устройств"}},
        {QStringLiteral("DeviceSplashDamage"), {"damage", "Урон по устройствам"}},
        {QStringLiteral("DeviceSplashDamageMaxRadius"), {"damage", "Радиус урона по устройствам"}},
        {QStringLiteral("DeviceSplashDamageDelay"), {"damage", "Задержка урона по устройствам"}},
        {QStringLiteral("StructureSplashDamage"), {"damage", "Урон по постройкам"}},
        {QStringLiteral("StructureSplashDamageMaxRadius"), {"damage", "Радиус урона по постройкам"}},
        {QStringLiteral("ButtonSpriteBottom"), {"visual", "Низ кнопки"}},
        {QStringLiteral("GroupButtonSpriteBottom"), {"visual", "Низ кнопки группы"}},
        {QStringLiteral("NeutralColour"), {"visual", "Нейтральный цвет"}},
        {QStringLiteral("HurtEffect"), {"effects", "Эффект урона"}},
        {QStringLiteral("HurtMinDelay"), {"effects", "Мин. задержка эффекта урона"}},
        {QStringLiteral("TrailEffect"), {"effects", "Эффект следа"}},
        {QStringLiteral("SelectEffect"), {"effects", "Эффект выбора"}},

        // ---- Эффекты ----
        {QStringLiteral("FireEffect"), {"effects", "Эффект выстрела"}},
        {QStringLiteral("FireEndEffect"), {"effects", "Эффект конца огня"}},
        {QStringLiteral("FireRetriggerEffect"), {"effects", "Эффект повтора выстрела"}},
        {QStringLiteral("RetriggerFireEffect"), {"effects", "Повторять эффект выстрела"}},
        {QStringLiteral("RetriggerFireEffectOnce"), {"effects", "Повторять один раз"}},
        {QStringLiteral("ConstructEffect"), {"effects", "Эффект постройки"}},
        {QStringLiteral("CompleteEffect"), {"effects", "Эффект завершения"}},
        {QStringLiteral("DestroyEffect"), {"effects", "Эффект разрушения"}},
        {QStringLiteral("DestroyUnderwaterEffect"), {"effects", "Эффект разрушения под водой"}},
        {QStringLiteral("ShellEffect"), {"effects", "Эффект гильзы"}},
        {QStringLiteral("ReloadEffect"), {"effects", "Эффект перезарядки"}},
        {QStringLiteral("ReloadEffectOffset"), {"effects", "Смещение эффекта перезарядки"}},
        {QStringLiteral("TrailEffect"), {"effects", "Эффект следа"}},
        {QStringLiteral("SelectEffect"), {"effects", "Эффект выбора"}},
        {QStringLiteral("HurtEffect"), {"effects", "Эффект урона"}},
        {QStringLiteral("HurtMinDelay"), {"effects", "Мин. задержка эффекта урона"}},
        {QStringLiteral("CutOffEffects"), {"effects", "Обрезать эффекты"}},
        {QStringLiteral("IgnitePlatformOnDestruct"), {"effects", "Поджигать платформу"}},
        {QStringLiteral("ExplodeWhenOutOfWorld"), {"effects", "Взрыв за границей мира"}},
        {QStringLiteral("EffectPath"), {"effects", "Путь к эффекту"}},

        // ---- Отображение ----
        {QStringLiteral("SelectionWidth"), {"visual", "Ширина выделения"}},
        {QStringLiteral("SelectionHeight"), {"visual", "Высота выделения"}},
        {QStringLiteral("SelectionOffset"), {"visual", "Смещение выделения"}},
        {QStringLiteral("RecessionBox"), {"visual", "Рамка отступа"}},
        {QStringLiteral("DrawBehindTerrain"), {"visual", "Рисовать за рельефом"}},
        {QStringLiteral("DrawBracket"), {"visual", "Рисовать скобку"}},
        {QStringLiteral("RenderOrder"), {"visual", "Порядок отрисовки"}},
        // --- записи устройств в меню постройки ---
        {QStringLiteral("FileName"), {"general", "Файл объекта"}},
        {QStringLiteral("ShowDetails"), {"visual", "Показывать подробности"}},
        {QStringLiteral("AllowOverlap"), {"behavior", "Разрешить перекрытие"}},
        {QStringLiteral("ScoreWeight"), {"economy", "Вес в счёте"}},
        {QStringLiteral("SpotterTarget"), {"behavior", "Цель наводчика"}},
        {QStringLiteral("AlignToCursorNormal"), {"behavior", "Выравнивать по курсору"}},
        {QStringLiteral("BuildOnOreOnly"), {"behavior", "Только на руде"}},
        {QStringLiteral("CanMove"), {"behavior", "Можно перемещать"}},
        {QStringLiteral("HasDummy"), {"visual", "Есть макет"}},
        {QStringLiteral("PopulationCap"), {"economy", "Лимит населения"}},
        {QStringLiteral("Tech"), {"behavior", "Технология"}},
        {QStringLiteral("ValidityFlags"), {"behavior", "Флаги размещения"}},
        {QStringLiteral("MetalReclaimMin"), {"economy", "Возврат металла (мин)"}},
        {QStringLiteral("MetalReclaimMax"), {"economy", "Возврат металла (макс)"}},
        {QStringLiteral("EnergyReclaimMin"), {"economy", "Возврат энергии (мин)"}},
        {QStringLiteral("EnergyReclaimMax"), {"economy", "Возврат энергии (макс)"}},
        {QStringLiteral("Upgrades"), {"behavior", "Улучшения"}},
        {QStringLiteral("Detail"), {"visual", "Спрайт подробностей"}},
        // --- оружие: основные и служебные поля файла ---
        {QStringLiteral("Name"), {"general", "Название"}},
        {QStringLiteral("Tip"), {"general", "Подсказка"}},
        {QStringLiteral("RecessionBox"), {"visual", "Зона отката"}},
        {QStringLiteral("CanUpdateAimWhileFiring"), {"firing", "Наводить во время очереди"}},
        {QStringLiteral("ClearanceAngleStdDevFactor"), {"firing", "Разброс угла зазора"}},
        {QStringLiteral("FireEndEffect"), {"effects", "Эффект конца стрельбы"}},
        {QStringLiteral("MaxUpAngle"), {"behavior", "Максимальный угол подъёма"}},
        {QStringLiteral("ObserverBuildEvent"), {"behavior", "Событие постройки для наблюдателя"}},
        {QStringLiteral("MaxSpotterAssistance"), {"behavior", "Помощь наводчика"}},
        {QStringLiteral("CompatibleGroupTypes"), {"behavior", "Совместимые группы"}},
        {QStringLiteral("IsBehindDevices"), {"visual", "Рисовать позади устройств"}},
        {QStringLiteral("DeviceSplashDamage"), {"damage", "Урон по устройствам"}},
        {QStringLiteral("DeviceSplashDamageMaxRadius"), {"damage", "Радиус урона по устройствам"}},
        {QStringLiteral("DeviceSplashDamageDelay"), {"damage", "Задержка урона по устройствам"}},
        {QStringLiteral("StructureSplashDamage"), {"damage", "Урон по постройкам"}},
        {QStringLiteral("StructureSplashDamageMaxRadius"), {"damage", "Радиус урона по постройкам"}},
        {QStringLiteral("ButtonSpriteBottom"), {"visual", "Низ кнопки"}},
        {QStringLiteral("GroupButtonSpriteBottom"), {"visual", "Низ кнопки группы"}},
        {QStringLiteral("NeutralColour"), {"visual", "Нейтральный цвет"}},
        {QStringLiteral("IsBehindDevices"), {"visual", "Позади устройств"}},
        {QStringLiteral("DrawBlurredProjectile"), {"visual", "Размытие снаряда"}},
    };
    return d;
}

// Word-by-word fallback so keys we have never seen still read in Russian.
const QHash<QString, QString> &words()
{
    static const QHash<QString, QString> w = {
        {QStringLiteral("damage"), QStringLiteral("урон")},
        {QStringLiteral("radius"), QStringLiteral("радиус")},
        {QStringLiteral("range"), QStringLiteral("дальность")},
        {QStringLiteral("speed"), QStringLiteral("скорость")},
        {QStringLiteral("time"), QStringLiteral("время")},
        {QStringLiteral("period"), QStringLiteral("период")},
        {QStringLiteral("delay"), QStringLiteral("задержка")},
        {QStringLiteral("cost"), QStringLiteral("стоимость")},
        {QStringLiteral("energy"), QStringLiteral("энергия")},
        {QStringLiteral("metal"), QStringLiteral("металл")},
        {QStringLiteral("mass"), QStringLiteral("масса")},
        {QStringLiteral("angle"), QStringLiteral("угол")},
        {QStringLiteral("fire"), QStringLiteral("выстрел")},
        {QStringLiteral("firing"), QStringLiteral("стрельба")},
        {QStringLiteral("reload"), QStringLiteral("перезарядка")},
        {QStringLiteral("projectile"), QStringLiteral("снаряд")},
        {QStringLiteral("projectiles"), QStringLiteral("снаряды")},
        {QStringLiteral("beam"), QStringLiteral("луч")},
        {QStringLiteral("laser"), QStringLiteral("лазер")},
        {QStringLiteral("missile"), QStringLiteral("ракета")},
        {QStringLiteral("max"), QStringLiteral("макс.")},
        {QStringLiteral("min"), QStringLiteral("мин.")},
        {QStringLiteral("maximum"), QStringLiteral("максимум")},
        {QStringLiteral("minimum"), QStringLiteral("минимум")},
        {QStringLiteral("height"), QStringLiteral("высота")},
        {QStringLiteral("width"), QStringLiteral("ширина")},
        {QStringLiteral("length"), QStringLiteral("длина")},
        {QStringLiteral("offset"), QStringLiteral("смещение")},
        {QStringLiteral("size"), QStringLiteral("размер")},
        {QStringLiteral("effect"), QStringLiteral("эффект")},
        {QStringLiteral("effects"), QStringLiteral("эффекты")},
        {QStringLiteral("rate"), QStringLiteral("скорость")},
        {QStringLiteral("capacity"), QStringLiteral("ёмкость")},
        {QStringLiteral("storage"), QStringLiteral("запас")},
        {QStringLiteral("production"), QStringLiteral("производство")},
        {QStringLiteral("wind"), QStringLiteral("ветер")},
        {QStringLiteral("rotational"), QStringLiteral("вращения")},
        {QStringLiteral("splash"), QStringLiteral("осколочный")},
        {QStringLiteral("device"), QStringLiteral("устройства")},
        {QStringLiteral("structure"), QStringLiteral("построек")},
        {QStringLiteral("incendiary"), QStringLiteral("поджог")},
        {QStringLiteral("underwater"), QStringLiteral("подводный")},
        {QStringLiteral("build"), QStringLiteral("строительство")},
        {QStringLiteral("repair"), QStringLiteral("ремонт")},
        {QStringLiteral("reclaim"), QStringLiteral("возврат")},
        {QStringLiteral("health"), QStringLiteral("прочность")},
        {QStringLiteral("hit"), QStringLiteral("попадание")},
        {QStringLiteral("points"), QStringLiteral("очки")},
        {QStringLiteral("scale"), QStringLiteral("масштаб")},
        {QStringLiteral("selection"), QStringLiteral("выделение")},
        {QStringLiteral("draw"), QStringLiteral("отрисовка")},
        {QStringLiteral("behind"), QStringLiteral("позади")},
        {QStringLiteral("terrain"), QStringLiteral("рельеф")},
        {QStringLiteral("enabled"), QStringLiteral("включено")},
        {QStringLiteral("visible"), QStringLiteral("видимость")},
        {QStringLiteral("priority"), QStringLiteral("приоритет")},
        {QStringLiteral("category"), QStringLiteral("категория")},
        {QStringLiteral("name"), QStringLiteral("название")},
        {QStringLiteral("icon"), QStringLiteral("иконка")},
        {QStringLiteral("group"), QStringLiteral("группа")},
        {QStringLiteral("button"), QStringLiteral("кнопка")},
        {QStringLiteral("count"), QStringLiteral("количество")},
        {QStringLiteral("amount"), QStringLiteral("количество")},
        {QStringLiteral("force"), QStringLiteral("сила")},
        {QStringLiteral("thickness"), QStringLiteral("толщина")},
        {QStringLiteral("duration"), QStringLiteral("длительность")},
        {QStringLiteral("factor"), QStringLiteral("коэффициент")},
        {QStringLiteral("multiplier"), QStringLiteral("множитель")},
        {QStringLiteral("vulnerability"), QStringLiteral("уязвимость")},
        {QStringLiteral("penetration"), QStringLiteral("пробитие")},
        {QStringLiteral("shield"), QStringLiteral("щит")},
        {QStringLiteral("shields"), QStringLiteral("щиты")},
        {QStringLiteral("armor"), QStringLiteral("броня")},
        {QStringLiteral("armour"), QStringLiteral("броня")},
        {QStringLiteral("weapon"), QStringLiteral("оружие")},
        {QStringLiteral("weapons"), QStringLiteral("оружие")},
        {QStringLiteral("device"), QStringLiteral("устройство")},
        {QStringLiteral("devices"), QStringLiteral("устройства")},
        {QStringLiteral("material"), QStringLiteral("материал")},
        {QStringLiteral("materials"), QStringLiteral("материалы")},
        {QStringLiteral("projectile"), QStringLiteral("снаряд")},
        {QStringLiteral("projectiles"), QStringLiteral("снаряды")},
        {QStringLiteral("strings"), QStringLiteral("строки")},
        {QStringLiteral("script"), QStringLiteral("скрипт")},
        {QStringLiteral("overheat"), QStringLiteral("перегрев")},
        {QStringLiteral("explosion"), QStringLiteral("взрыв")},
        {QStringLiteral("frame"), QStringLiteral("кадр")},
        {QStringLiteral("smoke"), QStringLiteral("дым")},
        {QStringLiteral("emitter"), QStringLiteral("источник")},
        {QStringLiteral("initial"), QStringLiteral("начальное")},
        {QStringLiteral("state"), QStringLiteral("состояние")},
        {QStringLiteral("sprite"), QStringLiteral("спрайт")},
        {QStringLiteral("pivot"), QStringLiteral("точка вращения")},
        {QStringLiteral("burst"), QStringLiteral("очередь")},
        {QStringLiteral("clamp"), QStringLiteral("ограничение")},
        {QStringLiteral("clearance"), QStringLiteral("зазор")},
        {QStringLiteral("kickback"), QStringLiteral("откат")},
        {QStringLiteral("recoil"), QStringLiteral("отдача")},
        {QStringLiteral("spread"), QStringLiteral("разброс")},
        {QStringLiteral("reflection"), QStringLiteral("отражение")},
        {QStringLiteral("momentum"), QStringLiteral("импульс")},
        {QStringLiteral("threshold"), QStringLiteral("порог")},
        {QStringLiteral("efficiency"), QStringLiteral("эффективность")},
        {QStringLiteral("count"), QStringLiteral("количество")},
        {QStringLiteral("spread"), QStringLiteral("разлёт")},
        {QStringLiteral("frag"), QStringLiteral("осколков")},
        {QStringLiteral("frags"), QStringLiteral("осколков")},
        {QStringLiteral("shard"), QStringLiteral("осколков")},
        {QStringLiteral("gaus"), QStringLiteral("Гаусс")},
        {QStringLiteral("aphe"), QStringLiteral("APHE")},
        {QStringLiteral("shell"), QStringLiteral("снаряда")},
        {QStringLiteral("bullet"), QStringLiteral("пули")},
        {QStringLiteral("save"), QStringLiteral("сохранения")},
        {QStringLiteral("scale"), QStringLiteral("масштаб")},
        {QStringLiteral("ref"), QStringLiteral("базовый")},
        {QStringLiteral("base"), QStringLiteral("базовый")},
        {QStringLiteral("ratio"), QStringLiteral("соотношение")},
        {QStringLiteral("index"), QStringLiteral("индекс")},
        {QStringLiteral("limit"), QStringLiteral("предел")},
        {QStringLiteral("value"), QStringLiteral("значение")},
        {QStringLiteral("default"), QStringLiteral("по умолчанию")},
    };
    return w;
}

const QHash<QString, QString> &categories()
{
    static const QHash<QString, QString> c = {
        {QStringLiteral("general"), QStringLiteral("Основные")},
        {QStringLiteral("health"), QStringLiteral("Прочность")},
        {QStringLiteral("firing"), QStringLiteral("Стрельба")},
        {QStringLiteral("damage"), QStringLiteral("Урон")},
        {QStringLiteral("overheat"), QStringLiteral("Перегрев")},
        {QStringLiteral("ammo"), QStringLiteral("Боеприпасы")},
        {QStringLiteral("bank"), QStringLiteral("Магазин")},
        {QStringLiteral("projectile"), QStringLiteral("Снаряд")},
        {QStringLiteral("economy"), QStringLiteral("Экономика")},
        {QStringLiteral("wind"), QStringLiteral("Ветер и вращение")},
        {QStringLiteral("behavior"), QStringLiteral("Поведение")},
        {QStringLiteral("effects"), QStringLiteral("Эффекты")},
        {QStringLiteral("visual"), QStringLiteral("Отображение")},
        {QStringLiteral("other"), QStringLiteral("Прочее")},
        {QStringLiteral("constants"), QStringLiteral("Константы")},
        {QStringLiteral("textures"), QStringLiteral("Текстуры")},
        {QStringLiteral("proj_main"), QStringLiteral("Основные")},
        {QStringLiteral("proj_flight"), QStringLiteral("Полёт снаряда")},
        {QStringLiteral("proj_damage"), QStringLiteral("Урон снаряда")},
        {QStringLiteral("proj_splash"), QStringLiteral("Осколки и взрыв")},
        {QStringLiteral("proj_armour"), QStringLiteral("Рикошет и броня")},
        {QStringLiteral("proj_beam"), QStringLiteral("Луч")},
        {QStringLiteral("proj_missile"), QStringLiteral("Ракета")},
        {QStringLiteral("wl_main"), QStringLiteral("Основные")},
        {QStringLiteral("wl_cost"), QStringLiteral("Стоимость")},
        {QStringLiteral("wl_tech"), QStringLiteral("Технология")},
        {QStringLiteral("wl_ui"), QStringLiteral("Интерфейс (HUD)")},
        {QStringLiteral("wl_build"), QStringLiteral("Строительство")},
        {QStringLiteral("wl_behavior"), QStringLiteral("Поведение")},
        {QStringLiteral("wl_upgrades"), QStringLiteral("Улучшения")},
        {QStringLiteral("dl_main"), QStringLiteral("Основные")},
        {QStringLiteral("dl_cost"), QStringLiteral("Стоимость")},
        {QStringLiteral("dl_tech"), QStringLiteral("Технология")},
        {QStringLiteral("dl_ui"), QStringLiteral("Интерфейс")},
        {QStringLiteral("dl_build"), QStringLiteral("Строительство")},
        {QStringLiteral("dl_behavior"), QStringLiteral("Поведение")},
    };
    return c;
}

const QStringList &categorySequence()
{
    static const QStringList s = {
        QStringLiteral("general"),   QStringLiteral("health"),   QStringLiteral("firing"),
        QStringLiteral("damage"),    QStringLiteral("overheat"), QStringLiteral("ammo"),
        QStringLiteral("bank"),
        QStringLiteral("projectile"),
        QStringLiteral("economy"),   QStringLiteral("wind"),     QStringLiteral("behavior"),
        QStringLiteral("effects"),   QStringLiteral("visual"),   QStringLiteral("other"),
        QStringLiteral("general"),
        QStringLiteral("health"),    QStringLiteral("firing"),
        QStringLiteral("ammo"),      QStringLiteral("overheat"),
        QStringLiteral("projectile"), QStringLiteral("damage"),
        QStringLiteral("economy"),   QStringLiteral("wind"),
        QStringLiteral("behavior"),  QStringLiteral("effects"),
        QStringLiteral("visual"),    QStringLiteral("textures"),
        QStringLiteral("constants"),
        QStringLiteral("proj_main"), QStringLiteral("proj_flight"), QStringLiteral("proj_damage"),
        QStringLiteral("proj_splash"), QStringLiteral("proj_armour"), QStringLiteral("proj_beam"),
        QStringLiteral("proj_missile"),
        QStringLiteral("wl_main"), QStringLiteral("wl_cost"), QStringLiteral("wl_tech"),
        QStringLiteral("wl_ui"), QStringLiteral("wl_build"), QStringLiteral("wl_behavior"),
        QStringLiteral("wl_upgrades"),
        QStringLiteral("dl_main"), QStringLiteral("dl_cost"), QStringLiteral("dl_tech"),
        QStringLiteral("dl_ui"), QStringLiteral("dl_build"), QStringLiteral("dl_behavior"),
    };
    return s;
}

// Tables whose contents are rendering / structural data, not characteristics.
const QSet<QString> &technicalTables()
{
    static const QSet<QString> t = {
        QStringLiteral("Sprites"),      QStringLiteral("Root"),       QStringLiteral("States"),
        QStringLiteral("Frames"),       QStringLiteral("Bracing"),    QStringLiteral("BracingPlates"),
        QStringLiteral("Cladding"),     QStringLiteral("NodeEffects"),
        QStringLiteral("BeamTable"),    QStringLiteral("AngleTable"), QStringLiteral("Materials"),
        QStringLiteral("Missile"),      QStringLiteral("Missile2"),  QStringLiteral("DefaultConversions"),
        QStringLiteral("Effects"),      QStringLiteral("Impact"),     QStringLiteral("Deflect"),
        QStringLiteral("Penetrate"),    QStringLiteral("NodeImpacts"),
        QStringLiteral("StandardNode"), QStringLiteral("CableNode"),  QStringLiteral("Trail"),
        QStringLiteral("UnderConstruction"), QStringLiteral("RecessionBox"),
        QStringLiteral("effect"),       QStringLiteral("visualEffect"),
    };
    return t;
}

} // namespace

namespace ParamCatalog {

namespace {

// Russian label for an ALL_CAPS constant: the trailing word names the kind
// (COUNT, SPEED, SPREAD …) and goes first, the rest describes it.
QString constantLabel(const QString &key)
{
    static const QHash<QString, QString> kinds = {
        {QStringLiteral("COUNT"), QStringLiteral("Количество")},
        {QStringLiteral("SPEED"), QStringLiteral("Скорость")},
        {QStringLiteral("SPREAD"), QStringLiteral("Разлёт")},
        {QStringLiteral("SCALE"), QStringLiteral("Масштаб")},
        {QStringLiteral("TIME"), QStringLiteral("Время")},
        {QStringLiteral("DAMAGE"), QStringLiteral("Урон")},
        {QStringLiteral("RADIUS"), QStringLiteral("Радиус")},
        {QStringLiteral("MASS"), QStringLiteral("Масса")},
        {QStringLiteral("FORCE"), QStringLiteral("Сила")},
        {QStringLiteral("NAME"), QStringLiteral("Имя")},
    };

    if (key.endsWith(QLatin1String("_SAVE_NAME")))
        return QStringLiteral("Внутреннее имя (константа)");

    QStringList parts = key.split(QLatin1Char('_'), Qt::SkipEmptyParts);
    if (parts.isEmpty())
        return key;

    const QString last = parts.takeLast();
    const auto kit = kinds.constFind(last);
    QString head = kit != kinds.constEnd() ? kit.value() : last;

    QStringList rest;
    for (const QString &w : parts) {
        const auto it = words().constFind(w.toLower());
        rest << (it != words().constEnd() ? it.value() : w.toLower());
    }

    QString out = head;
    if (!rest.isEmpty())
        out += QLatin1Char(' ') + rest.join(QLatin1Char(' '));
    out[0] = out.at(0).toUpper();
    return out;
}

} // namespace

QString label(const QString &key)
{
    const auto it = dict().constFind(key);
    if (it != dict().constEnd())
        return QString::fromUtf8(it.value().ru);

    if (isConstantName(key))
        return constantLabel(key);

    // Fallback: translate the CamelCase words we know, keep the rest as-is.
    static const QRegularExpression camel(
        QStringLiteral("(?<=[a-z0-9])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])"));
    const QStringList parts = key.split(camel, Qt::SkipEmptyParts);

    QStringList out;
    for (const QString &w : parts) {
        const QString lower = w.toLower();
        const auto wit = words().constFind(lower);
        out << (wit != words().constEnd() ? wit.value() : w);
    }

    QString result = out.join(QLatin1Char(' '));
    if (!result.isEmpty())
        result[0] = result[0].toUpper();
    return result;
}

QString hint(const QString &key)
{
    static const QHash<QString, QString> h = {
        // ---- Внешний вид ----
        {QStringLiteral("Scale"), QStringLiteral("Общий масштаб модели оружия")},
        {QStringLiteral("SelectionWidth"), QStringLiteral("Ширина рамки выделения оружия")},
        {QStringLiteral("SelectionHeight"), QStringLiteral("Высота рамки выделения оружия")},
        {QStringLiteral("SelectionOffset"), QStringLiteral("Смещение рамки выделения относительно центра")},
        {QStringLiteral("RenderOrder"), QStringLiteral("Порядок отрисовки: больше число — рисуется выше")},
        {QStringLiteral("NeutralColour"), QStringLiteral("Оттенок нейтрального цвета в меню")},
        {QStringLiteral("Mesh"), QStringLiteral("Модель устройства (файл меша)")},
        {QStringLiteral("ButtonSpriteBottom"), QStringLiteral("Доля спрайта, от которой начинается кнопка")},
        {QStringLiteral("GroupButtonSpriteBottom"), QStringLiteral("Смещение кнопки в группе оружия")},
        {QStringLiteral("DrawBehindTerrain"), QStringLiteral("Рисовать позади рельефа")},
        {QStringLiteral("DrawBracket"), QStringLiteral("Рисовать скобку выделения")},
        {QStringLiteral("DrawBlurredProjectile"), QStringLiteral("Размывать снаряд в полёте")},
        {QStringLiteral("IsBehindDevices"), QStringLiteral("Рисовать позади устройств")},

        // ---- Прочность ----
        {QStringLiteral("HitPoints"), QStringLiteral("Сколько урона выдерживает оружие до разрушения")},
        {QStringLiteral("Health"), QStringLiteral("Прочность устройства до разрушения")},
        {QStringLiteral("EMPVulnerability"), QStringLiteral("Уязвимость к ЭМИ: 0 — не боится, 1 — полный отказ")},
        {QStringLiteral("Armor"), QStringLiteral("Доля урона, которую материал отражает (0–1)")},
        {QStringLiteral("ReflectionMomentumThreshold"), QStringLiteral("Импульс, ниже которого снаряд рикошетит")},
        {QStringLiteral("PenetrationMomentumThreshold"), QStringLiteral("Импульс, выше которого снаряд пробивает броню")},

        // ---- Экономика ----
        {QStringLiteral("WeaponMass"), QStringLiteral("Масса оружия: влияет на устойчивость платформы")},
        {QStringLiteral("Mass"), QStringLiteral("Масса устройства: чем тяжелее, тем устойчивее платформа")},
        {QStringLiteral("Cost"), QStringLiteral("Стоимость постройки")},
        {QStringLiteral("EnergyProductionRate"), QStringLiteral("Сколько энергии производит в секунду")},
        {QStringLiteral("MetalProductionRate"), QStringLiteral("Сколько металла производит в секунду")},
        {QStringLiteral("EnergyStorageCapacity"), QStringLiteral("Сколько энергии можно накопить")},
        {QStringLiteral("MetalStorageCapacity"), QStringLiteral("Сколько металла можно накопить")},
        {QStringLiteral("EnergyFireCost"), QStringLiteral("Сколько энергии тратится на один выстрел")},
        {QStringLiteral("MetalFireCost"), QStringLiteral("Сколько металла тратится на один выстрел")},
        {QStringLiteral("EnergyBuildCost"), QStringLiteral("Сколько энергии стоит постройка")},
        {QStringLiteral("MetalBuildCost"), QStringLiteral("Сколько металла стоит постройка")},
        {QStringLiteral("EnergyRepairCost"), QStringLiteral("Сколько энергии стоит ремонт")},
        {QStringLiteral("MetalRepairCost"), QStringLiteral("Сколько металла стоит ремонт")},
        {QStringLiteral("EnergyReclaim"), QStringLiteral("Сколько энергии возвращается при разборе")},
        {QStringLiteral("MetalReclaim"), QStringLiteral("Сколько металла возвращается при разборе")},
        {QStringLiteral("NoReclaim"), QStringLiteral("Запрещает возврат ресурсов при разборе")},
        {QStringLiteral("BuildTimeComplete"), QStringLiteral("За сколько секунд устройство строится")},
        {QStringLiteral("ScrapPeriod"), QStringLiteral("Как часто устройство можно разбирать")},
        {QStringLiteral("BuildQueueConcurrent"), QStringLiteral("Сколько таких построек можно строить одновременно")},

        // ---- Ветер ----
        {QStringLiteral("MinWindEfficiency"), QStringLiteral("Минимальная эффективность при слабом ветре")},
        {QStringLiteral("MaxWindHeight"), QStringLiteral("Высота, выше которой ветер не влияет")},
        {QStringLiteral("MaxRotationalSpeed"), QStringLiteral("Максимальная скорость поворота орудия")},
        {QStringLiteral("MinWindAngle"), QStringLiteral("Минимальный угол, при котором работает ветер")},
        {QStringLiteral("MaxWindAngle"), QStringLiteral("Максимальный угол, при котором работает ветер")},
        {QStringLiteral("MinWindCrossFlow"), QStringLiteral("Минимальный поперечный поток ветра")},
        {QStringLiteral("MinWindNoCrossFlow"), QStringLiteral("Порог, ниже которого ветер не влияет")},

        // ---- Стрельба ----
        {QStringLiteral("ReloadTime"), QStringLiteral("Пауза между выстрелами, в секундах")},
        {QStringLiteral("MinFireSpeed"), QStringLiteral("Скорость снаряда при минимальной натяжке")},
        {QStringLiteral("MaxFireSpeed"), QStringLiteral("Скорость снаряда при максимальной натяжке")},
        {QStringLiteral("MinFireRadius"), QStringLiteral("Ближняя граница стрельбы")},
        {QStringLiteral("MaxFireRadius"), QStringLiteral("Дальняя граница стрельбы")},
        {QStringLiteral("MinFireAngle"), QStringLiteral("Минимальный угол наведения (ниже — нельзя)")},
        {QStringLiteral("MaxFireAngle"), QStringLiteral("Максимальный угол наведения (выше — нельзя)")},
        {QStringLiteral("DefaultFireAngle"), QStringLiteral("Угол наведения при постройке")},
        {QStringLiteral("ForceFireAngle"), QStringLiteral("Жёстко заданный угол, если оружие не наводится")},
        {QStringLiteral("MaxFireClamp"), QStringLiteral("Ограничение хода наведения")},
        {QStringLiteral("FireStdDev"), QStringLiteral("Случайный разброс при ручном выстреле")},
        {QStringLiteral("FireStdDevAuto"), QStringLiteral("Случайный разброс при автоматическом огне")},
        {QStringLiteral("FireDelay"), QStringLiteral("Задержка перед выстрелом после нажатия")},
        {QStringLiteral("Recoil"), QStringLiteral("Сила отдачи, толкающая платформу назад")},
        {QStringLiteral("KickbackMean"), QStringLiteral("Средняя сила отката ствола")},
        {QStringLiteral("KickbackStdDev"), QStringLiteral("Разброс силы отката")},
        {QStringLiteral("PanDuration"), QStringLiteral("Время плавного поворота орудия")},
        {QStringLiteral("MouseSensitivityFactor"), QStringLiteral("Множитель чувствительности мыши при наведении")},
        {QStringLiteral("BarrelLength"), QStringLiteral("Длина ствола: откуда вылетает снаряд")},
        {QStringLiteral("MinFireClearance"), QStringLiteral("Минимальный зазор до препятствия, иначе выстрела не будет")},
        {QStringLiteral("FireClearanceOffsetInner"), QStringLiteral("Внутреннее смещение зоны выстрела")},
        {QStringLiteral("FireClearanceOffsetOuter"), QStringLiteral("Внешнее смещение зоны выстрела")},
        {QStringLiteral("AttractZoomOutDuration"), QStringLiteral("За сколько секунд камера отъезжает к оружию")},
        {QStringLiteral("ShowFireAngle"), QStringLiteral("Показывать угол наведения при прицеливании")},
        {QStringLiteral("ShowFireSpeed"), QStringLiteral("Показывать скорость снаряда")},
        {QStringLiteral("ShowAimingGizmo"), QStringLiteral("Показывать вспомогательный прицел")},
        {QStringLiteral("HoldToFire"), QStringLiteral("Стрелять только при удержании кнопки")},
        {QStringLiteral("BarrelRecoilLimit"), QStringLiteral("Насколько глубоко ствол уходит при откате")},
        {QStringLiteral("BarrelRecoilSpeed"), QStringLiteral("Скорость отката ствола")},
        {QStringLiteral("BarrelReturnForce"), QStringLiteral("Сила возврата ствола на место")},
        {QStringLiteral("MaxTestDistance"), QStringLiteral("Максимальная дистанция проверки выстрела")},
        {QStringLiteral("MinTestDistance"), QStringLiteral("Минимальная дистанция проверки выстрела")},
        {QStringLiteral("MaxUpAngle"), QStringLiteral("Максимальный угол подъёма")},
        {QStringLiteral("StandardMaxUpAngle"), QStringLiteral("Максимальный угол подъёма конструкции")},
        {QStringLiteral("DoorCloseDelay"), QStringLiteral("Задержка автозакрытия двери")},
        {QStringLiteral("AutofireCloseDoorTicks"), QStringLiteral("Через сколько тиков дверь закрывается сама")},
        {QStringLiteral("ReloadFramePeriod"), QStringLiteral("Длительность кадра анимации перезарядки")},

        // ---- Боеприпасы ----
        {QStringLiteral("RoundsEachBurst"), QStringLiteral("Сколько снарядов в одной очереди")},
        {QStringLiteral("RoundPeriod"), QStringLiteral("Пауза между выстрелами внутри очереди")},
        {QStringLiteral("ReloadTimeIncludesBurst"), QStringLiteral("Считать очередь частью времени перезарядки")},
        {QStringLiteral("Ammo"), QStringLiteral("Количество боеприпасов")},

        // ---- Урон ----
        {QStringLiteral("Damage"), QStringLiteral("Урон по цели при попадании")},
        {QStringLiteral("DamageRadius"), QStringLiteral("Радиус, в котором наносится урон")},
        {QStringLiteral("Incendiary"), QStringLiteral("Сила поджога при взрыве")},
        {QStringLiteral("IncendiaryRadius"), QStringLiteral("Радиус поджога после взрыва")},
        {QStringLiteral("IncendiaryRadiusHeated"), QStringLiteral("Радиус поджога, когда оружие перегрето")},
        {QStringLiteral("DeviceSplashDamage"), QStringLiteral("Урон по устройствам в зоне взрыва")},
        {QStringLiteral("DeviceSplashDamageMaxRadius"), QStringLiteral("Радиус, в котором наносится урон устройствам")},
        {QStringLiteral("DeviceSplashDamageDelay"), QStringLiteral("Задержка перед нанесением урона")},
        {QStringLiteral("StructureSplashDamage"), QStringLiteral("Урон по постройкам в зоне взрыва")},
        {QStringLiteral("StructureSplashDamageMaxRadius"), QStringLiteral("Радиус урона по постройкам")},
        {QStringLiteral("UnderwaterDamageRate"), QStringLiteral("Урон подводным целям в секунду")},
        {QStringLiteral("UnderwaterDamageMinDepth"), QStringLiteral("Минимальная глубина для подводного урона")},
        {QStringLiteral("UnderwaterDamageMinAngle"), QStringLiteral("Минимальный угол для подводного урона")},
        {QStringLiteral("UnderwaterDamageMaxStructureRadius"), QStringLiteral("Радиус подводного урона по постройкам")},
        {QStringLiteral("BlockPenetration"), QStringLiteral("Блокирует пробитие брони")},

        // ---- Перегрев ----
        {QStringLiteral("CanOverheat"), QStringLiteral("Включает нагрев и остывание при стрельбе")},
        {QStringLiteral("HeatPeriod"), QStringLiteral("Сколько секунд стрельбы нужно для перегрева")},
        {QStringLiteral("CoolPeriod"), QStringLiteral("Сколько секунд остывает после перегрева")},
        {QStringLiteral("CoolPeriodOverheated"), QStringLiteral("Остывание, если оружие уже перегрето")},
        {QStringLiteral("Overheated"), QStringLiteral("Оружие перегрето")},
        {QStringLiteral("CooldownTime"), QStringLiteral("Время остывания после выстрела")},
        {QStringLiteral("FullCooldownTime"), QStringLiteral("Время полного остывания")},

        // ---- Снаряд ----
        {QStringLiteral("Projectile"), QStringLiteral("Какой снаряд использует оружие")},
        {QStringLiteral("ProjectileType"), QStringLiteral("Тип снаряда")},
        {QStringLiteral("ProjectileMass"), QStringLiteral("Масса снаряда: влияет на пробитие брони")},
        {QStringLiteral("ProjectileDrag"), QStringLiteral("Сопротивление воздуха для снаряда")},
        {QStringLiteral("ProjectileDamage"), QStringLiteral("Урон снаряда при попадании")},
        {QStringLiteral("ProjectileThickness"), QStringLiteral("Толщина снаряда при столкновениях")},
        {QStringLiteral("ProjectileShootDownRadius"), QStringLiteral("Радиус, в котором снаряд можно сбить")},
        {QStringLiteral("DeflectedByShields"), QStringLiteral("Снаряд отражается энергощитами")},
        {QStringLiteral("ExplodeOnTouch"), QStringLiteral("Снаряд взрывается при касании")},
        {QStringLiteral("SpeedIndicatorFactor"), QStringLiteral("Множитель индикатора скорости снаряда")},
        {QStringLiteral("BeamDuration"), QStringLiteral("Сколько секунд держится луч")},
        {QStringLiteral("BeamDamageMultiplier"), QStringLiteral("Множитель урона луча")},
        {QStringLiteral("BeamThicknessMultiplier"), QStringLiteral("Множитель толщины луча")},
        {QStringLiteral("BeamScrollRate"), QStringLiteral("Скорость прокрутки текстуры луча")},
        {QStringLiteral("BeamTileRate"), QStringLiteral("Частота повторов текстуры луча")},
        {QStringLiteral("BeamEndEffectTime"), QStringLiteral("Через сколько секунд проигрывается эффект конца луча")},
        {QStringLiteral("BeamsCutOffEffects"), QStringLiteral("Обрезать эффекты лучей по цели")},
        {QStringLiteral("BeamsRecycleEffects"), QStringLiteral("Переиспользовать эффекты лучей")},
        {QStringLiteral("LaserScale"), QStringLiteral("Масштаб луча лазера")},
        {QStringLiteral("LaserSightSolid"), QStringLiteral("Спрайт сплошного прицела лазера")},
        {QStringLiteral("LaserSightDashed"), QStringLiteral("Спрайт пунктирного прицела лазера")},
        {QStringLiteral("MissileDisruptionMin"), QStringLiteral("Минимальное отклонение ракеты помехами")},
        {QStringLiteral("MissileDisruptionStdDevMin"), QStringLiteral("Нижняя граница разброса помех")},
        {QStringLiteral("MissileDisruptionStdDevMax"), QStringLiteral("Верхняя граница разброса помех")},

        // ---- Эффекты ----
        {QStringLiteral("FireEffect"), QStringLiteral("Файл эффекта при выстреле")},
        {QStringLiteral("FireEndEffect"), QStringLiteral("Эффект после окончания стрельбы")},
        {QStringLiteral("FireRetriggerEffect"), QStringLiteral("Эффект при повторном нажатии огня")},
        {QStringLiteral("RetriggerFireEffect"), QStringLiteral("Перезапускать эффект выстрела")},
        {QStringLiteral("RetriggerFireEffectOnce"), QStringLiteral("Перезапускать эффект только один раз")},
        {QStringLiteral("ConstructEffect"), QStringLiteral("Эффект во время постройки")},
        {QStringLiteral("CompleteEffect"), QStringLiteral("Эффект при завершении постройки")},
        {QStringLiteral("DestroyEffect"), QStringLiteral("Эффект при разрушении")},
        {QStringLiteral("DestroyUnderwaterEffect"), QStringLiteral("Эффект при разрушении под водой")},
        {QStringLiteral("ShellEffect"), QStringLiteral("Эффект вылетающей гильзы")},
        {QStringLiteral("ReloadEffect"), QStringLiteral("Эффект перезарядки")},
        {QStringLiteral("ReloadEffectOffset"), QStringLiteral("Смещение эффекта перезарядки")},
        {QStringLiteral("TrailEffect"), QStringLiteral("Эффект следа за снарядом")},
        {QStringLiteral("SelectEffect"), QStringLiteral("Эффект при выборе оружия")},
        {QStringLiteral("HurtEffect"), QStringLiteral("Эффект при получении урона")},
        {QStringLiteral("HurtMinDelay"), QStringLiteral("Минимальная пауза между эффектами урона")},
        {QStringLiteral("CutOffEffects"), QStringLiteral("Обрезать эффекты по цели")},
        {QStringLiteral("IgnitePlatformOnDestruct"), QStringLiteral("Поджигает платформу при разрушении")},
        {QStringLiteral("ExplodeWhenOutOfWorld"), QStringLiteral("Взрывается, вылетев за границы карты")},
        {QStringLiteral("EffectPath"), QStringLiteral("Путь к файлу эффекта")},
        {QStringLiteral("SmokeEmitter"), QStringLiteral("Источник дыма для повреждённого устройства")},

        // ---- Поведение ----
        {QStringLiteral("Enabled"), QStringLiteral("Включает оружие или устройство")},
        {QStringLiteral("Disabled"), QStringLiteral("Отключает оружие или устройство")},
        {QStringLiteral("Visible"), QStringLiteral("Показывать в меню постройки")},
        {QStringLiteral("CanFlip"), QStringLiteral("Разрешает переворачивать оружие")},
        {QStringLiteral("Inverted"), QStringLiteral("Перевёрнутое размещение")},
        {QStringLiteral("IgnorePlatformSlope"), QStringLiteral("Игнорирует наклон платформы")},
        {QStringLiteral("TeamOwned"), QStringLiteral("Устройство принадлежит команде")},
        {QStringLiteral("ClaimsStructures"), QStringLiteral("Захватывает соседние постройки")},
        {QStringLiteral("Repairable"), QStringLiteral("Устройство можно ремонтировать")},
        {QStringLiteral("BuildOnGroundOnly"), QStringLiteral("Строить можно только на земле")},
        {QStringLiteral("DisruptionBlocksFire"), QStringLiteral("Помехи запрещают стрельбу")},
        {QStringLiteral("ChildrenInFront"), QStringLiteral("Дочерние элементы рисуются спереди")},
        {QStringLiteral("ChildrenBehind"), QStringLiteral("Дочерние элементы рисуются позади")},
        {QStringLiteral("Prerequisite"), QStringLiteral("Что нужно построить перед этим")},
        {QStringLiteral("PrerequisiteAlt"), QStringLiteral("Второй вариант требования (любой из двух)")},
        {QStringLiteral("GroupButton"), QStringLiteral("Кнопка группы в меню постройки")},
        {QStringLiteral("Priority"), QStringLiteral("Приоритет мода при конфликте файлов")},
        {QStringLiteral("Category"), QStringLiteral("Категория мода в списке")},
        {QStringLiteral("Selectable"), QStringLiteral("Мод можно выбрать в списке")},
        {QStringLiteral("UserData"), QStringLiteral("Произвольные данные для скриптов")},
        {QStringLiteral("ExcludeUnlockAll"), QStringLiteral("Не открывать вместе с «открыть всё»")},
        {QStringLiteral("RequiresHighSeas"), QStringLiteral("Требует дополнение High Seas")},
        {QStringLiteral("RequiresMoonshot"), QStringLiteral("Требует дополнение Moonshot")},
        {QStringLiteral("StandardMinLength"), QStringLiteral("Минимальная длина конструкции")},
        // --- записи устройств ---
        {QStringLiteral("FileName"), QStringLiteral("Файл самого объекта: что именно строится")},
        {QStringLiteral("ShowDetails"), QStringLiteral("Показывать подробности постройки в подсказке")},
        {QStringLiteral("AllowOverlap"), QStringLiteral("Разрешает ставить постройку вплотную к другим")},
        {QStringLiteral("ScoreWeight"), QStringLiteral("Сколько очков приносит постройка")},
        {QStringLiteral("SpotterTarget"), QStringLiteral("Можно выбрать как цель для наводчика")},
        {QStringLiteral("AlignToCursorNormal"), QStringLiteral("Разворачивать по нормали под курсором")},
        {QStringLiteral("BuildOnOreOnly"), QStringLiteral("Строится только на залежах руды")},
        {QStringLiteral("CanMove"), QStringLiteral("Постройку можно передвигать")},
        {QStringLiteral("HasDummy"), QStringLiteral("Рисовать макет до постройки")},
        {QStringLiteral("PopulationCap"), QStringLiteral("Сколько людей вмещает")},
        {QStringLiteral("Tech"), QStringLiteral("Технология, которая открывает постройку")},
        {QStringLiteral("ValidityFlags"), QStringLiteral("Где разрешено ставить: земля, вода, под водой")},
        {QStringLiteral("MetalReclaimMin"), QStringLiteral("Минимальный возврат металла при разборе")},
        {QStringLiteral("MetalReclaimMax"), QStringLiteral("Максимальный возврат металла при разборе")},
        {QStringLiteral("EnergyReclaimMin"), QStringLiteral("Минимальный возврат энергии при разборе")},
        {QStringLiteral("EnergyReclaimMax"), QStringLiteral("Максимальный возврат энергии при разборе")},
        {QStringLiteral("Detail"), QStringLiteral("Спрайт подробностей постройки")},
        {QStringLiteral("StandardMaxLength"), QStringLiteral("Максимальная длина конструкции")},
        {QStringLiteral("StandardMaxLinkLength"), QStringLiteral("Максимальная длина соединения")},
    };
    if (!h.value(key).isEmpty())
        return h.value(key);

    // Generic explanations for the usual tuning constants.
    if (key.endsWith(QLatin1String("_COUNT")))
        return QStringLiteral("Сколько осколков (или снарядов) создаётся за раз");
    if (key.endsWith(QLatin1String("_SPEED")))
        return QStringLiteral("Скорость разлёта осколков");
    if (key.endsWith(QLatin1String("_SPREAD")))
        return QStringLiteral("Разброс угла в радианах: 6.2832 ≈ полный круг (360°)");
    if (key.endsWith(QLatin1String("_SCALE")))
        return QStringLiteral("Масштаб модели снаряда");

    return QString();
}

QString unit(const QString &key)
{
    // Times
    if (key.endsWith(QLatin1String("Time")) || key.endsWith(QLatin1String("Period"))
        || key.endsWith(QLatin1String("Duration")) || key.endsWith(QLatin1String("Delay"))
        || key.contains(QLatin1String("Cooldown")))
        return QStringLiteral("с");

    // Angles
    if (key.contains(QLatin1String("Angle")))
        return QStringLiteral("°");

    // Distances
    if (key.contains(QLatin1String("Radius")) || key.contains(QLatin1String("Length"))
        || key.contains(QLatin1String("Width")) || key.contains(QLatin1String("Height"))
        || key.contains(QLatin1String("Distance")) || key.contains(QLatin1String("Clearance")))
        return QStringLiteral("ед.");

    if (key == QLatin1String("HitPoints"))
        return QStringLiteral("HP");
    if (key == QLatin1String("Mass") || key == QLatin1String("WeaponMass")
        || key == QLatin1String("ProjectileMass"))
        return QStringLiteral("т");
    if (key.endsWith(QLatin1String("Cost")) || key.startsWith(QLatin1String("Energy"))
        || key.startsWith(QLatin1String("Metal")))
        return QString();

    return QString();
}

QString categoryOf(const QString &key)
{
    const auto it = dict().constFind(key);
    return it != dict().constEnd() ? QString::fromUtf8(it.value().category)
                                   : QStringLiteral("other");
}

QString categoryTitle(const QString &id)
{
    return categories().value(id, id);
}

int categoryOrder(const QString &id)
{
    const int idx = categorySequence().indexOf(id);
    return idx < 0 ? categorySequence().size() : idx;
}

QString tableTitle(const QString &tableName)
{
    if (tableName == QLatin1String("Overheat"))
        return QStringLiteral("Перегрев");
    if (tableName == QLatin1String("Explosion"))
        return QStringLiteral("Взрыв");
    if (tableName == QLatin1String("Firing"))
        return QStringLiteral("Стрельба");
    if (tableName == QLatin1String("Ammo"))
        return QStringLiteral("Боеприпасы");
    if (tableName == QLatin1String("Ammunition"))
        return QStringLiteral("Боеприпасы");
    if (tableName == QLatin1String("ReloadBank"))
        return QStringLiteral("Магазин");
    if (tableName == QLatin1String("ReloadBankMod"))
        return QStringLiteral("Магазин");
    return label(tableName);
}

bool isToggleableTable(const QString &tableName)
{
    // Settings that exist either as a whole block or not at all. The editor
    // shows a switch on the group header to add / delete the block.
    return tableName == QLatin1String("ReloadBank");
}

QString tableChildLabel(const QString &table, const QString &key)
{
    const QString t = table.section(QLatin1Char('.'), -1);
    if (t == QLatin1String("ReloadBank")) {
        if (key == QLatin1String("Max"))
            return QStringLiteral("Ёмкость магазина");
        if (key == QLatin1String("ReloadTime"))
            return QStringLiteral("Время на выстрел");
        if (key == QLatin1String("BaseMult"))
            return QStringLiteral("Базовый множитель");
        if (key == QLatin1String("IndexMult"))
            return QStringLiteral("Прибавка за выстрел");
        if (key == QLatin1String("EnergyMult"))
            return QStringLiteral("Множитель энергии");
        if (key == QLatin1String("MetalMult"))
            return QStringLiteral("Множитель металла");
    }
    return label(key);
}

QString tableChildHint(const QString &table, const QString &key)
{
    const QString t = table.section(QLatin1Char('.'), -1);
    if (t == QLatin1String("ReloadBank")) {
        if (key == QLatin1String("Max"))
            return QStringLiteral("Сколько выстрелов в обойме до перезарядки");
        if (key == QLatin1String("ReloadTime"))
            return QStringLiteral("Время перезарядки одной позиции, в секундах");
        if (key == QLatin1String("BaseMult"))
            return QStringLiteral("Множитель стоимости и времени для первой позиции");
        if (key == QLatin1String("IndexMult"))
            return QStringLiteral("Насколько дороже каждая следующая позиция обоймы");
        if (key == QLatin1String("EnergyMult"))
            return QStringLiteral("Множитель затрат энергии на перезарядку");
        if (key == QLatin1String("MetalMult"))
            return QStringLiteral("Множитель затрат металла на перезарядку");
    }
    return hint(key);
}

const QVector<QPair<QString, QString>> &tableTemplate(const QString &table)
{
    static const QVector<QPair<QString, QString>> bank = {
        {QStringLiteral("Max"), QStringLiteral("8")},
        {QStringLiteral("ReloadTime"), QStringLiteral("0.4")},
        {QStringLiteral("BaseMult"), QStringLiteral("1")},
        {QStringLiteral("IndexMult"), QStringLiteral("0")},
        {QStringLiteral("EnergyMult"), QStringLiteral("1")},
        {QStringLiteral("MetalMult"), QStringLiteral("1")},
    };
    static const QVector<QPair<QString, QString>> empty;
    if (table == QLatin1String("ReloadBank"))
        return bank;
    return empty;
}

bool isTechnicalKey(const QString &key)
{
    if (key.size() < 3)
        return false;
    // ALL_CAPS names are Lua constants (FIELD_*, CONTROL_*, VALIDITYFLAG_*…).
    bool hasLower = false;
    for (const QChar &c : key) {
        if (c.isLower()) {
            hasLower = true;
            break;
        }
    }
    return !hasLower;
}

bool isTechnicalTable(const QString &tableName)
{
    return technicalTables().contains(tableName);
}


// ---------------------------------------------------------------------------
// Templates: every parameter a component of a given kind can have.
// Keys are taken from the game's own weapons/devices/materials so adding a
// missing one is always valid for the engine.
// ---------------------------------------------------------------------------

const QVector<TemplateParam> &weaponTemplate()
{
    static const QVector<TemplateParam> t = {
        // Внешний вид / основные
        {QStringLiteral("Scale"), QStringLiteral("1")},
        {QStringLiteral("SelectionWidth"), QStringLiteral("50.0")},
        {QStringLiteral("SelectionHeight"), QStringLiteral("50.0")},
        {QStringLiteral("SelectionOffset"), QStringLiteral("{ 0.0, -50.5 }")},
        {QStringLiteral("CanFlip"), QStringLiteral("false")},
        {QStringLiteral("Inverted"), QStringLiteral("false")},
        {QStringLiteral("IgnorePlatformSlope"), QStringLiteral("false")},
        {QStringLiteral("DrawBehindTerrain"), QStringLiteral("false")},
        {QStringLiteral("DrawBracket"), QStringLiteral("false")},
        {QStringLiteral("RenderOrder"), QStringLiteral("0")},
        {QStringLiteral("NeutralColour"), QStringLiteral("1")},
        {QStringLiteral("ButtonSpriteBottom"), QStringLiteral("0.664")},
        {QStringLiteral("GroupButtonSpriteBottom"), QStringLiteral("0.81")},
        // Прочность
        {QStringLiteral("HitPoints"), QStringLiteral("100.0")},
        {QStringLiteral("EMPVulnerability"), QStringLiteral("0")},
        // Экономика
        {QStringLiteral("WeaponMass"), QStringLiteral("100.0")},
        {QStringLiteral("EnergyProductionRate"), QStringLiteral("0.0")},
        {QStringLiteral("MetalProductionRate"), QStringLiteral("0.0")},
        {QStringLiteral("EnergyStorageCapacity"), QStringLiteral("0.0")},
        {QStringLiteral("MetalStorageCapacity"), QStringLiteral("0.0")},
        {QStringLiteral("MinWindEfficiency"), QStringLiteral("1")},
        {QStringLiteral("MaxWindHeight"), QStringLiteral("0")},
        {QStringLiteral("MaxRotationalSpeed"), QStringLiteral("0")},
        {QStringLiteral("EnergyFireCost"), QStringLiteral("0.0")},
        {QStringLiteral("MetalFireCost"), QStringLiteral("0.0")},
        {QStringLiteral("NoReclaim"), QStringLiteral("false")},
        {QStringLiteral("Repairable"), QStringLiteral("false")},
        // Стрельба
        {QStringLiteral("ReloadTime"), QStringLiteral("2.0")},
        {QStringLiteral("MinFireSpeed"), QStringLiteral("5000.0")},
        {QStringLiteral("MaxFireSpeed"), QStringLiteral("5000.0")},
        {QStringLiteral("MinFireRadius"), QStringLiteral("500.0")},
        {QStringLiteral("MaxFireRadius"), QStringLiteral("1000.0")},
        {QStringLiteral("MinFireAngle"), QStringLiteral("-20")},
        {QStringLiteral("MaxFireAngle"), QStringLiteral("45")},
        {QStringLiteral("DefaultFireAngle"), QStringLiteral("0")},
        {QStringLiteral("ForceFireAngle"), QStringLiteral("90"), false},
        {QStringLiteral("MaxFireClamp"), QStringLiteral("0.8")},
        {QStringLiteral("FireStdDev"), QStringLiteral("0.0")},
        {QStringLiteral("FireStdDevAuto"), QStringLiteral("0.0")},
        {QStringLiteral("FireDelay"), QStringLiteral("0.1")},
        {QStringLiteral("Recoil"), QStringLiteral("0")},
        {QStringLiteral("KickbackMean"), QStringLiteral("0")},
        {QStringLiteral("KickbackStdDev"), QStringLiteral("0")},
        {QStringLiteral("PanDuration"), QStringLiteral("0")},
        {QStringLiteral("MouseSensitivityFactor"), QStringLiteral("0.5")},
        {QStringLiteral("BarrelLength"), QStringLiteral("60.0")},
        {QStringLiteral("MinFireClearance"), QStringLiteral("500")},
        {QStringLiteral("FireClearanceOffsetInner"), QStringLiteral("20")},
        {QStringLiteral("FireClearanceOffsetOuter"), QStringLiteral("40")},
        {QStringLiteral("AttractZoomOutDuration"), QStringLiteral("5")},
        {QStringLiteral("ShowFireAngle"), QStringLiteral("false")},
        {QStringLiteral("ShowFireSpeed"), QStringLiteral("false")},
        {QStringLiteral("ShowAimingGizmo"), QStringLiteral("false")},
        {QStringLiteral("HoldToFire"), QStringLiteral("false")},
        {QStringLiteral("BarrelRecoilLimit"), QStringLiteral("-0.25")},
        {QStringLiteral("BarrelRecoilSpeed"), QStringLiteral("-2")},
        {QStringLiteral("BarrelReturnForce"), QStringLiteral("0.5")},
        {QStringLiteral("MaxTestDistance"), QStringLiteral("600")},
        {QStringLiteral("MinTestDistance"), QStringLiteral("25")},
        // Боеприпасы
        {QStringLiteral("RoundsEachBurst"), QStringLiteral("1")},
        {QStringLiteral("RoundPeriod"), QStringLiteral("1")},
        {QStringLiteral("ReloadTimeIncludesBurst"), QStringLiteral("false")},
        // Магазин: необязательный блок, в новый файл не пишется (включается
        // переключателем в разделе «Магазин»).
        {QStringLiteral("ReloadBank"), QString(), false},
        // Урон
        {QStringLiteral("DeviceSplashDamage"), QStringLiteral("0")},
        {QStringLiteral("DeviceSplashDamageMaxRadius"), QStringLiteral("0")},
        {QStringLiteral("DeviceSplashDamageDelay"), QStringLiteral("0.2")},
        {QStringLiteral("StructureSplashDamage"), QStringLiteral("0")},
        {QStringLiteral("StructureSplashDamageMaxRadius"), QStringLiteral("0")},
        {QStringLiteral("IncendiaryRadius"), QStringLiteral("0")},
        {QStringLiteral("IncendiaryRadiusHeated"), QStringLiteral("0")},
        {QStringLiteral("BlockPenetration"), QStringLiteral("false")},
        // Перегрев
        {QStringLiteral("CanOverheat"), QStringLiteral("false")},
        {QStringLiteral("HeatPeriod"), QStringLiteral("1.8")},
        {QStringLiteral("CoolPeriod"), QStringLiteral("5")},
        {QStringLiteral("CoolPeriodOverheated"), QStringLiteral("7")},
        // Снаряд
        {QStringLiteral("Projectile"), QStringLiteral("\"cannon\"")},
        {QStringLiteral("ProjectileMass"), QStringLiteral("1.0")},
        {QStringLiteral("ProjectileDrag"), QStringLiteral("0.0")},
        {QStringLiteral("ProjectileDamage"), QStringLiteral("0")},
        {QStringLiteral("ProjectileThickness"), QStringLiteral("1.0")},
        {QStringLiteral("ProjectileShootDownRadius"), QStringLiteral("0")},
        {QStringLiteral("DeflectedByShields"), QStringLiteral("true")},
        {QStringLiteral("ExplodeOnTouch"), QStringLiteral("true")},
        // Эффекты
        {QStringLiteral("FireEffect"), QStringLiteral("\"effects/fire_cannon.lua\"")},
        {QStringLiteral("ConstructEffect"), QStringLiteral("\"effects/device_construct.lua\"")},
        {QStringLiteral("CompleteEffect"), QStringLiteral("\"effects/device_complete.lua\"")},
        {QStringLiteral("DestroyEffect"), QStringLiteral("\"effects/cannon_explode.lua\"")},
        {QStringLiteral("DestroyUnderwaterEffect"), QStringLiteral("\"effects/device_explode_large.lua\"")},
        {QStringLiteral("ShellEffect"), QStringLiteral("\"effects/shell_eject_cannon.lua\"")},
        {QStringLiteral("ReloadEffect"), QStringLiteral("\"effects/reload_cannon.lua\"")},
        {QStringLiteral("ReloadEffectOffset"), QStringLiteral("-1.5")},
        {QStringLiteral("HurtEffect"), QStringLiteral("\"effects/reactor_hurt.lua\"")},
        {QStringLiteral("HurtMinDelay"), QStringLiteral("3")},
        {QStringLiteral("CutOffEffects"), QStringLiteral("true")},
        {QStringLiteral("IgnitePlatformOnDestruct"), QStringLiteral("false")},
        {QStringLiteral("ExplodeWhenOutOfWorld"), QStringLiteral("true")},
        // Поведение
        {QStringLiteral("Enabled"), QStringLiteral("true")},
        {QStringLiteral("TeamOwned"), QStringLiteral("true")},
        {QStringLiteral("ClaimsStructures"), QStringLiteral("false")},
        {QStringLiteral("BuildOnGroundOnly"), QStringLiteral("false")},
        {QStringLiteral("DisruptionBlocksFire"), QStringLiteral("false")},
        {QStringLiteral("ExcludeUnlockAll"), QStringLiteral("false")},
    };
    return t;
}

const QVector<TemplateParam> &deviceTemplate()
{
    static const QVector<TemplateParam> t = {
        {QStringLiteral("Scale"), QStringLiteral("1.0")},
        {QStringLiteral("SelectionWidth"), QStringLiteral("40.0")},
        {QStringLiteral("SelectionHeight"), QStringLiteral("40.0")},
        {QStringLiteral("SelectionOffset"), QStringLiteral("{ 0.0, -40.5 }")},
        {QStringLiteral("DrawBehindTerrain"), QStringLiteral("false")},
        {QStringLiteral("DrawBracket"), QStringLiteral("false")},
        {QStringLiteral("NeutralColour"), QStringLiteral("1")},
        {QStringLiteral("ButtonSpriteBottom"), QStringLiteral("0.664")},
        {QStringLiteral("HitPoints"), QStringLiteral("100.0")},
        {QStringLiteral("Mass"), QStringLiteral("40.0")},
        {QStringLiteral("EMPVulnerability"), QStringLiteral("0")},
        {QStringLiteral("EnergyProductionRate"), QStringLiteral("0.0")},
        {QStringLiteral("MetalProductionRate"), QStringLiteral("0.0")},
        {QStringLiteral("EnergyStorageCapacity"), QStringLiteral("0.0")},
        {QStringLiteral("MetalStorageCapacity"), QStringLiteral("0.0")},
        {QStringLiteral("MinWindEfficiency"), QStringLiteral("1")},
        {QStringLiteral("MaxWindHeight"), QStringLiteral("0")},
        {QStringLiteral("MaxRotationalSpeed"), QStringLiteral("0")},
        {QStringLiteral("MinWindAngle"), QStringLiteral("-10")},
        {QStringLiteral("MaxWindAngle"), QStringLiteral("10")},
        {QStringLiteral("MinWindCrossFlow"), QStringLiteral("0.35")},
        {QStringLiteral("MinWindNoCrossFlow"), QStringLiteral("0.3")},
        {QStringLiteral("NoReclaim"), QStringLiteral("false")},
        {QStringLiteral("Repairable"), QStringLiteral("false")},
        {QStringLiteral("DeviceSplashDamage"), QStringLiteral("0")},
        {QStringLiteral("DeviceSplashDamageMaxRadius"), QStringLiteral("0")},
        {QStringLiteral("DeviceSplashDamageDelay"), QStringLiteral("0.2")},
        {QStringLiteral("StructureSplashDamage"), QStringLiteral("0")},
        {QStringLiteral("StructureSplashDamageMaxRadius"), QStringLiteral("0")},
        {QStringLiteral("IncendiaryRadius"), QStringLiteral("0")},
        {QStringLiteral("IncendiaryRadiusHeated"), QStringLiteral("0")},
        {QStringLiteral("BlockPenetration"), QStringLiteral("false")},
        {QStringLiteral("UnderwaterDamageRate"), QStringLiteral("10")},
        {QStringLiteral("UnderwaterDamageMinDepth"), QStringLiteral("20")},
        {QStringLiteral("UnderwaterDamageMinAngle"), QStringLiteral("30")},
        {QStringLiteral("UnderwaterDamageMaxStructureRadius"), QStringLiteral("150")},
        {QStringLiteral("ConstructEffect"), QStringLiteral("\"effects/device_construct.lua\"")},
        {QStringLiteral("CompleteEffect"), QStringLiteral("\"effects/device_complete.lua\"")},
        {QStringLiteral("DestroyEffect"), QStringLiteral("\"effects/device_explode.lua\"")},
        {QStringLiteral("DestroyUnderwaterEffect"), QStringLiteral("\"effects/device_explode_submerged.lua\"")},
        {QStringLiteral("HurtEffect"), QStringLiteral("\"effects/reactor_hurt.lua\"")},
        {QStringLiteral("HurtMinDelay"), QStringLiteral("3")},
        {QStringLiteral("SmokeEmitter"), QStringLiteral("StandardDeviceSmokeEmitter")},
        {QStringLiteral("Mesh"), QStringLiteral("\"devices/battery/battery\"")},
        {QStringLiteral("IgnitePlatformOnDestruct"), QStringLiteral("false")},
        {QStringLiteral("ExplodeWhenOutOfWorld"), QStringLiteral("true")},
        {QStringLiteral("Enabled"), QStringLiteral("true")},
        {QStringLiteral("TeamOwned"), QStringLiteral("true")},
        {QStringLiteral("ClaimsStructures"), QStringLiteral("false")},
        {QStringLiteral("BuildOnGroundOnly"), QStringLiteral("false")},
        {QStringLiteral("MaxTestDistance"), QStringLiteral("600")},
        {QStringLiteral("MinTestDistance"), QStringLiteral("25")},
        {QStringLiteral("StandardMaxUpAngle"), QStringLiteral("20")},
    };
    return t;
}

const QVector<TemplateParam> &materialTemplate()
{
    static const QVector<TemplateParam> t = {
        {QStringLiteral("StandardMinLength"), QStringLiteral("37.5")},
        {QStringLiteral("StandardMaxLength"), QStringLiteral("150")},
        {QStringLiteral("StandardMaxLinkLength"), QStringLiteral("218")},
    };
    return t;
}


const QVector<TemplateParam> &projectileTemplate()
{
    static const QVector<TemplateParam> t = {
        // Снаряд
        {QStringLiteral("ProjectileType"), QStringLiteral("\"bullet\"")},
        {QStringLiteral("ProjectileSprite"), QStringLiteral("\"weapons/media/bullet\"")},
        {QStringLiteral("ProjectileSpriteMipMap"), QStringLiteral("false")},
        {QStringLiteral("ProjectileMass"), QStringLiteral("0.25")},
        {QStringLiteral("ProjectileDrag"), QStringLiteral("0.021")},
        {QStringLiteral("ProjectileThickness"), QStringLiteral("2.0")},
        {QStringLiteral("ProjectileShootDownRadius"), QStringLiteral("14")},
        {QStringLiteral("ProjectileDamage"), QStringLiteral("6.0")},
        {QStringLiteral("ProjectileSplashDamage"), QStringLiteral("0")},
        {QStringLiteral("ProjectileSplashDamageMaxRadius"), QStringLiteral("0")},
        {QStringLiteral("ProjectileSplashMaxForce"), QStringLiteral("0")},
        {QStringLiteral("ProjectileIncendiary"), QStringLiteral("false")},
        {QStringLiteral("SpeedIndicatorFactor"), QStringLiteral("5.0")},
        {QStringLiteral("MinAge"), QStringLiteral("2.5")},
        {QStringLiteral("MaxAge"), QStringLiteral("20")},
        {QStringLiteral("Impact"), QStringLiteral("10000")},
        {QStringLiteral("ImpactMomentumLimit"), QStringLiteral("2000")},
        {QStringLiteral("ImpactSize"), QStringLiteral("1.0")},
        {QStringLiteral("MomentumThreshold"), QStringLiteral("0")},
        {QStringLiteral("WeaponDamageBonus"), QStringLiteral("0")},
        {QStringLiteral("PenetrationDamage"), QStringLiteral("0")},
        {QStringLiteral("PenetrationSpeedMultiplier"), QStringLiteral("1.0")},
        {QStringLiteral("DamageMultiplier"), QStringLiteral("1.0")},
        {QStringLiteral("AntiAirDamage"), QStringLiteral("0")},
        // Поведение
        {QStringLiteral("ExpiresOnFreeFall"), QStringLiteral("false")},
        {QStringLiteral("DrawBlurredProjectile"), QStringLiteral("true")},
        {QStringLiteral("DeflectedByShields"), QStringLiteral("true")},
        {QStringLiteral("DeflectedByTerrain"), QStringLiteral("false")},
        {QStringLiteral("ExplodeOnTouch"), QStringLiteral("false")},
        {QStringLiteral("FlipSpriteFacingLeft"), QStringLiteral("false")},
        {QStringLiteral("IgnitesBackgroundMaterials"), QStringLiteral("false")},
        {QStringLiteral("IgnitesBackgroundMaterialsPassing"), QStringLiteral("false")},
        {QStringLiteral("PassesThroughMaterials"), QStringLiteral("false")},
        {QStringLiteral("DisableShields"), QStringLiteral("false")},
        {QStringLiteral("DestroyShields"), QStringLiteral("false")},
        {QStringLiteral("EnemyCanTeleport"), QStringLiteral("false")},
        // Луч
        {QStringLiteral("BeamDamage"), QStringLiteral("0")},
        {QStringLiteral("BeamTileRate"), QStringLiteral("0.02")},
        {QStringLiteral("BeamScrollRate"), QStringLiteral("0.0")},
        {QStringLiteral("BeamOcclusionDistance"), QStringLiteral("0")},
        {QStringLiteral("BeamOcclusionDistanceWater"), QStringLiteral("0")},
        // Эффекты
        {QStringLiteral("TrailEffect"), QStringLiteral("\"effects/bullet_trail.lua\"")},
        // Прочие реальные поля снаряда
        {QStringLiteral("Name"), QStringLiteral("\"new projectile\"")},
        {QStringLiteral("AntiAirHitpoints"), QStringLiteral("1")},
        {QStringLiteral("AlwaysIncendiary"), QStringLiteral("false")},
        {QStringLiteral("IgnitesBackgroundMaterials"), QStringLiteral("false")},
        {QStringLiteral("IgnitesBackgroundMaterialsPassing"), QStringLiteral("false")},
        {QStringLiteral("IgnitesBackgroundMaterialsPassingSource"), QStringLiteral("false")},
        {QStringLiteral("CollidesWithBeams"), QStringLiteral("false")},
        {QStringLiteral("Terminate"), QStringLiteral("true")},
        {QStringLiteral("BeamBackgroundSplit"), QStringLiteral("0.5")},
        {QStringLiteral("BeamBackgroundDamageIsBonus"), QStringLiteral("false")},
        {QStringLiteral("CruiseTargetDistance"), QStringLiteral("300")},
        {QStringLiteral("CruiseTargetDuration"), QStringLiteral("0.35")},
        {QStringLiteral("MaxSteerPerSecond"), QStringLiteral("150")},
        {QStringLiteral("MinTargetUpdateDistance"), QStringLiteral("2000")},
        {QStringLiteral("LaunchThrust"), QStringLiteral("60000")},
        {QStringLiteral("RocketThrust"), QStringLiteral("45000")},
        {QStringLiteral("RocketThrustChange"), QStringLiteral("45000")},
        {QStringLiteral("EMPSensitivity"), QStringLiteral("4")},
        {QStringLiteral("EnemyCanTeleport"), QStringLiteral("false")},
    };
    return t;
}


const QVector<TemplateParam> &weaponListTemplate()
{
    static const QVector<TemplateParam> t = {
        // Основные
        {QStringLiteral("Enabled"), QStringLiteral("true")},
        {QStringLiteral("SaveName"), QStringLiteral("\"newWeapon\"")},
        {QStringLiteral("FileName"), QStringLiteral("\"weapons/new_weapon.lua\"")},
        // Стоимость
        {QStringLiteral("MetalCost"), QStringLiteral("600")},
        {QStringLiteral("EnergyCost"), QStringLiteral("4000")},
        {QStringLiteral("MetalRepairCost"), QStringLiteral("200")},
        {QStringLiteral("EnergyRepairCost"), QStringLiteral("1500")},
        {QStringLiteral("NoReclaim"), QStringLiteral("false")},
        // Технология
        {QStringLiteral("Prerequisite"), QStringLiteral("\"armoury\"")},
        {QStringLiteral("PrerequisiteAlt"), QStringLiteral("\"workshop\"")},
        {QStringLiteral("CompatibleGroupTypes"), QStringLiteral("{ \"cannon\" }")},
        // Интерфейс
        {QStringLiteral("Icon"), QStringLiteral("\"hud-cannon-icon\"")},
        {QStringLiteral("GroupButton"), QStringLiteral("\"hud-group-cannon\"")},
        {QStringLiteral("Detail"), QStringLiteral("\"hud-detail-cannon\"")},
        {QStringLiteral("SelectEffect"), QStringLiteral("\"ui/hud/weapons/ui_weapons\"")},
        {QStringLiteral("RenderOrder"), QStringLiteral("0")},
        // Строительство
        {QStringLiteral("BuildTimeComplete"), QStringLiteral("60.0")},
        {QStringLiteral("ScrapPeriod"), QStringLiteral("8")},
        {QStringLiteral("BuildQueueConcurrent"), QStringLiteral("1")},
        // Поведение
        {QStringLiteral("BuildOnGroundOnly"), QStringLiteral("false")},
        {QStringLiteral("IgnitePlatformOnDestruct"), QStringLiteral("true")},
        {QStringLiteral("TeamOwned"), QStringLiteral("true")},
        {QStringLiteral("ObserverBuildEvent"), QStringLiteral("true")},
        {QStringLiteral("MaxUpAngle"), QStringLiteral("20")},
        {QStringLiteral("MaxSpotterAssistance"), QStringLiteral("1")},
        {QStringLiteral("IsBehindDevices"), QStringLiteral("false")},
        {QStringLiteral("ExcludeUnlockAll"), QStringLiteral("false")},
    };
    return t;
}

const QVector<TemplateParam> &deviceListTemplate()
{
    static const QVector<TemplateParam> t = {
        // Основные
        {QStringLiteral("Enabled"), QStringLiteral("true")},
        {QStringLiteral("SaveName"), QStringLiteral("\"newDevice\"")},
        {QStringLiteral("FileName"), QStringLiteral("\"devices/new_device.lua\"")},
        // Стоимость
        {QStringLiteral("MetalCost"), QStringLiteral("300")},
        {QStringLiteral("EnergyCost"), QStringLiteral("2000")},
        {QStringLiteral("MetalRepairCost"), QStringLiteral("200")},
        {QStringLiteral("EnergyRepairCost"), QStringLiteral("1500")},
        {QStringLiteral("ScoreWeight"), QStringLiteral("10")},
        {QStringLiteral("NoReclaim"), QStringLiteral("false")},
        // Технология
        {QStringLiteral("Prerequisite"), QStringLiteral("\"workshop\"")},
        {QStringLiteral("PrerequisiteAlt"), QStringLiteral("\"factory\"")},
        // Интерфейс
        {QStringLiteral("Icon"), QStringLiteral("\"hud-reactor-icon\"")},
        {QStringLiteral("Detail"), QStringLiteral("\"hud-detail-reactor\"")},
        {QStringLiteral("ShowDetails"), QStringLiteral("false")},
        {QStringLiteral("SelectEffect"), QStringLiteral("\"ui/hud/devices/ui_devices\"")},
        // Строительство
        {QStringLiteral("BuildTimeComplete"), QStringLiteral("30.0")},
        {QStringLiteral("ScrapPeriod"), QStringLiteral("8")},
        {QStringLiteral("BuildQueueConcurrent"), QStringLiteral("1")},
        {QStringLiteral("AllowOverlap"), QStringLiteral("false")},
        {QStringLiteral("AlignToCursorNormal"), QStringLiteral("false")},
        {QStringLiteral("BuildOnOreOnly"), QStringLiteral("false")},
        {QStringLiteral("MaxUpAngle"), QStringLiteral("20")},
        // Поведение
        {QStringLiteral("BuildOnGroundOnly"), QStringLiteral("false")},
        {QStringLiteral("TeamOwned"), QStringLiteral("true")},
        {QStringLiteral("SpotterTarget"), QStringLiteral("false")},
        {QStringLiteral("ObserverBuildEvent"), QStringLiteral("true")},
        {QStringLiteral("ExcludeUnlockAll"), QStringLiteral("false")},
    };
    return t;
}

const QVector<TemplateParam> &emptyTemplate()
{
    static const QVector<TemplateParam> t;
    return t;
}


const QVector<TemplateParam> &templateForFile(const QString &relPath, const QString &componentArray)
{
    if (componentArray == QLatin1String("Projectiles"))
        return projectileTemplate();
    if (componentArray == QLatin1String("Weapons") || componentArray == QLatin1String("Upgrades"))
        return weaponListTemplate();
    if (componentArray == QLatin1String("Devices") || componentArray == QLatin1String("Ammo"))
        return deviceListTemplate();
    return templateFor(QFileInfo(relPath).path().section(QLatin1Char('/'), 0, 0));
}

const QVector<TemplateParam> &templateFor(const QString &folder)
{
    if (folder == QLatin1String("weapons"))
        return weaponTemplate();
    if (folder == QLatin1String("devices"))
        return deviceTemplate();
    if (folder == QLatin1String("materials"))
        return materialTemplate();
    return emptyTemplate();
}


// ---------------------------------------------------------------------------
// File-kind aware grouping
// ---------------------------------------------------------------------------

namespace {

// projectile_list.lua keys -> section
const QHash<QString, QString> &projCategories()
{
    static const QHash<QString, QString> m = {
        {QStringLiteral("SaveName"), QStringLiteral("proj_main")},
        {QStringLiteral("Name"), QStringLiteral("proj_main")},
        {QStringLiteral("ProjectileType"), QStringLiteral("proj_main")},
        {QStringLiteral("ProjectileSprite"), QStringLiteral("proj_main")},
        {QStringLiteral("ProjectileSpriteMipMap"), QStringLiteral("proj_main")},
        {QStringLiteral("Sprite"), QStringLiteral("proj_main")},
        {QStringLiteral("Scale"), QStringLiteral("proj_main")},
        {QStringLiteral("FlipSpriteFacingLeft"), QStringLiteral("proj_main")},
        {QStringLiteral("Age"), QStringLiteral("proj_main")},

        {QStringLiteral("ProjectileMass"), QStringLiteral("proj_flight")},
        {QStringLiteral("ProjectileDrag"), QStringLiteral("proj_flight")},
        {QStringLiteral("ProjectileThickness"), QStringLiteral("proj_flight")},
        {QStringLiteral("ProjectileShootDownRadius"), QStringLiteral("proj_flight")},
        {QStringLiteral("SpeedIndicatorFactor"), QStringLiteral("proj_flight")},
        {QStringLiteral("MinAge"), QStringLiteral("proj_flight")},
        {QStringLiteral("MaxAge"), QStringLiteral("proj_flight")},
        {QStringLiteral("ExpiresOnFreeFall"), QStringLiteral("proj_flight")},
        {QStringLiteral("DrawBlurredProjectile"), QStringLiteral("proj_flight")},

        {QStringLiteral("ProjectileDamage"), QStringLiteral("proj_damage")},
        {QStringLiteral("WeaponDamageBonus"), QStringLiteral("proj_damage")},
        {QStringLiteral("AntiAirDamage"), QStringLiteral("proj_damage")},
        {QStringLiteral("PenetrationDamage"), QStringLiteral("proj_damage")},
        {QStringLiteral("PenetrationSpeedMultiplier"), QStringLiteral("proj_damage")},
        {QStringLiteral("DamageMultiplier"), QStringLiteral("proj_damage")},
        {QStringLiteral("ProjectileIncendiary"), QStringLiteral("proj_damage")},
        {QStringLiteral("AlwaysIncendiary"), QStringLiteral("proj_damage")},
        {QStringLiteral("IncendiaryRadius"), QStringLiteral("proj_damage")},
        {QStringLiteral("IncendiaryRadiusHeated"), QStringLiteral("proj_damage")},
        {QStringLiteral("IgnitesBackgroundMaterials"), QStringLiteral("proj_damage")},
        {QStringLiteral("IgnitesBackgroundMaterialsPassing"), QStringLiteral("proj_damage")},
        {QStringLiteral("IgnitesBackgroundMaterialsPassingSource"), QStringLiteral("proj_damage")},

        {QStringLiteral("ProjectileSplashDamage"), QStringLiteral("proj_splash")},
        {QStringLiteral("ProjectileSplashDamageMaxRadius"), QStringLiteral("proj_splash")},
        {QStringLiteral("ProjectileSplashMaxForce"), QStringLiteral("proj_splash")},
        {QStringLiteral("Splash"), QStringLiteral("proj_splash")},
        {QStringLiteral("Impact"), QStringLiteral("proj_splash")},
        {QStringLiteral("ImpactMomentumLimit"), QStringLiteral("proj_splash")},
        {QStringLiteral("ImpactSize"), QStringLiteral("proj_splash")},
        {QStringLiteral("Terminate"), QStringLiteral("proj_splash")},
        {QStringLiteral("DeviceSplashDamage"), QStringLiteral("proj_splash")},
        {QStringLiteral("DeviceSplashDamageMaxRadius"), QStringLiteral("proj_splash")},
        {QStringLiteral("DeviceSplashDamageDelay"), QStringLiteral("proj_splash")},
        {QStringLiteral("StructureSplashDamage"), QStringLiteral("proj_splash")},
        {QStringLiteral("StructureSplashDamageMaxRadius"), QStringLiteral("proj_splash")},

        {QStringLiteral("DeflectedByShields"), QStringLiteral("proj_armour")},
        {QStringLiteral("DeflectedByTerrain"), QStringLiteral("proj_armour")},
        {QStringLiteral("ExplodeOnTouch"), QStringLiteral("proj_armour")},
        {QStringLiteral("PassesThroughMaterials"), QStringLiteral("proj_armour")},
        {QStringLiteral("MomentumThreshold"), QStringLiteral("proj_armour")},
        {QStringLiteral("DestroyShields"), QStringLiteral("proj_armour")},
        {QStringLiteral("DisableShields"), QStringLiteral("proj_armour")},
        {QStringLiteral("BlockPenetration"), QStringLiteral("proj_armour")},
        {QStringLiteral("AntiAirHitpoints"), QStringLiteral("proj_armour")},

        {QStringLiteral("BeamDamage"), QStringLiteral("proj_beam")},
        {QStringLiteral("BeamTileRate"), QStringLiteral("proj_beam")},
        {QStringLiteral("BeamScrollRate"), QStringLiteral("proj_beam")},
        {QStringLiteral("BeamOcclusionDistance"), QStringLiteral("proj_beam")},
        {QStringLiteral("BeamOcclusionDistanceWater"), QStringLiteral("proj_beam")},
        {QStringLiteral("BeamBackgroundSplit"), QStringLiteral("proj_beam")},
        {QStringLiteral("BeamBackgroundDamageIsBonus"), QStringLiteral("proj_beam")},
        {QStringLiteral("CollidesWithBeams"), QStringLiteral("proj_beam")},

        {QStringLiteral("RocketThrust"), QStringLiteral("proj_missile")},
        {QStringLiteral("RocketThrustChange"), QStringLiteral("proj_missile")},
        {QStringLiteral("LaunchThrust"), QStringLiteral("proj_missile")},
        {QStringLiteral("CruiseTargetDistance"), QStringLiteral("proj_missile")},
        {QStringLiteral("CruiseTargetDuration"), QStringLiteral("proj_missile")},
        {QStringLiteral("MaxSteerPerSecond"), QStringLiteral("proj_missile")},
        {QStringLiteral("MaxSteerPerSecondErratic"), QStringLiteral("proj_missile")},
        {QStringLiteral("MinTargetUpdateDistance"), QStringLiteral("proj_missile")},
        {QStringLiteral("TargetRearOffsetDistance"), QStringLiteral("proj_missile")},
        {QStringLiteral("ThrustAngleExtent"), QStringLiteral("proj_missile")},
        {QStringLiteral("ErraticThrust"), QStringLiteral("proj_missile")},
        {QStringLiteral("ErraticAngleExtentMax"), QStringLiteral("proj_missile")},
        {QStringLiteral("ErraticAngleExtentStdDev"), QStringLiteral("proj_missile")},
        {QStringLiteral("ErraticAnglePeriodMean"), QStringLiteral("proj_missile")},
        {QStringLiteral("ErraticAnglePeriodStdDev"), QStringLiteral("proj_missile")},
        {QStringLiteral("EMPSensitivity"), QStringLiteral("proj_missile")},
        {QStringLiteral("EMPMissileProbabilityOfCircling"), QStringLiteral("proj_missile")},
        {QStringLiteral("EnemyCanTeleport"), QStringLiteral("proj_missile")},

        {QStringLiteral("TrailEffect"), QStringLiteral("effects")},
        {QStringLiteral("Effect"), QStringLiteral("effects")},
    };
    return m;
}

// weapon_list.lua keys -> section (build-menu record, not the weapon itself)
const QHash<QString, QString> &wlCategories()
{
    static const QHash<QString, QString> m = {
        {QStringLiteral("Enabled"), QStringLiteral("wl_main")},
        {QStringLiteral("SaveName"), QStringLiteral("wl_main")},
        {QStringLiteral("FileName"), QStringLiteral("wl_main")},
        {QStringLiteral("Name"), QStringLiteral("wl_main")},

        {QStringLiteral("MetalCost"), QStringLiteral("wl_cost")},
        {QStringLiteral("EnergyCost"), QStringLiteral("wl_cost")},
        {QStringLiteral("MetalBuildCost"), QStringLiteral("wl_cost")},
        {QStringLiteral("EnergyBuildCost"), QStringLiteral("wl_cost")},
        {QStringLiteral("MetalRepairCost"), QStringLiteral("wl_cost")},
        {QStringLiteral("EnergyRepairCost"), QStringLiteral("wl_cost")},
        {QStringLiteral("MetalReclaim"), QStringLiteral("wl_cost")},
        {QStringLiteral("EnergyReclaim"), QStringLiteral("wl_cost")},
        {QStringLiteral("NoReclaim"), QStringLiteral("wl_cost")},

        {QStringLiteral("Prerequisite"), QStringLiteral("wl_tech")},
        {QStringLiteral("PrerequisiteAlt"), QStringLiteral("wl_tech")},
        {QStringLiteral("Upgrades"), QStringLiteral("wl_upgrades")},
        {QStringLiteral("CompatibleGroupTypes"), QStringLiteral("wl_tech")},

        {QStringLiteral("Icon"), QStringLiteral("wl_ui")},
        {QStringLiteral("GroupButton"), QStringLiteral("wl_ui")},
        {QStringLiteral("Detail"), QStringLiteral("wl_ui")},
        {QStringLiteral("SelectEffect"), QStringLiteral("wl_ui")},
        {QStringLiteral("ButtonSpriteBottom"), QStringLiteral("wl_ui")},
        {QStringLiteral("GroupButtonSpriteBottom"), QStringLiteral("wl_ui")},
        {QStringLiteral("RenderOrder"), QStringLiteral("wl_ui")},

        {QStringLiteral("BuildTimeComplete"), QStringLiteral("wl_build")},
        {QStringLiteral("ScrapPeriod"), QStringLiteral("wl_build")},
        {QStringLiteral("BuildQueueConcurrent"), QStringLiteral("wl_build")},

        {QStringLiteral("BuildOnGroundOnly"), QStringLiteral("wl_behavior")},
        {QStringLiteral("IgnitePlatformOnDestruct"), QStringLiteral("wl_behavior")},
        {QStringLiteral("TeamOwned"), QStringLiteral("wl_behavior")},
        {QStringLiteral("ObserverBuildEvent"), QStringLiteral("wl_behavior")},
        {QStringLiteral("MaxUpAngle"), QStringLiteral("wl_behavior")},
        {QStringLiteral("MaxSpotterAssistance"), QStringLiteral("wl_behavior")},
        {QStringLiteral("IsBehindDevices"), QStringLiteral("wl_behavior")},
        {QStringLiteral("ExcludeUnlockAll"), QStringLiteral("wl_behavior")},
    };
    return m;
}

// device_list.lua / ammo_list.lua keys -> section (build-menu record)
const QHash<QString, QString> &dlCategories()
{
    static const QHash<QString, QString> m = {
        {QStringLiteral("Enabled"), QStringLiteral("dl_main")},
        {QStringLiteral("SaveName"), QStringLiteral("dl_main")},
        {QStringLiteral("FileName"), QStringLiteral("dl_main")},
        {QStringLiteral("Name"), QStringLiteral("dl_main")},

        {QStringLiteral("MetalCost"), QStringLiteral("dl_cost")},
        {QStringLiteral("EnergyCost"), QStringLiteral("dl_cost")},
        {QStringLiteral("MetalBuildCost"), QStringLiteral("dl_cost")},
        {QStringLiteral("EnergyBuildCost"), QStringLiteral("dl_cost")},
        {QStringLiteral("MetalRepairCost"), QStringLiteral("dl_cost")},
        {QStringLiteral("EnergyRepairCost"), QStringLiteral("dl_cost")},
        {QStringLiteral("MetalReclaimMin"), QStringLiteral("dl_cost")},
        {QStringLiteral("MetalReclaimMax"), QStringLiteral("dl_cost")},
        {QStringLiteral("EnergyReclaimMin"), QStringLiteral("dl_cost")},
        {QStringLiteral("EnergyReclaimMax"), QStringLiteral("dl_cost")},
        {QStringLiteral("NoReclaim"), QStringLiteral("dl_cost")},
        {QStringLiteral("ScoreWeight"), QStringLiteral("dl_cost")},

        {QStringLiteral("Prerequisite"), QStringLiteral("dl_tech")},
        {QStringLiteral("PrerequisiteAlt"), QStringLiteral("dl_tech")},
        {QStringLiteral("Tech"), QStringLiteral("dl_tech")},
        {QStringLiteral("Upgrades"), QStringLiteral("dl_tech")},
        {QStringLiteral("CompatibleGroupTypes"), QStringLiteral("dl_tech")},
        {QStringLiteral("ValidityFlags"), QStringLiteral("dl_tech")},
        {QStringLiteral("PopulationCap"), QStringLiteral("dl_tech")},
        {QStringLiteral("RequiresHighSeas"), QStringLiteral("dl_tech")},
        {QStringLiteral("RequiresMoonshot"), QStringLiteral("dl_tech")},

        {QStringLiteral("Icon"), QStringLiteral("dl_ui")},
        {QStringLiteral("Detail"), QStringLiteral("dl_ui")},
        {QStringLiteral("ShowDetails"), QStringLiteral("dl_ui")},
        {QStringLiteral("GroupButton"), QStringLiteral("dl_ui")},
        {QStringLiteral("SelectEffect"), QStringLiteral("dl_ui")},
        {QStringLiteral("HasDummy"), QStringLiteral("dl_ui")},
        {QStringLiteral("ButtonSpriteBottom"), QStringLiteral("dl_ui")},
        {QStringLiteral("GroupButtonSpriteBottom"), QStringLiteral("dl_ui")},
        {QStringLiteral("RenderOrder"), QStringLiteral("dl_ui")},

        {QStringLiteral("BuildTimeComplete"), QStringLiteral("dl_build")},
        {QStringLiteral("ScrapPeriod"), QStringLiteral("dl_build")},
        {QStringLiteral("BuildQueueConcurrent"), QStringLiteral("dl_build")},
        {QStringLiteral("CanMove"), QStringLiteral("dl_build")},
        {QStringLiteral("AllowOverlap"), QStringLiteral("dl_build")},
        {QStringLiteral("AlignToCursorNormal"), QStringLiteral("dl_build")},
        {QStringLiteral("BuildOnOreOnly"), QStringLiteral("dl_build")},
        {QStringLiteral("MaxUpAngle"), QStringLiteral("dl_build")},

        {QStringLiteral("BuildOnGroundOnly"), QStringLiteral("dl_behavior")},
        {QStringLiteral("TeamOwned"), QStringLiteral("dl_behavior")},
        {QStringLiteral("SpotterTarget"), QStringLiteral("dl_behavior")},
        {QStringLiteral("ObserverBuildEvent"), QStringLiteral("dl_behavior")},
        {QStringLiteral("ClaimsStructures"), QStringLiteral("dl_behavior")},
        {QStringLiteral("Repairable"), QStringLiteral("dl_behavior")},
        {QStringLiteral("DisruptionBlocksFire"), QStringLiteral("dl_behavior")},
        {QStringLiteral("IsBehindDevices"), QStringLiteral("dl_behavior")},
        {QStringLiteral("IgnitePlatformOnDestruct"), QStringLiteral("dl_behavior")},
        {QStringLiteral("ExcludeUnlockAll"), QStringLiteral("dl_behavior")},
    };
    return m;
}

} // namespace

Kind kindFor(const QString &relPath, const QString &componentArray)
{
    const QString folder = QFileInfo(relPath).path().section(QLatin1Char('/'), 0, 0);
    const QString name = QFileInfo(relPath).fileName().toLower();

    if (componentArray == QLatin1String("Projectiles"))
        return Kind::Projectile;
    if (componentArray == QLatin1String("Weapons") || componentArray == QLatin1String("Upgrades"))
        return Kind::WeaponList;
    if (componentArray == QLatin1String("Devices") || componentArray == QLatin1String("Ammo"))
        return Kind::DeviceList;

    if (name == QLatin1String("projectile_list.lua"))
        return Kind::Projectile;
    if (name == QLatin1String("weapon_list.lua"))
        return Kind::WeaponList;
    if (name == QLatin1String("device_list.lua") || name == QLatin1String("ammo_list.lua"))
        return Kind::DeviceList;

    if (folder == QLatin1String("weapons"))
        return Kind::Weapon;
    if (folder == QLatin1String("devices"))
        return Kind::Device;
    if (folder == QLatin1String("materials"))
        return Kind::Material;
    return Kind::Generic;
}

bool isConstantName(const QString &key)
{
    if (key.size() < 3 || key != key.toUpper())
        return false;
    for (const QChar &c : key) {
        if (c.isLetter())
            return true;
    }
    return false;
}

QString expectedArrayFor(const QString &relPath)
{
    const QString name = QFileInfo(relPath).fileName().toLower();
    if (name == QLatin1String("projectile_list.lua"))
        return QStringLiteral("Projectiles");
    if (name == QLatin1String("weapon_list.lua"))
        return QStringLiteral("Weapons");
    if (name == QLatin1String("device_list.lua") || name == QLatin1String("ammo_list.lua"))
        return QStringLiteral("Devices");
    return QString();
}

QString categoryFor(Kind kind, const QString &key)
{
    if (isConstantName(key))
        return QStringLiteral("constants");

    if (kind == Kind::Projectile) {
        const auto it = projCategories().constFind(key);
        return it != projCategories().constEnd() ? it.value() : QStringLiteral("other");
    }
    if (kind == Kind::WeaponList) {
        const auto it = wlCategories().constFind(key);
        return it != wlCategories().constEnd() ? it.value() : QStringLiteral("wl_behavior");
    }
    if (kind == Kind::DeviceList) {
        const auto it = dlCategories().constFind(key);
        return it != dlCategories().constEnd() ? it.value() : QStringLiteral("dl_behavior");
    }
    if (kind == Kind::Weapon) {
        const QString cat = categoryOf(key);
        return cat == QLatin1String("other") ? QStringLiteral("behavior") : cat;
    }
    return categoryOf(key);
}

Range rangeFor(const QString &key)
{
    const auto endsWith = [&key](const char *suffix) {
        return key.endsWith(QLatin1String(suffix), Qt::CaseInsensitive);
    };

    // Counts: whole numbers, 1..999
    if (endsWith("Count") || key == QLatin1String("RoundsEachBurst")
        || key == QLatin1String("Ammo") || key == QLatin1String("Capacity"))
        return Range{1, 999, true, true};

    // Fractions
    if (key == QLatin1String("EMPVulnerability") || key == QLatin1String("Armor")
        || key == QLatin1String("MaxFireClamp") || key == QLatin1String("BeamBackgroundSplit")
        || key == QLatin1String("MinWindEfficiency") || key == QLatin1String("MinWindCrossFlow")
        || key == QLatin1String("MinWindNoCrossFlow"))
        return Range{0, 1, false, true};

    // Angles in degrees
    if (key.contains(QLatin1String("Angle")) && !endsWith("StdDev") && !endsWith("Extent"))
        return Range{-180, 180, false, true};

    // Values that can never be negative
    static const char *kNonNegative[] = {
        "Radius", "Distance", "Length", "Width", "Height", "Mass", "Damage", "Force",
        "Speed", "Cost", "Capacity", "Thrust", "HitPoints", "Delay", "Drag",
        "Thickness", "Time", "Period", "Age", "Recoil", "Kickback", "Spread",
    };
    for (const char *suffix : kNonNegative) {
        if (endsWith(suffix))
            return Range{0, -1, false, true};   // -1 = no upper limit
    }

    return Range{};
}

} // namespace ParamCatalog
