#pragma once

#include <QColor>
#include <QIcon>

// All icons are painted with QPainter on a 24x24 logical grid, so the project
// has zero external icon/font dependencies. Colours default to the theme's
// muted text colour unless stated otherwise.
namespace Icons {

QIcon appLogo(int px = 18);
QIcon folder(int px = 18);
QIcon folderOpen(int px = 18);
QIcon fileLua(int px = 18);
QIcon fileImage(int px = 18);
QIcon fileGeneric(int px = 18);
QIcon chevronDown(int px = 14);
QIcon chevronRight(int px = 14);
QIcon refresh(int px = 16);
QIcon collapseAll(int px = 16);
QIcon search(int px = 15);
QIcon plus(int px = 16, const QColor &c = QColor(0xe7, 0xe9, 0xee));
QIcon exportIcon(int px = 16, const QColor &c = QColor(0xd7, 0xdb, 0xe3));
QIcon save(int px = 16, const QColor &c = QColor(0xd7, 0xdb, 0xe3));
QIcon dots(int px = 18);
QIcon gear(int px = 18, const QColor &c = QColor(0x9a, 0xa3, 0xa8));
QIcon target(int px = 18, const QColor &c = QColor(0xa0, 0xbe, 0xae));
QIcon thermometer(int px = 18, const QColor &c = QColor(0xa0, 0xbe, 0xae));
QIcon check(int px = 15, const QColor &c = QColor(0x35, 0xd0, 0x7f));
QIcon info(int px = 15);
QIcon help(int px = 14, const QColor &c = QColor(0x7d, 0x86, 0x8c));
QIcon remove(int px = 13, const QColor &c = QColor(0x7d, 0x86, 0x8c));
QIcon shieldCheck(int px = 16);
QIcon modBox(int px = 18);
QIcon dot(int px = 10, const QColor &c = QColor(0xd7, 0xa9, 0x4a));

} // namespace Icons
