#pragma once

#include <QMainWindow>

#include "ModModel.h"

class ClickableWidget;
class QLabel;
class PropertyPanel;
class QPushButton;
class Sidebar;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);

    // Opens a mod folder; returns false when the folder is not a valid mod.
    bool openMod(const QString &path);

    // Selects a file inside the open mod (path relative to the mod root).
    void selectFile(const QString &relPath);

    // Creates weapons/<name>.lua from the template and registers it in
    // weapon_list.lua. Returns false and fills `error` on failure.
    bool createWeapon(const QString &name, QString *error = nullptr);

    // Creates devices/<name>.lua from the template and registers it in
    // device_list.lua. Returns false and fills `error` on failure.
    bool createDevice(const QString &name, QString *error = nullptr);

    // Creates a new mod ("FMS-Project", "FMS-Project2", …) in `parentDir` from
    // the template shipped with the program. Returns the new mod's path.
    QString createNewMod(const QString &parentDir, QString *error = nullptr);

    // Deletes a parameter from the file currently shown in the properties card.
    bool removeParameter(const QString &path);
    void createNewModInteractive();

    // Values offered by the Prerequisite / Tech pick-lists: the mod's own
    // SaveNames and the ones the base game ships (for diagnostics/tests).
    QStringList technologyChoices() const;
    QStringList gameTechnologies() const;

    // Adds (on = true) or deletes (on = false) an optional nested table such as
    // ReloadBank in the file currently shown. Used by the group switch and tests.
    bool setTableEnabled(const QString &table, bool on);

    // Renames a file/folder inside the open mod and keeps weapon_list.lua in
    // sync. Returns false and fills `error` on failure.
    bool renamePath(const QString &relPath, const QString &newName, QString *error = nullptr);

    // Stores the Forts install root (the folder containing data/mods).
    // On failure returns false and fills `error` with a human-readable reason.
    bool setFortsPath(const QString &dir, QString *error = nullptr);

private:
    QWidget *buildHeader();
    QWidget *buildSecondaryBar();
    void setupStatusBar();

    void updateDirtyUi();
    void saveProject();
    void verifyMod();
    QString defaultModPath() const;
    QString templateRoot() const;
    QString templatePath() const;

    // Tree right-click actions
    void renameEntry(const QString &relPath, bool isDir);
    void addNewWeapon(const QString &folderRelPath);
    void addNewDevice(const QString &folderRelPath);
    bool ensureSaved();

    // Archives: workshop mods ship as .zip, so the editor can unpack and repack.
    void openModFromZip();
    void exportModInteractive();

    // Ctrl+S / Ctrl+Z / Ctrl+Y / Ctrl+O
    void installShortcuts();
    void undoEdit();
    void redoEdit();

    // Path pickers
    void chooseModFolder();
    void chooseFortsFolder();
    void updateFortsUi();

    ModProject m_project;
    QString m_fortsPath;   // root of the Forts install (contains data/mods)

    Sidebar *m_sidebar = nullptr;
    PropertyPanel *m_panel = nullptr;

    QLabel *m_modTitle = nullptr;
    QLabel *m_versionBadge = nullptr;
    QLabel *m_pathLabel = nullptr;
    QLabel *m_dirtyLabel = nullptr;
    QLabel *m_statusSaved = nullptr;
    QLabel *m_fortsPathLabel = nullptr;
    ClickableWidget *m_fortsBar = nullptr;
    QPushButton *m_moreBtn = nullptr;
};
