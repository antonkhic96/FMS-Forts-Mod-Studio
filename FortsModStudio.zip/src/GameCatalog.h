#pragma once

#include <QString>
#include <QStringList>

// Read-only catalogue of values taken from the installed game, used to turn
// free-form text fields into pick-lists ("Снаряд" -> the projectiles the game
// actually has). Everything is cached; call setDataPath() when the Forts folder
// changes.
class GameCatalog
{
public:
    static GameCatalog &instance();

    // `dataPath` is the game's data folder (…/Forts/data).
    void setDataPath(const QString &dataPath);
    QString dataPath() const { return m_dataPath; }
    bool isLoaded() const { return m_loaded; }

    // Allowed values for a parameter key, empty when the value is free-form.
    QStringList choicesFor(const QString &key) const;

    QStringList projectiles() const { return m_projectiles; }
    QStringList projectileTypes() const { return m_projectileTypes; }
    QStringList modCategories() const { return m_modCategories; }
    // Quoted effect paths from the game, e.g. "effects/fire_cannon.lua".
    QStringList effects() const { return m_effects; }
    // SaveName values of the game's own weapons and devices, e.g. "workshop".
    QStringList technologies() const { return m_technologies; }

private:
    GameCatalog() = default;
    void reload();
    void reloadTechnologies();

    QString m_dataPath;
    QStringList m_projectiles;
    QStringList m_projectileTypes;
    QStringList m_modCategories;
    QStringList m_effects;
    QStringList m_technologies;
    bool m_loaded = false;
};
