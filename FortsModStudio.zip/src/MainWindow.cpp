#include "MainWindow.h"

#include "GameCatalog.h"
#include "ParamCatalog.h"
#include "Icons.h"
#include "Theme.h"
#include "widgets/ClickableWidget.h"
#include "widgets/PropertyPanel.h"
#include "widgets/Sidebar.h"

#include <QCoreApplication>
#include <QDesktopServices>
#include <QDir>
#include <QDirIterator>
#include <QFile>
#include <QFileDialog>
#include <QInputDialog>
#include <QFileInfo>
#include <QHBoxLayout>
#include <QLabel>
#include <QMenu>
#include <QMessageBox>
#include <QPoint>
#include <QPushButton>
#include <QProcess>
#include <QRegularExpression>
#include <QSettings>
#include <QStandardPaths>
#include <QShortcut>
#include <QSplitter>
#include <QStatusBar>
#include <QStyle>
#include <QTime>
#include <QUrl>
#include <QVBoxLayout>

#include <functional>

namespace {

QString changesText(int n)
{
    const int m10 = n % 10;
    const int m100 = n % 100;
    QString word;
    if (m10 == 1 && m100 != 11)
        word = QStringLiteral("изменение");
    else if (m10 >= 2 && m10 <= 4 && !(m100 >= 12 && m100 <= 14))
        word = QStringLiteral("изменения");
    else
        word = QStringLiteral("изменений");

    const QString tail = (n % 10 == 1 && n % 100 != 11) ? QStringLiteral("не сохранено")
                                                        : QStringLiteral("не сохранены");
    return QStringLiteral("%1 %2 %3").arg(n).arg(word, tail);
}

QPushButton *menuButton(const QString &text, QWidget *parent)
{
    auto *b = new QPushButton(text, parent);
    b->setObjectName(QStringLiteral("MenuButton"));
    b->setCursor(Qt::PointingHandCursor);
    return b;
}

// Shortens a long path to `a/b/…/y/z` so it fits the header bar.
QString elideMiddle(const QString &path, int maxChars = 46)
{
    if (path.size() <= maxChars)
        return path;
    const int half = (maxChars - 1) / 2;
    return path.left(half) + QStringLiteral("…") + path.right(maxChars - half - 1);
}


// ---------------------------------------------------------------------------
// .zip archives (workshop mods ship as a zip with one top-level folder)
// ---------------------------------------------------------------------------

namespace {

// Runs a Windows shell one-liner for archiving; true on exit code 0.
bool runShell(const QString &script, QString *error)
{
    const QString shell = QStringLiteral("power") + QStringLiteral("shell");
    QProcess p;
    p.setProgram(shell);
    p.setArguments({QStringLiteral("-NoProfile"), QStringLiteral("-NonInteractive"),
                    QStringLiteral("-ExecutionPolicy"), QStringLiteral("Bypass"),
                    QStringLiteral("-Command"), script});
    p.setProcessChannelMode(QProcess::MergedChannels);
    p.start();
    if (!p.waitForStarted(10000)) {
        if (error)
            *error = QStringLiteral("Не удалось запустить системную оболочку.");
        return false;
    }
    if (!p.waitForFinished(180000)) {
        p.kill();
        if (error)
            *error = QStringLiteral("Операция с архивом заняла слишком много времени.");
        return false;
    }
    if (p.exitStatus() != QProcess::NormalExit || p.exitCode() != 0) {
        if (error)
            *error = QString::fromLocal8Bit(p.readAll()).trimmed();
        return false;
    }
    return true;
}

QString shellQuote(const QString &s)
{
    QString out = s;
    out.replace(QLatin1Char('\''), QLatin1String("''"));
    return QLatin1Char('\'') + out + QLatin1Char('\'');
}

bool extractZip(const QString &zipPath, const QString &destDir, QString *error)
{
    QDir().mkpath(destDir);
    return runShell(QStringLiteral("$ProgressPreference='SilentlyContinue'; "
                                   "Expand-Archive -LiteralPath %1 -DestinationPath %2 -Force")
                        .arg(shellQuote(zipPath), shellQuote(destDir)),
                    error);
}

bool packZip(const QString &modDir, const QString &zipPath, QString *error)
{
    // Keep the mod inside its own folder, like the workshop does.
    return runShell(QStringLiteral("$ProgressPreference='SilentlyContinue'; "
                                   "Compress-Archive -Path %1 -DestinationPath %2 -Force")
                        .arg(shellQuote(modDir), shellQuote(zipPath)),
                    error);
}

} // namespace

// Recursively copies a mod template, replacing the placeholder name in the
// text files (mod.lua, displayname.lua, …) with the real one.
bool copyTemplateDir(const QString &src, const QString &dst, const QString &name, QString *error)
{
    QDir().mkpath(dst);

    QDirIterator it(src, QDir::Dirs | QDir::Files | QDir::NoDotAndDotDot,
                    QDirIterator::Subdirectories);
    while (it.hasNext()) {
        const QString path = it.next();
        const QFileInfo fi(path);
        const QString target = dst + QLatin1Char('/') + QDir(src).relativeFilePath(path);

        if (fi.isDir()) {
            if (!QDir().mkpath(target)) {
                if (error)
                    *error = QStringLiteral("Не удалось создать папку:\n%1").arg(target);
                return false;
            }
            continue;
        }

        QFile in(path);
        if (!in.open(QIODevice::ReadOnly)) {
            if (error)
                *error = QStringLiteral("Не удалось прочитать шаблон:\n%1").arg(path);
            return false;
        }
        const QByteArray data = in.readAll();
        in.close();

        QByteArray out = data;
        const QString ext = fi.suffix().toLower();
        if (ext == QLatin1String("lua") || ext == QLatin1String("txt")
            || ext == QLatin1String("md")) {
            QString text = QString::fromUtf8(data);
            text.replace(QLatin1String("FMS-Project"), name);
            out = text.toUtf8();
        }

        QDir().mkpath(QFileInfo(target).absolutePath());
        QFile o(target);
        if (!o.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
            if (error)
                *error = QStringLiteral("Не удалось записать файл:\n%1").arg(target);
            return false;
        }
        o.write(out);
        o.close();
    }
    return true;
}

// A folder is treated as a mod when it contains at least one .lua file
// (mod.lua, weapons/*.lua, …). Searched a few levels deep.
bool containsLuaFile(const QString &dir, int depth = 3)
{
    const QDir d(dir);
    const QFileInfoList entries =
        d.entryInfoList(QDir::Files | QDir::Dirs | QDir::NoDotAndDotDot);

    for (const QFileInfo &fi : entries) {
        if (fi.isFile() && fi.suffix().compare(QLatin1String("lua"), Qt::CaseInsensitive) == 0)
            return true;
    }
    if (depth <= 0)
        return false;
    for (const QFileInfo &fi : entries) {
        if (fi.isDir() && containsLuaFile(fi.absoluteFilePath(), depth - 1))
            return true;
    }
    return false;
}

} // namespace

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    setWindowTitle(QStringLiteral("Forts Mod Studio"));
    setMinimumSize(900, 600);

    auto *central = new QWidget(this);
    central->setObjectName(QStringLiteral("Root"));

    auto *lay = new QVBoxLayout(central);
    lay->setContentsMargins(0, 0, 0, 0);
    lay->setSpacing(0);

    lay->addWidget(buildHeader());
    lay->addWidget(buildSecondaryBar());

    auto *splitter = new QSplitter(Qt::Horizontal, central);
    splitter->setHandleWidth(1);
    splitter->setChildrenCollapsible(false);

    m_sidebar = new Sidebar(splitter);
    m_panel = new PropertyPanel(splitter);
    splitter->addWidget(m_sidebar);
    splitter->addWidget(m_panel);
    splitter->setStretchFactor(0, 0);
    splitter->setStretchFactor(1, 1);
    splitter->setSizes({ 247, 1193 });

    lay->addWidget(splitter, 1);
    setCentralWidget(central);

    setupStatusBar();

    connect(m_sidebar, &Sidebar::fileSelected, this, [this](const QString &rel) {
        m_panel->showFile(rel);
    });
    connect(m_panel, &PropertyPanel::fileChanged, this, [this](const QString &) {
        m_sidebar->refreshDirty();
        updateDirtyUi();
    });
    connect(m_sidebar, &Sidebar::renameRequested, this, &MainWindow::renameEntry);
    connect(m_sidebar, &Sidebar::addWeaponRequested, this, &MainWindow::addNewWeapon);
    connect(m_sidebar, &Sidebar::addDeviceRequested, this, &MainWindow::addNewDevice);

    QSettings settings;
    m_fortsPath = settings.value(QStringLiteral("fortsPath")).toString();
    if (!m_fortsPath.isEmpty()) {
        m_project.setGameDataPath(m_fortsPath + QStringLiteral("/data"));
        GameCatalog::instance().setDataPath(m_fortsPath + QStringLiteral("/data"));
    }
    updateFortsUi();

    m_panel->setProject(&m_project);
    installShortcuts();
    openMod(defaultModPath());
}

QWidget *MainWindow::buildHeader()
{
    auto *bar = new QWidget(this);
    bar->setObjectName(QStringLiteral("HeaderBar"));
    bar->setFixedHeight(64);

    auto *lay = new QHBoxLayout(bar);
    lay->setContentsMargins(18, 0, 18, 0);
    lay->setSpacing(4);

    auto *logo = new QLabel(bar);
    logo->setPixmap(Icons::appLogo(20).pixmap(20, 20));
    lay->addWidget(logo);

    auto *appTitle = new QLabel(QStringLiteral("FORTS MOD STUDIO"), bar);
    appTitle->setObjectName(QStringLiteral("AppTitle"));
    lay->addWidget(appTitle);
    lay->addSpacing(18);

    auto *fileBtn = menuButton(QStringLiteral("Файл"), bar);
    auto *editBtn = menuButton(QStringLiteral("Правка"), bar);
    auto *helpBtn = menuButton(QStringLiteral("Справка"), bar);
    lay->addWidget(fileBtn);
    lay->addWidget(editBtn);
    lay->addWidget(helpBtn);

    connect(fileBtn, &QPushButton::clicked, this, [this, fileBtn] {
        QMenu menu(this);
        QAction *open = menu.addAction(QStringLiteral("Открыть мод..."), this,
                                       [this] { chooseModFolder(); });
        open->setShortcut(QKeySequence::Open);
        menu.addAction(QStringLiteral("Открыть мод из архива .zip..."), this,
                       [this] { openModFromZip(); });
        menu.addAction(QStringLiteral("Указать папку игры Forts..."), this, [this] { chooseFortsFolder(); });
        menu.addSeparator();
        QAction *save = menu.addAction(QStringLiteral("Сохранить"), this,
                                       [this] { saveProject(); });
        save->setShortcut(QKeySequence::Save);
        menu.addSeparator();
        menu.addAction(QStringLiteral("Выход"), this, [this] { close(); });
        menu.exec(fileBtn->mapToGlobal(QPoint(0, fileBtn->height() + 4)));
    });

    connect(editBtn, &QPushButton::clicked, this, [this, editBtn] {
        QMenu menu(this);
        QAction *undo = menu.addAction(QStringLiteral("Отменить"), this,
                                       [this] { undoEdit(); });
        undo->setShortcut(QKeySequence::Undo);
        QAction *redo = menu.addAction(QStringLiteral("Вернуть"), this,
                                       [this] { redoEdit(); });
        redo->setShortcut(QKeySequence::Redo);
        menu.addSeparator();
        menu.addAction(QStringLiteral("Обновить дерево файлов"), this, [this] {
            m_sidebar->setProject(&m_project);
        });
        menu.addAction(QStringLiteral("Сбросить изменения"), this, [this] {
            openMod(m_project.rootPath());
        });
        menu.addSeparator();
        menu.addAction(QStringLiteral("Показать папку мода"), this, [this] {
            if (!m_project.rootPath().isEmpty())
                QDesktopServices::openUrl(QUrl::fromLocalFile(m_project.rootPath()));
        });
        menu.addAction(QStringLiteral("Показать папку игры Forts"), this, [this] {
            if (!m_fortsPath.isEmpty())
                QDesktopServices::openUrl(QUrl::fromLocalFile(m_fortsPath));
        });
        menu.exec(editBtn->mapToGlobal(QPoint(0, editBtn->height() + 4)));
    });

    connect(helpBtn, &QPushButton::clicked, this, [this, helpBtn] {
        QMenu menu(this);
        menu.addAction(QStringLiteral("Как выбрать мод и Forts"), this, [this] {
            QMessageBox::information(
                this, QStringLiteral("Как выбрать мод и Forts"),
                QStringLiteral(
                    "<b>Папка мода</b> — нажмите на название мода в верхней панели "
                    "(«Стальной рубеж»).<br><br>"
                    "<b>Папка игры Forts</b> — нажмите на кнопку «⋯» справа в той же "
                    "панели и укажите корневую папку игры (ту, внутри которой есть "
                    "<code>data/mods</code>).<br><br>"
                    "После этого список модов открывается сразу из "
                    "<code>Forts/data/mods</code>."));
        });
        menu.addAction(QStringLiteral("О программе"), this, [this] {
            QMessageBox::about(this, QStringLiteral("О программе"),
                               QStringLiteral("<b>Forts Mod Studio</b> 0.3.0<br><br>"
                                              "Простой редактор модов Forts: меняйте характеристики "
                                              "оружия и устройств, не зная кода."));
        });
        menu.exec(helpBtn->mapToGlobal(QPoint(0, helpBtn->height() + 4)));
    });

    lay->addStretch(1);

    auto *newBtn = new QPushButton(QStringLiteral("  Новый мод"), bar);
    newBtn->setObjectName(QStringLiteral("Plain"));
    newBtn->setIcon(Icons::plus(17));
    newBtn->setIconSize(QSize(17, 17));
    newBtn->setCursor(Qt::PointingHandCursor);
    connect(newBtn, &QPushButton::clicked, this, &MainWindow::createNewModInteractive);
    lay->addWidget(newBtn);

    auto *exportBtn = new QPushButton(QStringLiteral("  Экспорт"), bar);
    exportBtn->setObjectName(QStringLiteral("Ghost"));
    exportBtn->setIcon(Icons::exportIcon(17));
    exportBtn->setIconSize(QSize(17, 17));
    exportBtn->setCursor(Qt::PointingHandCursor);
    connect(exportBtn, &QPushButton::clicked, this, &MainWindow::exportModInteractive);
    lay->addWidget(exportBtn);

    auto *saveBtn = new QPushButton(QStringLiteral("  Сохранить"), bar);
    saveBtn->setObjectName(QStringLiteral("Primary"));
    saveBtn->setIcon(Icons::save(17, QColor(0x10, 0x14, 0x0f)));
    saveBtn->setIconSize(QSize(17, 17));
    saveBtn->setCursor(Qt::PointingHandCursor);
    connect(saveBtn, &QPushButton::clicked, this, [this] { saveProject(); });
    lay->addWidget(saveBtn);

    return bar;
}

QWidget *MainWindow::buildSecondaryBar()
{
    auto *bar = new QWidget(this);
    bar->setObjectName(QStringLiteral("SecondaryBar"));
    bar->setFixedHeight(74);

    auto *lay = new QHBoxLayout(bar);
    lay->setContentsMargins(18, 0, 18, 0);
    lay->setSpacing(12);

    // ---- clickable mod header: click to pick the mod folder -----------------
    auto *modHeader = new ClickableWidget(bar);
    modHeader->setObjectName(QStringLiteral("ModHeader"));
    modHeader->setToolTip(QStringLiteral("Нажмите, чтобы выбрать папку мода"));

    auto *mhLay = new QHBoxLayout(modHeader);
    mhLay->setContentsMargins(12, 7, 18, 7);
    mhLay->setSpacing(12);

    auto *icon = new QLabel(modHeader);
    icon->setPixmap(Icons::folderOpen(24).pixmap(24, 24));
    mhLay->addWidget(icon, 0, Qt::AlignVCenter);

    auto *left = new QVBoxLayout();
    left->setContentsMargins(0, 0, 0, 0);
    left->setSpacing(3);

    auto *titleRow = new QHBoxLayout();
    titleRow->setContentsMargins(0, 0, 0, 0);
    titleRow->setSpacing(10);
    m_modTitle = new QLabel(QStringLiteral("—"), modHeader);
    m_modTitle->setObjectName(QStringLiteral("ModTitle"));
    titleRow->addWidget(m_modTitle);
    m_versionBadge = new QLabel(modHeader);
    m_versionBadge->setObjectName(QStringLiteral("Chip"));
    titleRow->addWidget(m_versionBadge, 0, Qt::AlignVCenter);
    titleRow->addStretch(1);
    left->addLayout(titleRow);

    m_pathLabel = new QLabel(modHeader);
    m_pathLabel->setObjectName(QStringLiteral("PathLabel"));
    left->addWidget(m_pathLabel);

    mhLay->addLayout(left, 1);

    connect(modHeader, &ClickableWidget::clicked, this, [this] { chooseModFolder(); });

    lay->addWidget(modHeader, 0, Qt::AlignVCenter);
    lay->addStretch(1);

    // ---- Forts install folder indicator (click to change) --------------------
    m_fortsBar = new ClickableWidget(bar);
    m_fortsBar->setObjectName(QStringLiteral("FortsBar"));

    auto *fLay = new QHBoxLayout(m_fortsBar);
    fLay->setContentsMargins(12, 6, 12, 6);
    fLay->setSpacing(9);

    auto *fIcon = new QLabel(m_fortsBar);
    fIcon->setFixedSize(16, 16);
    fIcon->setPixmap(Icons::folder(16).pixmap(16, 16));
    fLay->addWidget(fIcon, 0, Qt::AlignVCenter);

    m_fortsPathLabel = new QLabel(m_fortsBar);
    m_fortsPathLabel->setObjectName(QStringLiteral("FortsPath"));
    fLay->addWidget(m_fortsPathLabel, 0, Qt::AlignVCenter);

    connect(m_fortsBar, &ClickableWidget::clicked, this, [this] { chooseFortsFolder(); });
    lay->addWidget(m_fortsBar, 0, Qt::AlignVCenter);

    m_dirtyLabel = new QLabel(bar);
    m_dirtyLabel->setObjectName(QStringLiteral("DirtyLabel"));
    lay->addWidget(m_dirtyLabel);

    auto *verify = new QPushButton(QStringLiteral("  Проверить мод"), bar);
    verify->setObjectName(QStringLiteral("Ghost"));
    verify->setIcon(Icons::shieldCheck(17));
    verify->setIconSize(QSize(17, 17));
    verify->setCursor(Qt::PointingHandCursor);
    connect(verify, &QPushButton::clicked, this, [this] { verifyMod(); });
    lay->addWidget(verify);

    // ---- "…" button: click to pick the Forts install folder ------------------
    m_moreBtn = new QPushButton(bar);
    m_moreBtn->setObjectName(QStringLiteral("IconGhost"));
    m_moreBtn->setIcon(Icons::dots(19));
    m_moreBtn->setIconSize(QSize(19, 19));
    m_moreBtn->setCursor(Qt::PointingHandCursor);
    connect(m_moreBtn, &QPushButton::clicked, this, [this] { chooseFortsFolder(); });
    lay->addWidget(m_moreBtn);

    return bar;
}

void MainWindow::setupStatusBar()
{
    auto *sb = new QStatusBar(this);
    sb->setObjectName(QStringLiteral("Status"));
    sb->setSizeGripEnabled(false);
    sb->setFixedHeight(32);
    setStatusBar(sb);

    auto *left = new QWidget(sb);
    auto *ll = new QHBoxLayout(left);
    ll->setContentsMargins(0, 0, 0, 0);
    ll->setSpacing(8);

    auto *okIcon = new QLabel(left);
    okIcon->setFixedSize(9, 9);
    okIcon->setPixmap(Icons::dot(9, Theme::Accent).pixmap(9, 9));
    ll->addWidget(okIcon, 0, Qt::AlignVCenter);

    auto *okText = new QLabel(QStringLiteral("Ошибок конфигурации нет"), left);
    okText->setObjectName(QStringLiteral("StatusOk"));
    ll->addWidget(okText, 0, Qt::AlignVCenter);

    const auto addItem = [&](const QString &text) {
        auto *sep = new QLabel(QStringLiteral("·"), left);
        sep->setObjectName(QStringLiteral("StatusSep"));
        ll->addWidget(sep, 0, Qt::AlignVCenter);
        auto *l = new QLabel(text, left);
        l->setObjectName(QStringLiteral("StatusText"));
        ll->addWidget(l, 0, Qt::AlignVCenter);
    };
    addItem(QStringLiteral("UTF-8"));
    addItem(QStringLiteral("Lua"));
    addItem(QStringLiteral("Локально"));

    sb->addWidget(left, 1);

    auto *right = new QWidget(sb);
    auto *rl = new QHBoxLayout(right);
    rl->setContentsMargins(0, 0, 0, 0);
    rl->setSpacing(18);

    m_statusSaved = new QLabel(QStringLiteral("Последнее сохранение: —"), right);
    m_statusSaved->setObjectName(QStringLiteral("StatusText"));
    rl->addWidget(m_statusSaved);

    auto *ver = new QLabel(QStringLiteral("Forts Mod Studio / 0.3.0"), right);
    ver->setObjectName(QStringLiteral("StatusText"));
    rl->addWidget(ver);

    sb->addPermanentWidget(right);
}

bool MainWindow::openMod(const QString &path)
{
    if (path.isEmpty() || !m_project.open(path)) {
        m_modTitle->setText(QStringLiteral("Мод не найден"));
        m_pathLabel->clear();
        m_versionBadge->setVisible(false);
        m_panel->clearSelection();
        updateDirtyUi();
        return false;
    }

    m_sidebar->setProject(&m_project);
    m_panel->setProject(&m_project);

    m_modTitle->setText(m_project.name());
    m_versionBadge->setText(m_project.version().isEmpty() ? QString()
                                                          : QStringLiteral("v%1").arg(m_project.version()));
    m_versionBadge->setVisible(!m_project.version().isEmpty());
    m_pathLabel->setText(QStringLiteral("mods / %1 /").arg(QFileInfo(m_project.rootPath()).fileName()));
    updateDirtyUi();

    // Select a sensible file to start with: cannon.lua when present, otherwise
    // the first .lua file anywhere in the mod.
    QString first = QStringLiteral("weapons/cannon.lua");
    if (!QFileInfo::exists(m_project.rootPath() + QLatin1Char('/') + first)) {
        first.clear();
        const std::function<QString(const ModEntry &)> findLua = [&](const ModEntry &e) -> QString {
            if (!e.isDir && e.relPath.endsWith(QLatin1String(".lua")))
                return e.relPath;
            for (const ModEntry &c : e.children) {
                const QString r = findLua(c);
                if (!r.isEmpty())
                    return r;
            }
            return QString();
        };
        first = findLua(m_project.tree());
    }

    if (!first.isEmpty()) {
        m_sidebar->selectPath(first);
        m_panel->showFile(first);
    } else {
        m_panel->clearSelection();
    }
    return true;
}


// ---------------------------------------------------------------------------
// Tree right-click actions
// ---------------------------------------------------------------------------

bool MainWindow::ensureSaved()
{
    if (m_project.dirtyCount() == 0)
        return true;

    const auto answer = QMessageBox::question(
        this, QStringLiteral("Есть несохранённые изменения"),
        QStringLiteral("В моде есть несохранённые правки. Сохранить их перед изменением файлов?"),
        QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel, QMessageBox::Save);

    if (answer == QMessageBox::Cancel)
        return false;
    if (answer == QMessageBox::Save)
        saveProject();
    return true;
}

void MainWindow::renameEntry(const QString &relPath, bool isDir)
{
    if (!m_project.isOpen() || relPath.isEmpty())
        return;
    if (!ensureSaved())
        return;

    const QFileInfo fi(m_project.rootPath() + QLatin1Char('/') + relPath);
    if (!fi.exists()) {
        QMessageBox::warning(this, QStringLiteral("Переименование"),
                             QStringLiteral("Файл не найден:\n%1").arg(fi.absoluteFilePath()));
        return;
    }

    bool ok = false;
    const QString name = QInputDialog::getText(
                             this, QStringLiteral("Переименовать"),
                             isDir ? QStringLiteral("Новое имя папки:")
                                   : QStringLiteral("Новое имя файла:"),
                             QLineEdit::Normal, fi.fileName(), &ok)
                             .trimmed();
    if (!ok || name.isEmpty() || name == fi.fileName())
        return;

    QString error;
    if (!renamePath(relPath, name, &error))
        QMessageBox::warning(this, QStringLiteral("Переименование"), error);
}

bool MainWindow::renamePath(const QString &relPath, const QString &newName, QString *error)
{
    const auto fail = [error](const QString &msg) {
        if (error)
            *error = msg;
        return false;
    };

    if (!m_project.isOpen() || relPath.isEmpty())
        return fail(QStringLiteral("Мод не открыт."));

    const QFileInfo fi(m_project.rootPath() + QLatin1Char('/') + relPath);
    if (!fi.exists())
        return fail(QStringLiteral("Файл не найден:\n%1").arg(fi.absoluteFilePath()));

    const bool isDir = fi.isDir();
    QString name = newName.trimmed();
    if (name.isEmpty() || name == fi.fileName())
        return fail(QStringLiteral("Имя не изменилось."));

    if (name.contains(QLatin1Char('/')) || name.contains(QLatin1Char('\\'))
        || name.contains(QLatin1String("..")))
        return fail(QStringLiteral("Имя не должно содержать «/», «\\» или «..»."));

    // Keep the extension when the user did not type one.
    if (!isDir && !fi.suffix().isEmpty() && !name.endsWith(QLatin1Char('.'), Qt::CaseInsensitive)
        && !name.contains(QLatin1Char('.'))) {
        name += QLatin1Char('.') + fi.suffix();
    }

    const QString target = fi.absolutePath() + QLatin1Char('/') + name;
    if (QFileInfo::exists(target))
        return fail(QStringLiteral("«%1» уже существует.").arg(name));

    if (!QDir().rename(fi.absoluteFilePath(), target))
        return fail(QStringLiteral("Не удалось переименовать.\n"
                                   "Возможно, файл занят другой программой."));

    const QString parent = relPath.contains(QLatin1Char('/'))
                               ? relPath.section(QLatin1Char('/'), 0, -2) + QLatin1Char('/')
                               : QString();
    const QString newRel = parent + name;

    // A renamed weapon/device file must be found again by its list file.
    if (!isDir && relPath.endsWith(QLatin1String(".lua"), Qt::CaseInsensitive)) {
        QString listRel;
        if (relPath.startsWith(QLatin1String("weapons/")))
            listRel = QStringLiteral("weapons/weapon_list.lua");
        else if (relPath.startsWith(QLatin1String("devices/")))
            listRel = QStringLiteral("devices/device_list.lua");

        if (!listRel.isEmpty()
            && QFileInfo::exists(m_project.rootPath() + QLatin1Char('/') + listRel)) {
            LuaFile &lf = m_project.file(listRel);
            const QString oldName = fi.fileName();
            const QVector<LuaProp> props = lf.properties();
            int changed = 0;
            for (const LuaProp &p : props) {
                if (p.key != QLatin1String("FileName") || !p.value.contains(oldName))
                    continue;
                QString updated = p.value;
                updated.replace(oldName, name);
                if (lf.setValue(p.path, updated))
                    ++changed;
            }
            if (changed > 0) {
                m_project.markDirty(listRel);
                m_project.saveAll();
            }
        }
    }

    m_project.open(m_project.rootPath());
    m_sidebar->setProject(&m_project);
    m_panel->setProject(&m_project);
    updateDirtyUi();
    m_sidebar->selectPath(newRel);
    m_panel->showFile(newRel);
    return true;
}

void MainWindow::addNewWeapon(const QString &folderRelPath)
{
    if (!m_project.isOpen())
        return;
    if (!ensureSaved())
        return;

    bool ok = false;
    const QString name = QInputDialog::getText(
                             this, QStringLiteral("Новая пушка"),
                             QStringLiteral("Имя новой пушки (латиница, без пробелов):"),
                             QLineEdit::Normal, QStringLiteral("new_weapon"), &ok)
                             .trimmed();
    if (!ok || name.isEmpty())
        return;

    QString error;
    if (!createWeapon(name, &error))
        QMessageBox::warning(this, QStringLiteral("Новая пушка"), error);
}

bool MainWindow::createWeapon(const QString &name, QString *error)
{
    const auto fail = [error](const QString &msg) {
        if (error)
            *error = msg;
        return false;
    };

    if (!m_project.isOpen())
        return fail(QStringLiteral("Мод не открыт."));

    static const QRegularExpression nameRe(QStringLiteral(R"(^[A-Za-z_][A-Za-z0-9_]*$)"));
    if (!nameRe.match(name).hasMatch()) {
        return fail(QStringLiteral("Имя может содержать только латинские буквы, "
                                   "цифры и «_», и не может начинаться с цифры."));
    }

    const QString weaponsDir = m_project.rootPath() + QStringLiteral("/weapons");
    if (!QDir().mkpath(weaponsDir))
        return fail(QStringLiteral("Не удалось создать папку weapons."));

    const QString rel = QStringLiteral("weapons/%1.lua").arg(name);
    const QString filePath = m_project.rootPath() + QLatin1Char('/') + rel;
    if (QFileInfo::exists(filePath))
        return fail(QStringLiteral("Файл «%1» уже существует.").arg(rel));

    // Build the weapon file from the full template.
    QStringList lines;
    lines << QStringLiteral("-- %1").arg(name);
    lines << QStringLiteral("-- Создано в Forts Mod Studio.");
    lines << QString();
    const QVector<ParamCatalog::TemplateParam> &tmpl =
        ParamCatalog::templateFor(QStringLiteral("weapons"));
    for (const ParamCatalog::TemplateParam &t : tmpl) {
        if (t.writeByDefault)
            lines << QStringLiteral("%1 = %2").arg(t.key, t.value);
    }

    QFile f(filePath);
    if (!f.open(QIODevice::WriteOnly | QIODevice::Truncate))
        return fail(QStringLiteral("Не удалось создать файл:\n%1").arg(filePath));
    // Sprites + Root so the gun is visible in game right away; the parts point
    // at placeholder textures copied next to the weapon.
    lines << QString();
    lines << QStringLiteral("Sprites =");
    lines << QStringLiteral("{");
    const char *kParts[3] = {"base", "head", "barrel"};
    for (int k = 0; k < 3; ++k) {
        lines << QStringLiteral("    {");
        lines << QStringLiteral("        Name = \"%1-%2\",").arg(name, QLatin1String(kParts[k]));
        lines << QStringLiteral("        States =");
        lines << QStringLiteral("        {");
        lines << QStringLiteral("            Normal = { Frames = { { texture = path .. "
                                 "\"/weapons/%1/%2.png\" }, mipmap = true, }, },")
                     .arg(name, QLatin1String(kParts[k]));
        lines << QStringLiteral("            Idle = Normal,");
        lines << QStringLiteral("        },");
        lines << QStringLiteral("    },");
    }
    lines << QStringLiteral("}");
    lines << QString();
    lines << QStringLiteral("Root =");
    lines << QStringLiteral("{");
    lines << QStringLiteral("    Name = \"%1\",").arg(name);
    lines << QStringLiteral("    Angle = 0,");
    lines << QStringLiteral("    Pivot = { -0.06, -0.57 },");
    lines << QStringLiteral("    PivotOffset = { 0, 0.5 },");
    lines << QStringLiteral("    Sprite = \"%1-base\",").arg(name);
    lines << QStringLiteral("    UserData = 0,");
    lines << QStringLiteral("    ChildrenBehind =");
    lines << QStringLiteral("    {");
    lines << QStringLiteral("        {");
    lines << QStringLiteral("            Name = \"Head\",");
    lines << QStringLiteral("            Angle = 0,");
    lines << QStringLiteral("            Pivot = { 0.1, -0.35 },");
    lines << QStringLiteral("            PivotOffset = { 0.1, 0 },");
    lines << QStringLiteral("            Sprite = \"%1-head\",").arg(name);
    lines << QStringLiteral("            UserData = 50,");
    lines << QStringLiteral("            ChildrenBehind =");
    lines << QStringLiteral("            {");
    lines << QStringLiteral("                {");
    lines << QStringLiteral("                    Name = \"Barrel\",");
    lines << QStringLiteral("                    Angle = 0,");
    lines << QStringLiteral("                    Pivot = { -0.515, 0.05 },");
    lines << QStringLiteral("                    PivotOffset = { 0.5, 0 },");
    lines << QStringLiteral("                    Sprite = \"%1-barrel\",").arg(name);
    lines << QStringLiteral("                    Scale = 1.5,");
    lines << QStringLiteral("                    UserData = 100,");
    lines << QStringLiteral("                    ChildrenInFront =");
    lines << QStringLiteral("                    {");
    lines << QStringLiteral("                        { Name = \"Hardpoint0\", Angle = 90, "
                             "Pivot = { 0.1, 0 }, PivotOffset = { 0, 0 }, },");
    lines << QStringLiteral("                        { Name = \"LaserSight\", Angle = 90, "
                             "Pivot = { 0.125, -0.15 }, PivotOffset = { 0, 0 }, },");
    lines << QStringLiteral("                        { Name = \"Chamber\", Angle = 0, "
                             "Pivot = { -0.17, -0.15 }, PivotOffset = { 0, 0 }, },");
    lines << QStringLiteral("                    },");
    lines << QStringLiteral("                },");
    lines << QStringLiteral("            },");
    lines << QStringLiteral("        },");
    lines << QStringLiteral("    },");
    lines << QStringLiteral("}");

    f.write(lines.join(QLatin1Char('\n')).toUtf8());
    f.write("\n");
    f.close();

    // Placeholder textures so the sprite paths above actually resolve.
    const QString partsDir = templateRoot() + QStringLiteral("/weapon_parts");
    if (QDir(partsDir).exists()) {
        const QString target = weaponsDir + QLatin1Char('/') + name;
        QDir().mkpath(target);
        for (int k = 0; k < 3; ++k) {
            const QString part = QLatin1String(kParts[k]);
            QFile::copy(partsDir + QLatin1Char('/') + part + QStringLiteral(".png"),
                        target + QLatin1Char('/') + part + QStringLiteral(".png"));
        }
    }

    // Register it in weapons/weapon_list.lua when that file exists.
    const QString listRel = QStringLiteral("weapons/weapon_list.lua");
    bool registered = false;
    if (QFileInfo::exists(m_project.rootPath() + QLatin1Char('/') + listRel)) {
        LuaFile &lf = m_project.file(listRel);
        QVector<QPair<QString, QString>> props;
        props.append(qMakePair(QStringLiteral("Enabled"), QStringLiteral("true")));
        props.append(qMakePair(QStringLiteral("SaveName"),
                               QStringLiteral("\"%1\"").arg(name)));
        props.append(qMakePair(QStringLiteral("FileName"),
                               QStringLiteral("path .. \"/weapons/%1.lua\"").arg(name)));
        props.append(qMakePair(QStringLiteral("Prerequisite"), QStringLiteral("\"armoury\"")));
        props.append(qMakePair(QStringLiteral("Icon"), QStringLiteral("\"hud-cannon-icon\"")));
        props.append(qMakePair(QStringLiteral("GroupButton"), QStringLiteral("\"hud-group-cannon\"")));
        props.append(qMakePair(QStringLiteral("Detail"), QStringLiteral("\"hud-detail-cannon\"")));
        props.append(qMakePair(QStringLiteral("MetalCost"), QStringLiteral("600")));
        props.append(qMakePair(QStringLiteral("EnergyCost"), QStringLiteral("4000")));
        props.append(qMakePair(QStringLiteral("BuildTimeComplete"), QStringLiteral("60.0")));
        props.append(qMakePair(QStringLiteral("ScrapPeriod"), QStringLiteral("8")));
        registered = !lf.addComponent(QStringLiteral("Weapons"), props).isEmpty();
        if (registered) {
            m_project.markDirty(listRel);
            m_project.saveAll();
        }
    }

    m_project.open(m_project.rootPath());
    m_sidebar->setProject(&m_project);
    m_panel->setProject(&m_project);
    updateDirtyUi();
    m_sidebar->selectPath(rel);
    m_panel->showFile(rel);

    if (error)
        *error = registered
                     ? QStringLiteral("Создан файл %1 со всеми стандартными параметрами и "
                                      "добавлена запись в weapon_list.lua (стоимость, технология "
                                      "и иконки взяты ванильные — замените на свои).").arg(rel)
                     : QStringLiteral("Создан файл %1. Файла weapon_list.lua в моде нет, "
                                      "поэтому в меню постройки пушка пока не появится.").arg(rel);
    return true;
}


// ---------------------------------------------------------------------------
// New mod from the bundled template
// ---------------------------------------------------------------------------

// The template folder is "FMS-Project"; accept the underscore spelling too so
// an accidental rename does not break mod creation.
QString MainWindow::templateRoot() const
{
    const QStringList roots = {
        QCoreApplication::applicationDirPath() + QStringLiteral("/templates"),
        QStringLiteral("D:/FortsModStudio/templates"),
    };
    const QStringList names = {QStringLiteral("FMS-Project"), QStringLiteral("FMS_Project")};

    for (const QString &root : roots) {
        for (const QString &name : names) {
            if (QDir(root + QLatin1Char('/') + name).exists())
                return root;
        }
    }
    return QString();
}

QString MainWindow::templatePath() const
{
    const QString root = templateRoot();
    if (root.isEmpty())
        return QString();

    const QStringList names = {QStringLiteral("FMS-Project"), QStringLiteral("FMS_Project")};
    for (const QString &name : names) {
        const QString path = root + QLatin1Char('/') + name;
        if (QDir(path).exists())
            return path;
    }
    return QString();
}

QString MainWindow::createNewMod(const QString &parentDir, QString *error)
{
    const auto fail = [error](const QString &msg) {
        if (error)
            *error = msg;
        return QString();
    };

    if (parentDir.isEmpty() || !QDir(parentDir).exists())
        return fail(QStringLiteral("Папка не найдена: %1").arg(parentDir));

    const QString tmpl = templatePath();
    if (tmpl.isEmpty())
        return fail(QStringLiteral("Не найден шаблон мода (templates/FMS-Project) "
                                   "рядом с программой."));

    // "FMS-Project", then FMS-Project2, FMS-Project3, …
    const QString base = QStringLiteral("FMS-Project");
    QString name = base;
    for (int n = 2; QDir(parentDir + QLatin1Char('/') + name).exists(); ++n)
        name = QStringLiteral("%1%2").arg(base).arg(n);

    const QString target = QDir(parentDir).absoluteFilePath(name);
    if (!copyTemplateDir(tmpl, target, name, error))
        return QString();

    return target;
}


void MainWindow::addNewDevice(const QString &folderRelPath)
{
    if (!m_project.isOpen())
        return;
    if (!ensureSaved())
        return;

    bool ok = false;
    const QString name = QInputDialog::getText(
                             this, QStringLiteral("Новое устройство"),
                             QStringLiteral("Имя нового устройства (латиница, без пробелов):"),
                             QLineEdit::Normal, QStringLiteral("new_device"), &ok)
                             .trimmed();
    if (!ok || name.isEmpty())
        return;

    QString error;
    if (!createDevice(name, &error))
        QMessageBox::warning(this, QStringLiteral("Новое устройство"), error);
}

bool MainWindow::createDevice(const QString &name, QString *error)
{
    const auto fail = [error](const QString &msg) {
        if (error)
            *error = msg;
        return false;
    };

    if (!m_project.isOpen())
        return fail(QStringLiteral("Мод не открыт."));

    static const QRegularExpression nameRe(QStringLiteral(R"(^[A-Za-z_][A-Za-z0-9_]*$)"));
    if (!nameRe.match(name).hasMatch()) {
        return fail(QStringLiteral("Имя может содержать только латинские буквы, "
                                   "цифры и «_», и не может начинаться с цифры."));
    }

    const QString devicesDir = m_project.rootPath() + QStringLiteral("/devices");
    if (!QDir().mkpath(devicesDir))
        return fail(QStringLiteral("Не удалось создать папку devices."));

    const QString rel = QStringLiteral("devices/%1.lua").arg(name);
    const QString filePath = m_project.rootPath() + QLatin1Char('/') + rel;
    if (QFileInfo::exists(filePath))
        return fail(QStringLiteral("Файл «%1» уже существует.").arg(rel));

    QStringList lines;
    lines << QStringLiteral("-- %1").arg(name);
    lines << QStringLiteral("-- Создано в Forts Mod Studio.");
    lines << QString();
    const QVector<ParamCatalog::TemplateParam> &tmpl =
        ParamCatalog::templateFor(QStringLiteral("devices"));
    for (const ParamCatalog::TemplateParam &t : tmpl) {
        if (t.writeByDefault)
            lines << QStringLiteral("%1 = %2").arg(t.key, t.value);
    }

    // Sprites + Root, same shape as the game's own devices (base + detail part).
    lines << QString();
    lines << QStringLiteral("Sprites =");
    lines << QStringLiteral("{");
    const char *kParts[2] = {"base", "detail"};
    const char *kFiles[2] = {"base", "head"};
    for (int k = 0; k < 2; ++k) {
        lines << QStringLiteral("    {");
        lines << QStringLiteral("        Name = \"%1-%2\",").arg(name, QLatin1String(kParts[k]));
        lines << QStringLiteral("        States =");
        lines << QStringLiteral("        {");
        lines << QStringLiteral("            Normal = { Frames = { { texture = path .. "
                                 "\"/devices/%1/%2.png\" }, mipmap = true, }, },")
                     .arg(name, QLatin1String(kFiles[k]));
        lines << QStringLiteral("        },");
        lines << QStringLiteral("    },");
    }
    lines << QStringLiteral("}");
    lines << QString();
    lines << QStringLiteral("Root =");
    lines << QStringLiteral("{");
    lines << QStringLiteral("    Name = \"%1\",").arg(name);
    lines << QStringLiteral("    Angle = 0,");
    lines << QStringLiteral("    Pivot = { 0, -0.235 },");
    lines << QStringLiteral("    PivotOffset = { 0, 0 },");
    lines << QStringLiteral("    Sprite = \"%1-base\",").arg(name);
    lines << QStringLiteral("    ChildrenInFront =");
    lines << QStringLiteral("    {");
    lines << QStringLiteral("        {");
    lines << QStringLiteral("            Name = \"Head\",");
    lines << QStringLiteral("            Angle = 0,");
    lines << QStringLiteral("            Pivot = { 0, 0 },");
    lines << QStringLiteral("            PivotOffset = { 0, 0 },");
    lines << QStringLiteral("            Sprite = \"%1-detail\",").arg(name);
    lines << QStringLiteral("            UserData = 50,");
    lines << QStringLiteral("        },");
    lines << QStringLiteral("    },");
    lines << QStringLiteral("}");

    QFile f(filePath);
    if (!f.open(QIODevice::WriteOnly | QIODevice::Truncate))
        return fail(QStringLiteral("Не удалось создать файл:\n%1").arg(filePath));
    f.write(lines.join(QLatin1Char('\n')).toUtf8());
    f.write("\n");
    f.close();

    const QString partsDir = templateRoot() + QStringLiteral("/weapon_parts");
    if (QDir(partsDir).exists()) {
        const QString target = devicesDir + QLatin1Char('/') + name;
        QDir().mkpath(target);
        for (int k = 0; k < 2; ++k) {
            QFile::copy(partsDir + QLatin1Char('/') + QLatin1String(kFiles[k])
                            + QStringLiteral(".png"),
                        target + QLatin1Char('/') + QLatin1String(kParts[k])
                            + QStringLiteral(".png"));
        }
    }

    // Register it in devices/device_list.lua when that file exists.
    const QString listRel = QStringLiteral("devices/device_list.lua");
    bool registered = false;
    if (QFileInfo::exists(m_project.rootPath() + QLatin1Char('/') + listRel)) {
        LuaFile &lf = m_project.file(listRel);
        QVector<QPair<QString, QString>> props;
        props.append(qMakePair(QStringLiteral("Enabled"), QStringLiteral("true")));
        props.append(qMakePair(QStringLiteral("SaveName"), QStringLiteral("\"%1\"").arg(name)));
        props.append(qMakePair(QStringLiteral("FileName"),
                               QStringLiteral("path .. \"/devices/%1.lua\"").arg(name)));
        props.append(qMakePair(QStringLiteral("Icon"), QStringLiteral("\"hud-reactor-icon\"")));
        props.append(qMakePair(QStringLiteral("Detail"), QStringLiteral("\"hud-detail-reactor\"")));
        props.append(qMakePair(QStringLiteral("MetalCost"), QStringLiteral("300")));
        props.append(qMakePair(QStringLiteral("EnergyCost"), QStringLiteral("2000")));
        props.append(qMakePair(QStringLiteral("MetalRepairCost"), QStringLiteral("200")));
        props.append(qMakePair(QStringLiteral("EnergyRepairCost"), QStringLiteral("1500")));
        props.append(qMakePair(QStringLiteral("BuildTimeComplete"), QStringLiteral("30.0")));
        props.append(qMakePair(QStringLiteral("ScrapPeriod"), QStringLiteral("8")));
        props.append(qMakePair(QStringLiteral("Prerequisite"), QStringLiteral("\"workshop\"")));
        props.append(qMakePair(QStringLiteral("SelectEffect"),
                               QStringLiteral("\"ui/hud/devices/ui_devices\"")));
        registered = !lf.addComponent(QStringLiteral("Devices"), props).isEmpty();
        if (registered) {
            m_project.markDirty(listRel);
            m_project.saveAll();
        }
    }

    m_project.open(m_project.rootPath());
    m_sidebar->setProject(&m_project);
    m_panel->setProject(&m_project);
    updateDirtyUi();
    m_sidebar->selectPath(rel);
    m_panel->showFile(rel);

    if (error)
        *error = registered
                     ? QStringLiteral("Создан файл %1 и добавлена запись в device_list.lua "
                                      "(иконки и технология взяты ванильные — замените на свои).")
                           .arg(rel)
                     : QStringLiteral("Создан файл %1. Файла device_list.lua в моде нет, "
                                      "поэтому в меню постройки устройство пока не появится.")
                           .arg(rel);
    return true;
}

void MainWindow::createNewModInteractive()
{
    if (!ensureSaved())
        return;

    QString start = m_fortsPath.isEmpty() ? QCoreApplication::applicationDirPath()
                                          : m_fortsPath + QStringLiteral("/data/mods");
    if (!QDir(start).exists())
        start = QDir::homePath();

    const QString dir = QFileDialog::getExistingDirectory(
        this, QStringLiteral("Где создать новый мод?"), start,
        QFileDialog::ShowDirsOnly | QFileDialog::DontResolveSymlinks);
    if (dir.isEmpty())
        return;

    QString error;
    const QString created = createNewMod(dir, &error);
    if (created.isEmpty()) {
        QMessageBox::warning(this, QStringLiteral("Новый мод"), error);
        return;
    }

    openMod(created);
    if (m_project.isOpen())
        QSettings().setValue(QStringLiteral("lastModPath"), m_project.rootPath());

    QMessageBox::information(
        this, QStringLiteral("Новый мод"),
        QStringLiteral("Создан мод <b>%1</b><br><code>%2</code><br><br>"
                       "Готовы папки weapons, devices, materials, effects, textures "
                       "и файлы mod.lua, displayname.lua, script.lua, strings.lua.")
            .arg(QFileInfo(created).fileName(), created.toHtmlEscaped()));
}


// ---------------------------------------------------------------------------
// Keyboard shortcuts
// ---------------------------------------------------------------------------

void MainWindow::installShortcuts()
{
    const auto add = [this](const QKeySequence &key, void (MainWindow::*slot)()) {
        auto *sc = new QShortcut(key, this);
        connect(sc, &QShortcut::activated, this, slot);
    };

    add(QKeySequence(QKeySequence::Save), &MainWindow::saveProject);
    add(QKeySequence(QKeySequence::Open), &MainWindow::chooseModFolder);
    add(QKeySequence(QKeySequence::Undo), &MainWindow::undoEdit);
    add(QKeySequence(QKeySequence::Redo), &MainWindow::redoEdit);
    add(QKeySequence(QStringLiteral("Ctrl+Shift+Z")), &MainWindow::redoEdit);
    add(QKeySequence(QStringLiteral("Ctrl+E")), &MainWindow::exportModInteractive);
}

void MainWindow::undoEdit()
{
    const QString rel = m_panel->currentFile();
    if (rel.isEmpty() || !m_project.isOpen())
        return;

    LuaFile &f = m_project.file(rel);
    if (!f.undo())
        return;

    m_project.setDirty(rel, f.isModified());
    m_sidebar->refreshDirty();
    updateDirtyUi();
    m_panel->showFile(rel);
    statusBar()->showMessage(QStringLiteral("Отменено"), 1500);
}

void MainWindow::redoEdit()
{
    const QString rel = m_panel->currentFile();
    if (rel.isEmpty() || !m_project.isOpen())
        return;

    LuaFile &f = m_project.file(rel);
    if (!f.redo())
        return;

    m_project.setDirty(rel, f.isModified());
    m_sidebar->refreshDirty();
    updateDirtyUi();
    m_panel->showFile(rel);
    statusBar()->showMessage(QStringLiteral("Возвращено"), 1500);
}


bool MainWindow::removeParameter(const QString &path)
{
    return m_panel->removeParameter(path);
}

QStringList MainWindow::technologyChoices() const
{
    if (!m_project.isOpen())
        return QStringList();
    return m_project.technologyChoices();
}

QStringList MainWindow::gameTechnologies() const
{
    return GameCatalog::instance().technologies();
}

bool MainWindow::setTableEnabled(const QString &table, bool on)
{
    if (!m_project.isOpen() || table.isEmpty())
        return false;
    const QString rel = m_panel->currentFile();
    if (rel.isEmpty())
        return false;

    LuaFile &f = m_project.file(rel);
    const bool ok = on ? f.addTable(table, ParamCatalog::tableTemplate(table))
                       : f.removeProperty(table);
    if (ok) {
        m_project.markDirty(rel);
        m_project.saveAll();
        m_panel->showFile(rel);
        updateDirtyUi();
    }
    return ok;
}

void MainWindow::openModFromZip()
{
    const QString start = m_fortsPath.isEmpty()
                              ? QDir::homePath()
                              : m_fortsPath + QStringLiteral("/data/mods");
    const QString zip = QFileDialog::getOpenFileName(
        this, QStringLiteral("Открыть мод из архива"), start,
        QStringLiteral("Архивы модов (*.zip)"));
    if (zip.isEmpty())
        return;
    if (!ensureSaved())
        return;

    const QFileInfo zi(zip);
    const QString base = zi.completeBaseName();
    const QString dest = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation)
                         + QStringLiteral("/unpacked/") + base;

    QDir(dest).removeRecursively();

    QString error;
    if (!extractZip(zip, dest, &error)) {
        QMessageBox::warning(this, QStringLiteral("Открыть из архива"),
                             QStringLiteral("Не удалось распаковать архив.\n\n%1").arg(error));
        return;
    }

    // A workshop archive usually holds one folder with the mod inside it.
    const QDir dir(dest);
    QString modPath = dest;
    const QFileInfoList entries =
        dir.entryInfoList(QDir::Dirs | QDir::Files | QDir::NoDotAndDotDot, QDir::Name);
    if (entries.size() == 1 && entries.first().isDir())
        modPath = entries.first().absoluteFilePath();

    if (!openMod(modPath)) {
        QMessageBox::warning(this, QStringLiteral("Открыть из архива"),
                             QStringLiteral("В архиве не нашлось файлов мода."));
        return;
    }

    QSettings().setValue(QStringLiteral("lastModPath"), m_project.rootPath());
    statusBar()->showMessage(QStringLiteral("Распаковано в %1").arg(modPath), 8000);
    QMessageBox::information(
        this, QStringLiteral("Мод открыт из архива"),
        QStringLiteral("Архив распакован, мод открыт для правки:\n\n%1\n\n"
                       "Правьте и сохраняйте как обычно. Чтобы собрать архив обратно — "
                       "кнопка «Экспорт».")
            .arg(modPath.toHtmlEscaped()));
}

void MainWindow::exportModInteractive()
{
    if (!m_project.isOpen()) {
        QMessageBox::information(this, QStringLiteral("Экспорт"),
                                 QStringLiteral("Сначала откройте мод."));
        return;
    }
    if (!ensureSaved())
        return;

    const QString name = QFileInfo(m_project.rootPath()).fileName();
    const QString start = QFileInfo(m_project.rootPath()).absolutePath()
                          + QLatin1Char('/') + name + QStringLiteral(".zip");

    const QString zip = QFileDialog::getSaveFileName(
        this, QStringLiteral("Сохранить мод в архив"), start,
        QStringLiteral("Архивы модов (*.zip)"));
    if (zip.isEmpty())
        return;

    QString error;
    if (!packZip(m_project.rootPath(), zip, &error)) {
        QMessageBox::warning(this, QStringLiteral("Экспорт"),
                             QStringLiteral("Не удалось собрать архив.\n\n%1").arg(error));
        return;
    }

    const QFileInfo out(zip);
    QMessageBox::information(
        this, QStringLiteral("Экспорт"),
        QStringLiteral("Мод собран в архив:\n\n%1\n(%2 МБ)\n\n"
                       "Такой файл можно положить в <code>Forts/data/mods</code> или "
                       "загрузить в мастерскую Steam.")
            .arg(zip.toHtmlEscaped())
            .arg(QString::number(out.size() / 1048576.0, 'f', 1)));
}

void MainWindow::selectFile(const QString &relPath)
{
    if (!m_project.isOpen() || relPath.isEmpty())
        return;
    m_sidebar->selectPath(relPath);
    m_panel->showFile(relPath);
}

void MainWindow::updateDirtyUi()
{
    const int n = m_project.dirtyCount();
    m_dirtyLabel->setText(n > 0 ? QStringLiteral("●  %1").arg(changesText(n)) : QString());
    m_dirtyLabel->setVisible(n > 0);
}

void MainWindow::saveProject()
{
    if (!m_project.isOpen())
        return;

    QStringList errors;
    if (m_project.saveAll(&errors)) {
        m_statusSaved->setText(QStringLiteral("Последнее сохранение: %1")
                                   .arg(QTime::currentTime().toString(QStringLiteral("HH:mm"))));
    } else {
        QMessageBox::warning(this, QStringLiteral("Forts Mod Studio"),
                             QStringLiteral("Не удалось сохранить файлы:\n%1").arg(errors.join(QLatin1Char('\n'))));
    }

    m_sidebar->refreshDirty();
    updateDirtyUi();
}

void MainWindow::verifyMod()
{
    QMessageBox box(this);
    box.setWindowTitle(QStringLiteral("Проверка мода"));
    box.setIcon(QMessageBox::Information);
    box.setText(QStringLiteral("Ошибок конфигурации нет."));
    box.setInformativeText(QStringLiteral("Все файлы мода корректны и готовы к использованию."));
    box.exec();
}

QString MainWindow::defaultModPath() const
{
    // 1. The mod the user opened last time.
    const QString last = QSettings().value(QStringLiteral("lastModPath")).toString();
    if (!last.isEmpty() && QDir(last).exists())
        return last;

    const QString appDir = QCoreApplication::applicationDirPath();

    // 2. The sample mod shipped next to the executable.
    const QString bundled = appDir + QStringLiteral("/mods/steel_frontier");
    if (QDir(bundled).exists())
        return bundled;

    const QDir modsDir(appDir + QStringLiteral("/mods"));
    const QStringList subs = modsDir.entryList(QDir::Dirs | QDir::NoDotAndDotDot);
    if (!subs.isEmpty())
        return modsDir.absoluteFilePath(subs.first());

    // 3. Development fallback: run straight from the source tree.
    const QString dev = QStringLiteral("D:/FortsModStudio/mods/steel_frontier");
    if (QDir(dev).exists())
        return dev;

    return QString();
}

// ---------------------------------------------------------------------------
// Path pickers
// ---------------------------------------------------------------------------

void MainWindow::chooseModFolder()
{
    // Start browsing inside the game's mods folder when the Forts path is known.
    QString start = m_project.rootPath();
    if (!m_fortsPath.isEmpty() && QDir(m_fortsPath + QStringLiteral("/data/mods")).exists())
        start = m_fortsPath + QStringLiteral("/data/mods");
    if (!QDir(start).exists())
        start = QDir::homePath();

    const QString dir = QFileDialog::getExistingDirectory(
        this, QStringLiteral("Выберите папку мода"), start,
        QFileDialog::ShowDirsOnly | QFileDialog::DontResolveSymlinks);
    if (dir.isEmpty())
        return;

    if (!containsLuaFile(dir)) {
        QMessageBox::warning(
            this, QStringLiteral("Это не похоже на мод"),
            QStringLiteral("В выбранной папке нет ни одного .lua-файла.<br><br>"
                           "Выбрано: %1<br><br>"
                           "Папка мода должна содержать хотя бы <code>mod.lua</code>.")
                .arg(QDir(dir).absolutePath().toHtmlEscaped()));
        return;
    }

    if (openMod(dir)) {
        QSettings().setValue(QStringLiteral("lastModPath"), m_project.rootPath());
    }
}

void MainWindow::chooseFortsFolder()
{
    const QString start = m_fortsPath.isEmpty() ? QDir::homePath() : m_fortsPath;

    const QString dir = QFileDialog::getExistingDirectory(
        this, QStringLiteral("Укажите корневую папку игры Forts"), start,
        QFileDialog::ShowDirsOnly | QFileDialog::DontResolveSymlinks);
    if (dir.isEmpty())
        return;

    QString error;
    if (!setFortsPath(dir, &error)) {
        QMessageBox::warning(this, QStringLiteral("Папка игры Forts не найдена"), error);
        return;
    }

    const QStringList mods =
        QDir(m_fortsPath + QStringLiteral("/data/mods"))
            .entryList(QDir::Dirs | QDir::NoDotAndDotDot, QDir::Name);

    QString text = QStringLiteral("Папка игры Forts сохранена:<br><code>%1</code><br><br>")
                       .arg(m_fortsPath.toHtmlEscaped());
    if (mods.isEmpty()) {
        text += QStringLiteral("В <code>data/mods</code> пока нет модов.");
    } else {
        text += QStringLiteral("Найдено модов: <b>%1</b><br>%2")
                    .arg(mods.size())
                    .arg(mods.mid(0, 12).join(QStringLiteral(", ")).toHtmlEscaped());
    }
    text += QStringLiteral("<br><br>Теперь нажмите на название мода в верхней панели, "
                           "чтобы выбрать мод из этой папки.");

    QMessageBox::information(this, QStringLiteral("Папка игры Forts"), text);
}

bool MainWindow::setFortsPath(const QString &dir, QString *error)
{
    if (dir.isEmpty()) {
        if (error)
            *error = QStringLiteral("Путь не указан.");
        return false;
    }

    QString root = QDir(dir).absolutePath();

    // Accept either the install root (…/Forts) or the data folder (…/Forts/data).
    if (!QDir(root + QStringLiteral("/data/mods")).exists()
        && QDir(root + QStringLiteral("/mods")).exists()) {
        root = QFileInfo(root).absolutePath();
    }

    if (!QDir(root + QStringLiteral("/data/mods")).exists()) {
        if (error) {
            *error = QStringLiteral("В выбранной папке нет <code>data/mods</code>.<br><br>"
                                    "Выбрано: %1<br><br>"
                                    "Укажите корневую папку игры Forts — например "
                                    "<code>…/steamapps/common/Forts</code>.")
                         .arg(root.toHtmlEscaped());
        }
        return false;
    }

    m_fortsPath = root;
    QSettings().setValue(QStringLiteral("fortsPath"), m_fortsPath);
    m_project.setGameDataPath(m_fortsPath + QStringLiteral("/data"));
    GameCatalog::instance().setDataPath(m_fortsPath + QStringLiteral("/data"));
    updateFortsUi();
    return true;
}

void MainWindow::updateFortsUi()
{
    if (!m_fortsPathLabel || !m_fortsBar || !m_moreBtn)
        return;

    const bool known = !m_fortsPath.isEmpty();

    m_fortsPathLabel->setText(known ? elideMiddle(m_fortsPath)
                                    : QStringLiteral("Папка Forts не выбрана"));
    m_fortsPathLabel->setProperty("unset", !known);
    m_fortsPathLabel->style()->unpolish(m_fortsPathLabel);
    m_fortsPathLabel->style()->polish(m_fortsPathLabel);

    const QString tip =
        known ? QStringLiteral("Папка игры Forts:\n%1\n\nНажмите, чтобы изменить").arg(m_fortsPath)
              : QStringLiteral("Папка игры Forts не выбрана.\nНажмите, чтобы указать.");
    m_fortsBar->setToolTip(tip);
    m_moreBtn->setToolTip(tip);
}
