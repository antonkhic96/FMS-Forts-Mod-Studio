#pragma once

#include <QHash>
#include <QPair>
#include <QString>
#include <QStringList>
#include <QVector>

// Type of a parsed value.
enum class LuaKind {
    Number,     // 12, -0.5
    Bool,       // true / false
    String,     // "text"
    List,       // { 1, 2 }  (inline array kept as text)
    Expression  // 5000/BeamDuration, nil, FindProjectile(...)
};

// A `texture = …` reference inside the Sprites table (barrel / head / base).
struct TextureRef {
    QString sprite;   // sprite name, e.g. "30mmpuska-barrel"
    QString value;    // raw expression, e.g. path .. "/weapons/30mmCannon/barrel.png"
    int line = -1;
};

// One editable value found in a Forts .lua file.
struct LuaProp {
    QString key;    // "ReloadTime"
    QString path;   // "Root.Offset" or "ReloadTime"
    QString table;  // owning table path, "" for the top level
    QString value;  // raw text (quotes stripped for strings)
    LuaKind kind = LuaKind::Expression;
    bool quoted = false;
    int line = -1;  // 0-based line index in the file
};

// Reader/writer for Forts .lua data files.
//
// Handles the shapes the game actually uses:
//   Key = value
//   Key = { a, b }              (inline array)
//   Key =                       (opening brace on the following line)
//   {
//       Nested = 1,
//   }
//   -- comments, CRLF, UTF-8 and UTF-16 input.
//
// Editing rewrites only the affected line, so comments, indentation and the
// rest of the file stay untouched.
class LuaFile
{
public:
    bool load(const QString &path);
    bool save();

    QString path() const { return m_path; }
    QString fileName() const;

    const QVector<LuaProp> &properties() const { return m_props; }
    const QVector<TextureRef> &textures() const { return m_textures; }

    // "base" | "head" | "barrel" | "" - guessed from the sprite name and path.
    static QString textureRole(const TextureRef &t);

    // Replaces the texture expression on that line.
    bool setTexture(int line, const QString &value);

    // Undo / redo of in-memory edits (Ctrl+Z / Ctrl+Y).
    bool canUndo() const { return !m_undo.isEmpty(); }
    bool canRedo() const { return !m_redo.isEmpty(); }
    bool undo();
    bool redo();

    bool isModified() const { return m_modified; }
    void setModified(bool m) { m_modified = m; }
    bool isEmpty() const { return m_lines.isEmpty(); }
    int byteSize() const;

    // True when the file is Lua script (callbacks/loops) rather than data.
    bool looksLikeScript() const { return m_isScript; }

    // Value of a property by dotted path, or an empty string.
    QString value(const QString &path) const;

    // Rewrites the matching line in the source and flags the file as modified.
    bool setValue(const QString &path, const QString &value);

    // Deletes the parameter (and its table, when it has one) from the source.
    // This is how a setting is "turned off": writing 0/false is not the same.
    bool removeProperty(const QString &path);

    // Line index where the named table's closing brace sits, or -1.
    int tableCloseLine(const QString &table) const;

    // Appends a new entry to an array of tables (e.g. a new projectile in
    // `Projectiles`). Returns the new entry's path ("Projectiles[11]") or an
    // empty string on failure.
    QString addComponent(const QString &arrayName,
                         const QVector<QPair<QString, QString>> &props);

    // Adds a brand-new `Key = value` line (used when the user enables a setting
    // the file did not define yet). With `table` empty the line goes to the end
    // of the file (top level); otherwise it is inserted inside that table.
    bool addProperty(const QString &key, const QString &value, const QString &table = QString());

    // Adds a brand-new nested table at the top level:
    //   Key =
    //   {
    //       A = 1,
    //   }
    // Used for optional blocks such as ReloadBank. Returns false when the table
    // already exists.
    bool addTable(const QString &key, const QVector<QPair<QString, QString>> &props);

    // True when a table with this name exists in the file.
    bool hasTable(const QString &key) const;

    // Re-reads the on-disk text, discarding in-memory edits.
    void reload() { parse(); m_modified = false; }

    // Full source text (used by the "code editor" tab).
    QString rawText() const;
    void setRawText(const QString &text);

private:
    void parse();

    QString m_path;
    QString m_newline = QStringLiteral("\n");
    QStringList m_lines;
    // One step of history: the whole file text plus its modified flag.
    struct Snapshot {
        QStringList lines;
        bool modified = false;
    };
    void snapshot();   // call before mutating

    QVector<LuaProp> m_props;
    QVector<Snapshot> m_undo;
    QVector<Snapshot> m_redo;
    QVector<TextureRef> m_textures;
    QHash<QString, int> m_tableClose;
    int m_encoding = 0;   // 0 = UTF-8, 1 = UTF-16LE, 2 = UTF-16BE
    bool m_bom = false;
    bool m_isScript = false;
    bool m_modified = false;
};
