#pragma once

#include <QPair>
#include <QString>
#include <QStringList>
#include <QVector>

// Mod-independent catalogue of Forts parameter names.
//
// The translation and grouping must NOT depend on which mod is open: the same
// key (e.g. `ReloadTime`) always maps to the same Russian label and the same
// section, no matter where it appears. Unknown keys fall back to a word-by-word
// translation of the CamelCase name, so brand-new mods still read in Russian.
namespace ParamCatalog {

// A parameter a Forts component can have, with a sensible default value.
struct TemplateParam {
    QString key;
    QString value;
    // false: the key is known and offered when missing, but is NOT written into
    // a freshly created file (used for settings that would break the default
    // behaviour, e.g. ForceFireAngle locks the aiming).
    bool writeByDefault = true;
};

// Allowed range of a numeric parameter (used to validate input).
struct Range {
    double min = 0;
    double max = 0;
    bool integer = false;
    bool defined = false;
};

// What kind of file is being edited. Grouping and templates depend on it: an
// entry of weapon_list.lua is a build-menu record (price, icon, tech), not a
// weapon with damage and reload time.
enum class Kind {
    Generic,
    Weapon,        // weapons/<name>.lua      - the weapon itself
    WeaponList,    // weapons/weapon_list.lua - its entry in the build menu
    Projectile,    // weapons/projectile_list.lua
    Device,        // devices/<name>.lua
    DeviceList,    // devices/device_list.lua
    Material,
};

Kind kindFor(const QString &relPath, const QString &componentArray);

// The array a *_list.lua file is meant to fill ("Projectiles" for
// projectile_list.lua, …). Empty for ordinary files. Used to offer "Добавить"
// even when the file has no entries yet.
QString expectedArrayFor(const QString &relPath);

// Russian label for a parameter key ("ReloadTime" -> "Время перезарядки").
QString label(const QString &key);

// Unit shown inside the input, e.g. "с" for times, "ед." for distances.
QString unit(const QString &key);

// Short explanation shown under a toggle, or an empty string.
QString hint(const QString &key);

// Section id the parameter belongs to ("firing", "damage", …).
QString categoryOf(const QString &key);
// Same, but aware of the file kind (a key can mean different things in a
// weapon file and in weapon_list.lua).
QString categoryFor(Kind kind, const QString &key);

// Allowed range for a numeric parameter, if known.
Range rangeFor(const QString &key);
// Russian title of a section id ("firing" -> "Стрельба").
QString categoryTitle(const QString &id);
// Sort weight so sections appear in a sensible order.
int categoryOrder(const QString &id);

// Section title for a nested table ("Overheat" -> "Перегрев").
QString tableTitle(const QString &tableName);

// Tables that are optional as a whole (ReloadBank): the editor shows a switch
// in the group header to add or delete the entire block.
bool isToggleableTable(const QString &tableName);

// Label / hint for a value inside a named table ("ReloadBank", "Max"). Falls
// back to the ordinary label()/hint() for unknown combinations.
QString tableChildLabel(const QString &table, const QString &key);
QString tableChildHint(const QString &table, const QString &key);

// Default contents of an optional table, used when the block is switched on.
const QVector<QPair<QString, QString>> &tableTemplate(const QString &table);

// ALL_CAPS names are tuning constants declared at the top of a file
// (`local FRAG_COUNT = 24`), not per-entry settings.
bool isConstantName(const QString &key);

// Technical parameters that are not user-facing characteristics.
bool isTechnicalKey(const QString &key);
// Tables holding rendering / structural data rather than characteristics.
bool isTechnicalTable(const QString &tableName);

// Every parameter a Forts component of this kind can have (derived from the
// game's own weapons/devices/materials), so the editor can offer the settings a
// file does not define yet. `folder` is the top-level folder of the mod file
// ("weapons", "devices", "materials"); anything else returns an empty list.
const QVector<TemplateParam> &templateFor(const QString &folder);

// Same, but aware of the file: `componentArray` is the array being edited
// ("Projectiles" inside projectile_list.lua), which picks a matching template.
const QVector<TemplateParam> &templateForFile(const QString &relPath,
                                              const QString &componentArray = QString());

} // namespace ParamCatalog
