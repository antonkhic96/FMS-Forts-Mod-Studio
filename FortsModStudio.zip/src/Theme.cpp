#include "Theme.h"

#include <QApplication>
#include <QFile>
#include <QPalette>
#include <QStyleFactory>

namespace Theme {

void apply(QApplication &app)
{
    // Use Fusion as the base style so our stylesheet behaves consistently
    // across platforms.
    app.setStyle(QStyleFactory::create("Fusion"));

    // Base palette for native widgets the stylesheet does not reach
    // (menus, tooltips, text selection, etc.).
    QPalette p;
    p.setColor(QPalette::Window, BgApp);
    p.setColor(QPalette::WindowText, Text);
    p.setColor(QPalette::Base, BgField);
    p.setColor(QPalette::AlternateBase, BgSoft);
    p.setColor(QPalette::Text, Text);
    p.setColor(QPalette::Button, BgField);
    p.setColor(QPalette::ButtonText, Text);
    p.setColor(QPalette::Highlight, Select);
    p.setColor(QPalette::HighlightedText, QColor(0xff, 0xff, 0xff));
    p.setColor(QPalette::ToolTipBase, BgSoft);
    p.setColor(QPalette::ToolTipText, Text);
    p.setColor(QPalette::PlaceholderText, TextMute);
    p.setColor(QPalette::Disabled, QPalette::Text, TextMute);
    p.setColor(QPalette::Disabled, QPalette::WindowText, TextMute);
    app.setPalette(p);

    QFile f(QStringLiteral(":/theme.qss"));
    if (f.open(QIODevice::ReadOnly | QIODevice::Text)) {
        app.setStyleSheet(QString::fromUtf8(f.readAll()));
    }
}

} // namespace Theme
