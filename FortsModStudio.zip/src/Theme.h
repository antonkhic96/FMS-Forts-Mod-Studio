#pragma once

#include <QColor>

class QApplication;

// Central place for the palette so painted icons and widgets stay in sync
// with resources/theme.qss. Values are sampled from the reference design.
namespace Theme {

inline const QColor BgApp      {0x19, 0x1d, 0x20};  // top bar, sidebar, status bar
inline const QColor BgContent  {0x14, 0x17, 0x19};  // content column, secondary bar
inline const QColor BgField    {0x11, 0x15, 0x17};  // input fields
inline const QColor BgSoft     {0x20, 0x25, 0x29};  // info box, chips, active tab
inline const QColor Border     {0x2b, 0x32, 0x37};
inline const QColor BorderSoft {0x1e, 0x22, 0x25};
inline const QColor Text       {0xe2, 0xe6, 0xe8};
inline const QColor TextDim    {0xa8, 0xb0, 0xb5};
inline const QColor TextMute   {0x8f, 0x98, 0x9d};
inline const QColor Accent     {0xa0, 0xbe, 0xae};  // sage green
inline const QColor AccentBg   {0x2e, 0x43, 0x3a};  // icon box / badge fill
inline const QColor AccentDark {0x27, 0x3b, 0x33};
inline const QColor Select     {0x49, 0x65, 0x57};  // selected tree row
inline const QColor Warn       {0xd7, 0xa9, 0x4a};
inline const QColor Danger     {0xe5, 0x53, 0x4b};

// Loads :/theme.qss and installs it on the application.
void apply(QApplication &app);

} // namespace Theme
