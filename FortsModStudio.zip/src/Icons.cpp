#include "Icons.h"
#include "Theme.h"

#include <QApplication>
#include <QPainter>
#include <QPainterPath>
#include <QPixmap>
#include <QPolygonF>
#include <cmath>
#include <functional>

namespace {

constexpr qreal kGrid = 24.0;
constexpr qreal kPi = 3.14159265358979323846;

const QColor kMuted{0x99, 0xa0, 0xb0};
const QColor kBright{0xd7, 0xdb, 0xe3};

QIcon render(int px, const std::function<void(QPainter &)> &draw)
{
    const qreal dpr = qApp ? qApp->devicePixelRatio() : 1.0;
    QPixmap pm(QSize(qRound(px * dpr), qRound(px * dpr)));
    pm.setDevicePixelRatio(dpr);
    pm.fill(Qt::transparent);

    QPainter p(&pm);
    p.setRenderHint(QPainter::Antialiasing, true);
    p.scale(px / kGrid, px / kGrid);
    draw(p);
    p.end();
    return QIcon(pm);
}

void stroke(QPainter &p, const QColor &c, qreal w = 1.7)
{
    QPen pen(c);
    pen.setWidthF(w);
    pen.setCapStyle(Qt::RoundCap);
    pen.setJoinStyle(Qt::RoundJoin);
    p.setPen(pen);
    p.setBrush(Qt::NoBrush);
}

void solid(QPainter &p, const QColor &c)
{
    p.setPen(Qt::NoPen);
    p.setBrush(c);
}

// A document silhouette with a folded top-right corner.
QPainterPath docPath()
{
    QPainterPath path;
    path.moveTo(6.2, 3.8);
    path.lineTo(13.4, 3.8);
    path.lineTo(18.0, 8.4);
    path.lineTo(18.0, 20.2);
    path.lineTo(6.2, 20.2);
    path.closeSubpath();
    return path;
}

} // namespace

namespace Icons {

QIcon appLogo(int px)
{
    return render(px, [](QPainter &p) {
        solid(p, Theme::Text);
        const qreal s = 7.4, r = 1.9;
        p.drawRoundedRect(QRectF(4.2, 4.2, s, s), r, r);
        p.drawRoundedRect(QRectF(12.6, 4.2, s, s), r, r);
        p.drawRoundedRect(QRectF(4.2, 12.6, s, s), r, r);
        p.drawRoundedRect(QRectF(12.6, 12.6, s, s), r, r);
    });
}

QIcon folder(int px)
{
    return render(px, [](QPainter &p) {
        stroke(p, kMuted, 1.6);
        QPainterPath path;
        path.moveTo(3.6, 19.0);
        path.lineTo(3.6, 6.0);
        path.lineTo(9.4, 6.0);
        path.lineTo(11.4, 8.7);
        path.lineTo(20.4, 8.7);
        path.lineTo(20.4, 19.0);
        path.closeSubpath();
        p.drawPath(path);
    });
}

QIcon folderOpen(int px)
{
    return render(px, [](QPainter &p) {
        stroke(p, kMuted, 1.6);
        QPainterPath path;
        path.moveTo(3.6, 19.0);
        path.lineTo(3.6, 6.0);
        path.lineTo(9.4, 6.0);
        path.lineTo(11.4, 8.7);
        path.lineTo(20.4, 8.7);
        path.lineTo(20.4, 19.0);
        path.closeSubpath();
        p.drawPath(path);
        p.drawLine(QPointF(3.6, 11.8), QPointF(20.4, 11.8));
    });
}

QIcon fileGeneric(int px)
{
    return render(px, [](QPainter &p) {
        stroke(p, kMuted, 1.6);
        p.drawPath(docPath());
        p.drawLine(QPointF(13.4, 3.8), QPointF(13.4, 8.4));
        p.drawLine(QPointF(13.4, 8.4), QPointF(18.0, 8.4));
    });
}

QIcon fileLua(int px)
{
    return render(px, [](QPainter &p) {
        stroke(p, kMuted, 1.6);
        p.drawPath(docPath());
        p.drawLine(QPointF(13.4, 3.8), QPointF(13.4, 8.4));
        p.drawLine(QPointF(13.4, 8.4), QPointF(18.0, 8.4));
        stroke(p, kMuted, 1.4);
        p.drawLine(QPointF(8.6, 13.6), QPointF(15.6, 13.6));
        p.drawLine(QPointF(8.6, 16.6), QPointF(13.4, 16.6));
    });
}

QIcon fileImage(int px)
{
    return render(px, [](QPainter &p) {
        stroke(p, kMuted, 1.6);
        p.drawPath(docPath());
        p.drawLine(QPointF(13.4, 3.8), QPointF(13.4, 8.4));
        p.drawLine(QPointF(13.4, 8.4), QPointF(18.0, 8.4));
        // little photo glyph inside the page
        solid(p, kMuted);
        p.drawEllipse(QPointF(9.6, 13.4), 1.15, 1.15);
        QPainterPath hill;
        hill.moveTo(8.0, 18.4);
        hill.lineTo(11.2, 15.0);
        hill.lineTo(13.4, 17.2);
        hill.lineTo(15.2, 15.6);
        hill.lineTo(16.6, 18.4);
        hill.closeSubpath();
        p.drawPath(hill);
    });
}

QIcon chevronDown(int px)
{
    return render(px, [](QPainter &p) {
        stroke(p, kMuted, 1.9);
        p.drawPolyline(QPolygonF({ {8.5, 10.0}, {12.0, 13.6}, {15.5, 10.0} }));
    });
}

QIcon chevronRight(int px)
{
    return render(px, [](QPainter &p) {
        stroke(p, kMuted, 1.9);
        p.drawPolyline(QPolygonF({ {10.0, 8.5}, {13.6, 12.0}, {10.0, 15.5} }));
    });
}

QIcon refresh(int px)
{
    return render(px, [](QPainter &p) {
        stroke(p, kMuted, 1.7);
        p.drawArc(QRectF(5.2, 5.2, 13.6, 13.6), 75 * 16, 295 * 16);
        solid(p, kMuted);
        p.drawPolygon(QPolygonF({ {15.9, 3.9}, {11.4, 6.3}, {16.6, 8.6} }));
    });
}

QIcon collapseAll(int px)
{
    return render(px, [](QPainter &p) {
        stroke(p, kMuted, 1.7);
        p.drawPolyline(QPolygonF({ {7.5, 7.0}, {12.0, 11.0}, {16.5, 7.0} }));
        p.drawPolyline(QPolygonF({ {7.5, 17.0}, {12.0, 13.0}, {16.5, 17.0} }));
    });
}

QIcon search(int px)
{
    return render(px, [](QPainter &p) {
        stroke(p, Theme::TextMute, 1.7);
        p.drawEllipse(QPointF(10.4, 10.4), 5.6, 5.6);
        p.drawLine(QPointF(14.7, 14.7), QPointF(19.4, 19.4));
    });
}

QIcon plus(int px, const QColor &c)
{
    return render(px, [c](QPainter &p) {
        stroke(p, c, 1.9);
        p.drawLine(QPointF(12.0, 5.2), QPointF(12.0, 18.8));
        p.drawLine(QPointF(5.2, 12.0), QPointF(18.8, 12.0));
    });
}

QIcon exportIcon(int px, const QColor &c)
{
    return render(px, [c](QPainter &p) {
        stroke(p, c, 1.7);
        p.drawLine(QPointF(12.0, 14.0), QPointF(12.0, 5.0));
        p.drawPolyline(QPolygonF({ {8.6, 8.4}, {12.0, 5.0}, {15.4, 8.4} }));
        p.drawPolyline(QPolygonF({ {5.2, 15.0}, {5.2, 19.2}, {18.8, 19.2}, {18.8, 15.0} }));
    });
}

QIcon save(int px, const QColor &c)
{
    return render(px, [c](QPainter &p) {
        stroke(p, c, 1.7);
        p.drawLine(QPointF(12.0, 4.6), QPointF(12.0, 13.4));
        p.drawPolyline(QPolygonF({ {8.6, 10.0}, {12.0, 13.4}, {15.4, 10.0} }));
        p.drawPolyline(QPolygonF({ {5.2, 16.4}, {5.2, 19.4}, {18.8, 19.4}, {18.8, 16.4} }));
    });
}

QIcon dots(int px)
{
    return render(px, [](QPainter &p) {
        solid(p, kMuted);
        p.drawEllipse(QPointF(6.2, 12.0), 1.5, 1.5);
        p.drawEllipse(QPointF(12.0, 12.0), 1.5, 1.5);
        p.drawEllipse(QPointF(17.8, 12.0), 1.5, 1.5);
    });
}

QIcon gear(int px, const QColor &c)
{
    return render(px, [c](QPainter &p) {
        stroke(p, c, 1.6);
        p.drawEllipse(QPointF(12.0, 12.0), 4.2, 4.2);
        stroke(p, c, 1.7);
        for (int i = 0; i < 8; ++i) {
            const qreal a = i * kPi / 4.0;
            p.drawLine(QPointF(12 + std::cos(a) * 6.3, 12 + std::sin(a) * 6.3),
                       QPointF(12 + std::cos(a) * 8.9, 12 + std::sin(a) * 8.9));
        }
    });
}

QIcon target(int px, const QColor &c)
{
    return render(px, [c](QPainter &p) {
        stroke(p, c, 1.6);
        p.drawEllipse(QPointF(12.0, 12.0), 8.0, 8.0);
        p.drawEllipse(QPointF(12.0, 12.0), 3.7, 3.7);
        solid(p, c);
        p.drawEllipse(QPointF(12.0, 12.0), 1.35, 1.35);
    });
}

QIcon thermometer(int px, const QColor &c)
{
    return render(px, [c](QPainter &p) {
        stroke(p, c, 1.6);
        p.drawEllipse(QPointF(12.0, 17.5), 3.2, 3.2);
        QPainterPath stem;
        stem.moveTo(10.3, 16.0);
        stem.lineTo(10.3, 6.4);
        stem.quadTo(10.3, 4.5, 12.0, 4.5);
        stem.quadTo(13.7, 4.5, 13.7, 6.4);
        stem.lineTo(13.7, 16.0);
        p.drawPath(stem);
        stroke(p, c, 1.3);
        p.drawLine(QPointF(12.0, 8.6), QPointF(12.0, 15.4));
    });
}

QIcon check(int px, const QColor &c)
{
    return render(px, [c](QPainter &p) {
        stroke(p, c, 1.7);
        p.drawEllipse(QPointF(12.0, 12.0), 8.4, 8.4);
        stroke(p, c, 2.0);
        p.drawPolyline(QPolygonF({ {7.9, 12.3}, {10.9, 15.2}, {16.3, 9.0} }));
    });
}

QIcon info(int px)
{
    return render(px, [](QPainter &p) {
        stroke(p, kMuted, 1.6);
        p.drawEllipse(QPointF(12.0, 12.0), 8.2, 8.2);
        solid(p, kMuted);
        p.drawEllipse(QPointF(12.0, 8.2), 1.15, 1.15);
        stroke(p, kMuted, 1.7);
        p.drawLine(QPointF(12.0, 11.0), QPointF(12.0, 16.2));
    });
}

QIcon help(int px, const QColor &c)
{
    return render(px, [c](QPainter &p) {
        stroke(p, c, 1.5);
        p.drawEllipse(QPointF(12.0, 12.0), 8.6, 8.6);

        QFont f = p.font();
        f.setPixelSize(12);
        f.setBold(true);
        p.setFont(f);
        p.setPen(c);
        p.drawText(QRectF(0, 0, 24, 23), Qt::AlignCenter, QStringLiteral("?"));
    });
}

QIcon remove(int px, const QColor &c)
{
    return render(px, [c](QPainter &p) {
        stroke(p, c, 2.0);
        p.drawLine(QPointF(7, 7), QPointF(17, 17));
        p.drawLine(QPointF(17, 7), QPointF(7, 17));
    });
}

QIcon shieldCheck(int px)
{
    return render(px, [](QPainter &p) {
        stroke(p, Theme::Accent, 1.7);
        QPainterPath path;
        path.moveTo(12.0, 3.6);
        path.lineTo(19.2, 6.5);
        path.lineTo(19.2, 11.4);
        path.quadTo(19.2, 16.6, 12.0, 20.4);
        path.quadTo(4.8, 16.6, 4.8, 11.4);
        path.lineTo(4.8, 6.5);
        path.closeSubpath();
        p.drawPath(path);
        stroke(p, Theme::Accent, 1.9);
        p.drawPolyline(QPolygonF({ {8.8, 11.9}, {11.3, 14.3}, {15.7, 9.4} }));
    });
}

QIcon modBox(int px)
{
    return render(px, [](QPainter &p) {
        stroke(p, kMuted, 1.6);
        QPainterPath path;
        path.moveTo(12.0, 3.4);
        path.lineTo(20.2, 7.6);
        path.lineTo(20.2, 16.4);
        path.lineTo(12.0, 20.6);
        path.lineTo(3.8, 16.4);
        path.lineTo(3.8, 7.6);
        path.closeSubpath();
        p.drawPath(path);
        p.drawLine(QPointF(3.8, 7.6), QPointF(12.0, 11.8));
        p.drawLine(QPointF(20.2, 7.6), QPointF(12.0, 11.8));
        p.drawLine(QPointF(12.0, 11.8), QPointF(12.0, 20.6));
    });
}

QIcon dot(int px, const QColor &c)
{
    return render(px, [c](QPainter &p) {
        solid(p, c);
        p.drawEllipse(QPointF(12.0, 12.0), 4.0, 4.0);
    });
}

} // namespace Icons
