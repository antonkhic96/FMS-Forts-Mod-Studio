#include "ModModel.h"

#include <QDir>
#include <QDirIterator>
#include <QFile>
#include <QFileInfo>
#include <QRegularExpression>

#include <algorithm>

namespace {

QString capitalize(const QString &s)
{
    if (s.isEmpty())
        return s;
    QString r = s;
    r[0] = r.at(0).toUpper();
    return r;
}

QString readAll(const QString &path)
{
    QFile f(path);
    if (!f.open(QIODevice::ReadOnly | QIODevice::Text))
        return QString();
    return QString::fromUtf8(f.readAll());
}

} // namespace

bool ModProject::open(const QString &root)
{
    QFileInfo info(root);
    if (!info.exists() || !info.isDir())
        return false;

    m_root = QDir(root).absolutePath();
    m_cache.clear();
    m_dirty.clear();
    m_textureChoices.clear();   // the list belongs to the previous mod

    m_tree = ModEntry{};
    m_tree.name = info.fileName();
    m_tree.relPath = QString();
    m_tree.isDir = true;
    scanDir(m_root, QString(), m_tree);

    readModMeta();
    return true;
}

void ModProject::scanDir(const QString &absDir, const QString &relDir, ModEntry &out)
{
    out.children.clear();

    QDir dir(absDir);
    const QFileInfoList entries =
        dir.entryInfoList(QDir::Dirs | QDir::Files | QDir::NoDotAndDotDot | QDir::NoSymLinks);

    QVector<ModEntry> dirs;
    QVector<ModEntry> files;

    for (const QFileInfo &fi : entries) {
        if (fi.fileName().startsWith(QLatin1Char('.')))
            continue;

        ModEntry e;
        e.name = fi.fileName();
        e.relPath = relDir.isEmpty() ? fi.fileName() : relDir + QLatin1Char('/') + fi.fileName();
        e.isDir = fi.isDir();

        if (e.isDir) {
            scanDir(fi.absoluteFilePath(), e.relPath, e);
            e.count = e.children.size();
            dirs.push_back(e);
        } else {
            files.push_back(e);
        }
    }

    const auto byName = [](const ModEntry &a, const ModEntry &b) {
        return a.name.compare(b.name, Qt::CaseInsensitive) < 0;
    };
    std::sort(dirs.begin(), dirs.end(), byName);
    std::sort(files.begin(), files.end(), byName);

    // Directories follow a curated order (weapons first) instead of pure
    // alphabetical, matching how a mod is normally explored.
    static const QStringList kFolderOrder = {
        QStringLiteral("weapons"),  QStringLiteral("devices"), QStringLiteral("materials"),
        QStringLiteral("effects"),  QStringLiteral("textures"), QStringLiteral("sounds"),
        QStringLiteral("scripts"),
    };
    const auto rankOf = [](const QString &name) {
        const int idx = kFolderOrder.indexOf(name);
        return idx < 0 ? kFolderOrder.size() : idx;
    };
    std::sort(dirs.begin(), dirs.end(), [&](const ModEntry &a, const ModEntry &b) {
        const int ra = rankOf(a.name);
        const int rb = rankOf(b.name);
        if (ra != rb)
            return ra < rb;
        return byName(a, b);
    });

    // mod.lua first, then folders, then the remaining files - matching the
    // layout used by the design.
    for (const ModEntry &e : files)
        if (e.name == QLatin1String("mod.lua"))
            out.children.push_back(e);
    for (const ModEntry &e : dirs)
        out.children.push_back(e);
    for (const ModEntry &e : files)
        if (e.name != QLatin1String("mod.lua"))
            out.children.push_back(e);

    out.count = out.children.size();
}

void ModProject::readModMeta()
{
    m_name = QFileInfo(m_root).fileName();
    m_version.clear();

    const QString dn = readAll(m_root + QStringLiteral("/displayname.lua"));
    if (!dn.isEmpty()) {
        static const QRegularExpression re(
            QStringLiteral(R"re(\[\s*"Russian"\s*\]\s*=\s*L?"([^"]*)")re"));
        const QRegularExpressionMatch m = re.match(dn);
        if (m.hasMatch() && !m.captured(1).isEmpty())
            m_name = m.captured(1);
    }

    const QString ml = readAll(m_root + QStringLiteral("/mod.lua"));
    if (!ml.isEmpty()) {
        static const QRegularExpression nameRe(QStringLiteral(R"re(\bName\s*=\s*L?"([^"]*)")re"));
        static const QRegularExpression verRe(QStringLiteral(R"re(\bVersion\s*=\s*L?"([^"]*)")re"));
        const QRegularExpressionMatch nm = nameRe.match(ml);
        if (nm.hasMatch() && m_name == QFileInfo(m_root).fileName() && !nm.captured(1).isEmpty())
            m_name = nm.captured(1);
        const QRegularExpressionMatch vm = verRe.match(ml);
        if (vm.hasMatch())
            m_version = vm.captured(1);
    }
}

LuaFile &ModProject::file(const QString &relPath)
{
    auto it = m_cache.find(relPath);
    if (it == m_cache.end()) {
        LuaFile lf;
        lf.load(m_root + QLatin1Char('/') + relPath);
        it = m_cache.insert(relPath, lf);
    }
    return it.value();
}

bool ModProject::saveAll(QStringList *errors)
{
    bool ok = true;
    for (auto it = m_cache.begin(); it != m_cache.end(); ++it) {
        if (!it.value().isModified())
            continue;
        if (!it.value().save()) {
            ok = false;
            if (errors)
                errors->append(it.key());
        }
    }
    if (ok)
        m_dirty.clear();
    return ok;
}

// ---------------------------------------------------------------------------
// Presentation helpers
// ---------------------------------------------------------------------------

QString ModProject::categoryForFolder(const QString &folder)
{
    static const QMap<QString, QString> kMap = {
        {QStringLiteral("weapons"), QStringLiteral("Оружие")},
        {QStringLiteral("devices"), QStringLiteral("Устройства")},
        {QStringLiteral("materials"), QStringLiteral("Материалы")},
        {QStringLiteral("effects"), QStringLiteral("Эффекты")},
        {QStringLiteral("textures"), QStringLiteral("Текстуры")},
        {QStringLiteral("sounds"), QStringLiteral("Звуки")},
        {QStringLiteral("scripts"), QStringLiteral("Скрипты")},
        {QStringLiteral("strings"), QStringLiteral("Строки")},
    };
    return kMap.value(folder, capitalize(folder));
}

QString ModProject::displayNameForFile(const QString &relPath)
{
    const QString stem = QFileInfo(relPath).completeBaseName();
    static const QMap<QString, QString> kNames = {
        {QStringLiteral("cannon"), QStringLiteral("Пушка")},
        {QStringLiteral("machinegun"), QStringLiteral("Пулемёт")},
        {QStringLiteral("sniper"), QStringLiteral("Снайпер")},
        {QStringLiteral("mortar"), QStringLiteral("Миномёт")},
        {QStringLiteral("missile"), QStringLiteral("Ракета")},
        {QStringLiteral("laser"), QStringLiteral("Лазер")},
        {QStringLiteral("flak"), QStringLiteral("Зенитка")},
        {QStringLiteral("shotgun"), QStringLiteral("Дробовик")},
        {QStringLiteral("minigun"), QStringLiteral("Миниган")},
        {QStringLiteral("howitzer"), QStringLiteral("Гаубица")},
        {QStringLiteral("weapon"), QStringLiteral("Оружие")},
        {QStringLiteral("weapon_list"), QStringLiteral("Список оружия")},
        {QStringLiteral("projectile_list"), QStringLiteral("Список снарядов")},
        {QStringLiteral("mod"), QStringLiteral("Мод")},
        {QStringLiteral("displayname"), QStringLiteral("Название мода")},
        {QStringLiteral("strings"), QStringLiteral("Строки")},
        {QStringLiteral("script"), QStringLiteral("Скрипт")},
        {QStringLiteral("building_materials"), QStringLiteral("Материалы построек")},
    };
    return kNames.value(stem, capitalize(stem));
}

QString ModProject::typeLabelFor(const QString &relPath)
{
    const QString ext = QFileInfo(relPath).suffix().toLower();
    static const QMap<QString, QString> kMap = {
        {QStringLiteral("lua"), QStringLiteral("Lua")},
        {QStringLiteral("png"), QStringLiteral("PNG")},
        {QStringLiteral("jpg"), QStringLiteral("JPEG")},
        {QStringLiteral("jpeg"), QStringLiteral("JPEG")},
        {QStringLiteral("ogg"), QStringLiteral("OGG")},
        {QStringLiteral("mp3"), QStringLiteral("MP3")},
        {QStringLiteral("wav"), QStringLiteral("WAV")},
        {QStringLiteral("txt"), QStringLiteral("TXT")},
        {QStringLiteral("json"), QStringLiteral("JSON")},
    };
    return kMap.value(ext, ext.isEmpty() ? QStringLiteral("Файл") : ext.toUpper());
}

QString ModProject::humanSize(qint64 bytes)
{
    if (bytes < 1024)
        return QStringLiteral("%1 Б").arg(bytes);
    const double kb = bytes / 1024.0;
    if (kb < 1024.0)
        return QStringLiteral("%1 КБ").arg(QString::number(kb, 'f', 1));
    return QStringLiteral("%1 МБ").arg(QString::number(kb / 1024.0, 'f', 1));
}

QStringList ModProject::textureChoices() const
{
    if (m_textureChoices.isEmpty()) {
        QDirIterator it(m_root + QStringLiteral("/weapons"),
                        QStringList{QStringLiteral("*.png"), QStringLiteral("*.dds"),
                                    QStringLiteral("*.tga"), QStringLiteral("*.jpg")},
                        QDir::Files, QDirIterator::Subdirectories);
        while (it.hasNext()) {
            const QString rel = QDir(m_root).relativeFilePath(it.next());
            m_textureChoices << QStringLiteral("path .. \"/%1\"").arg(rel);
        }
        m_textureChoices.sort(Qt::CaseInsensitive);
    }
    return m_textureChoices;
}

QStringList ModProject::weaponFiles() const
{
    QStringList out;
    QDirIterator it(m_root + QStringLiteral("/weapons"),
                    QStringList{QStringLiteral("*.lua")}, QDir::Files);
    while (it.hasNext()) {
        const QString rel = QDir(m_root).relativeFilePath(it.next());
        const QString name = QFileInfo(rel).fileName().toLower();
        if (name == QLatin1String("weapon_list.lua")
            || name == QLatin1String("projectile_list.lua"))
            continue;
        out << rel;
    }
    out.sort(Qt::CaseInsensitive);
    return out;
}

QStringList ModProject::deviceFiles() const
{
    QStringList out;
    QDirIterator it(m_root + QStringLiteral("/devices"),
                    QStringList{QStringLiteral("*.lua")}, QDir::Files);
    while (it.hasNext()) {
        const QString rel = QDir(m_root).relativeFilePath(it.next());
        const QString name = QFileInfo(rel).fileName().toLower();
        if (name == QLatin1String("device_list.lua") || name == QLatin1String("ammo_list.lua")
            || name == QLatin1String("device_util.lua") || name == QLatin1String("strings.lua"))
            continue;
        out << rel;
    }
    out.sort(Qt::CaseInsensitive);
    return out;
}

QStringList ModProject::effectChoices() const
{
    QStringList out;
    QDirIterator it(m_root + QStringLiteral("/effects"),
                    QStringList{QStringLiteral("*.lua")}, QDir::Files,
                    QDirIterator::Subdirectories);
    while (it.hasNext()) {
        it.next();
        const QString rel = QDir(m_root).relativeFilePath(it.filePath());
        out << QStringLiteral("path .. \"/%1\"").arg(rel);
    }
    out.sort(Qt::CaseInsensitive);
    return out;
}

QStringList ModProject::technologyChoices() const
{
    QStringList out;
    // Devices and weapons can both be named as a Prerequisite / Tech, so scan
    // both folders. SaveName lives in device_list.lua / weapon_list.lua as well
    // as in every individual object file.
    const QStringList folders{QStringLiteral("/devices"), QStringLiteral("/weapons")};
    const QRegularExpression re(
        QStringLiteral(R"re(SaveName\s*=\s*"([^"]*)")re"));
    for (const QString &folder : folders) {
        QDirIterator it(m_root + folder, QStringList{QStringLiteral("*.lua")}, QDir::Files,
                        QDirIterator::Subdirectories);
        while (it.hasNext()) {
            const QString text = readAll(it.next());
            auto it2 = re.globalMatch(text);
            while (it2.hasNext()) {
                const QString name = it2.next().captured(1);
                // Quoted, because that is how the value is written into the
                // file (`Prerequisite = "workshop"`).
                const QString q = QStringLiteral("\"%1\"").arg(name);
                if (!name.isEmpty() && !out.contains(q))
                    out << q;
            }
        }
    }
    out.sort(Qt::CaseInsensitive);
    return out;
}

bool ModProject::overridesBaseFile(const QString &relPath) const
{
    if (m_gameData.isEmpty())
        return false;
    return QFileInfo::exists(m_gameData + QLatin1Char('/') + relPath);
}

QString ModProject::iconKindFor(const QString &relPath)
{
    const QString ext = QFileInfo(relPath).suffix().toLower();
    if (ext == QLatin1String("lua"))
        return QStringLiteral("lua");
    if (ext == QLatin1String("png") || ext == QLatin1String("jpg") || ext == QLatin1String("jpeg"))
        return QStringLiteral("image");
    return QStringLiteral("file");
}
