#include "MainWindow.h"
#include "widgets/WheelSafeComboBox.h"
#include "Theme.h"

#include <QApplication>
#include <QStringList>
#include <QComboBox>
#include <QTextStream>
#include <QWheelEvent>
#include <QTimer>

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    app.setApplicationName(QStringLiteral("Forts Mod Studio"));
    app.setApplicationVersion(QStringLiteral("0.3.0"));
    app.setOrganizationName(QStringLiteral("FortsModStudio"));

    Theme::apply(app);

    MainWindow window;
    window.resize(1440, 960);

    // `--mod <path>` opens a specific mod folder (handy for shortcuts and tests).
    // `--forts <path>` presets the Forts install folder.
    // `--size WxH` sets the window size (useful for tall screenshots).
    const QStringList args = app.arguments();

    const int sizeIdx = args.indexOf(QStringLiteral("--size"));
    if (sizeIdx >= 0 && sizeIdx + 1 < args.size()) {
        const QStringList wh = args.at(sizeIdx + 1).split(QLatin1Char('x'));
        if (wh.size() == 2)
            window.resize(wh.at(0).toInt(), wh.at(1).toInt());
    }

    const int fortsIdx = args.indexOf(QStringLiteral("--forts"));
    if (fortsIdx >= 0 && fortsIdx + 1 < args.size()) {
        QString error;
        if (!window.setFortsPath(args.at(fortsIdx + 1), &error))
            qWarning("--forts: %s", qPrintable(error));
    }

    const int modIdx = args.indexOf(QStringLiteral("--mod"));
    if (modIdx >= 0 && modIdx + 1 < args.size())
        window.openMod(args.at(modIdx + 1));

    // `--rename <relPath>|<newName>` renames inside the mod and exits.
    const int rnIdx = args.indexOf(QStringLiteral("--rename"));
    if (rnIdx >= 0 && rnIdx + 1 < args.size()) {
        const QString spec = args.at(rnIdx + 1);
        const int bar = spec.indexOf(QLatin1Char('|'));
        if (bar <= 0) {
            QTextStream(stderr) << "FAIL: --rename expects relPath|newName\n";
            return 1;
        }
        QString error;
        const bool ok = window.renamePath(spec.left(bar), spec.mid(bar + 1), &error);
        QTextStream ts(ok ? stdout : stderr);
        ts << (ok ? "OK" : "FAIL: " + error) << "\n";
        ts.flush();
        return ok ? 0 : 1;
    }

    // `--new-device <name>` creates a device from the template and exits.
    const int ndIdx = args.indexOf(QStringLiteral("--new-device"));
    if (ndIdx >= 0 && ndIdx + 1 < args.size()) {
        QString error;
        const bool ok = window.createDevice(args.at(ndIdx + 1), &error);
        QTextStream ts(ok ? stdout : stderr);
        ts << (ok ? "OK: " : "FAIL: ") << error << "\n";
        ts.flush();
        return ok ? 0 : 1;
    }

    // `--new-mod <dir>` creates a new mod from the template and exits.
    const int nmIdx = args.indexOf(QStringLiteral("--new-mod"));
    if (nmIdx >= 0 && nmIdx + 1 < args.size()) {
        QString error;
        const QString created = window.createNewMod(args.at(nmIdx + 1), &error);
        QTextStream ts(created.isEmpty() ? stderr : stdout);
        ts << (created.isEmpty() ? "FAIL: " : "OK: ") << (created.isEmpty() ? error : created)
           << "\n";
        ts.flush();
        return created.isEmpty() ? 1 : 0;
    }

    // `--new-weapon <name>` creates a weapon from the template (same as the
    // tree's right-click action) and exits.
    const int newIdx = args.indexOf(QStringLiteral("--new-weapon"));
    if (newIdx >= 0 && newIdx + 1 < args.size()) {
        QString error;
        const bool ok = window.createWeapon(args.at(newIdx + 1), &error);
        QTextStream ts(ok ? stdout : stderr);
        ts << (ok ? "OK: " : "FAIL: ") << error << "\n";
        ts.flush();
        return ok ? 0 : 1;
    }

    // `--test-wheel` checks that scrolling over a pick-list does not change its
    // value (plain QComboBox does change it - that is the control).
    if (args.contains(QStringLiteral("--test-wheel"))) {
        const auto wheelOver = [](QComboBox *c) {
            c->setCurrentIndex(1);
            const QPointF local(5, 5);
            QWheelEvent ev(local, c->mapToGlobal(local.toPoint()), QPoint(0, 0), QPoint(0, -120),
                           Qt::NoButton, Qt::NoModifier, Qt::NoScrollPhase, false);
            QApplication::sendEvent(c, &ev);
            return c->currentIndex();
        };

        auto *plain = new QComboBox();
        plain->addItems({QStringLiteral("one"), QStringLiteral("two"), QStringLiteral("three")});
        auto *safe = new WheelSafeComboBox();
        safe->addItems({QStringLiteral("one"), QStringLiteral("two"), QStringLiteral("three")});

        const int plainIndex = wheelOver(plain);
        const int safeIndex = wheelOver(safe);

        QTextStream ts(stdout);
        ts << "обычный QComboBox   : индекс " << plainIndex
           << (plainIndex == 1 ? " (не поменялось)" : " (ЗНАЧЕНИЕ ПОМЕНЯЛОСЬ)") << "\n";
        ts << "безопасный список   : индекс " << safeIndex
           << (safeIndex == 1 ? " (значение сохранилось)" : " (поменялось!)") << "\n";
        ts.flush();
        return safeIndex == 1 ? 0 : 1;
    }

    // `--dump-tech` prints the values offered by the Prerequisite / Tech
    // pick-lists (the mod's own SaveNames + the base game's), then exits.
    if (args.contains(QStringLiteral("--dump-tech"))) {
        const QStringList own = window.technologyChoices();
        const QStringList base = window.gameTechnologies();
        QTextStream ts(stdout);
        ts << "мод (" << own.size() << "): " << own.join(QStringLiteral(", ")) << "\n";
        ts << "игра (" << base.size() << "): " << base.join(QStringLiteral(", ")) << "\n";
        ts.flush();
        return 0;
    }

    // `--file <relPath>` opens a specific file of the mod.
    const int fileIdx = args.indexOf(QStringLiteral("--file"));
    if (fileIdx >= 0 && fileIdx + 1 < args.size())
        window.selectFile(args.at(fileIdx + 1));

    // `--set-table <name>|on|off` adds or deletes an optional block such as
    // ReloadBank in the shown file and exits (used to test the group switch).
    const int stIdx = args.indexOf(QStringLiteral("--set-table"));
    if (stIdx >= 0 && stIdx + 1 < args.size()) {
        const QString spec = args.at(stIdx + 1);
        const int bar = spec.indexOf(QLatin1Char('|'));
        const QString name = bar > 0 ? spec.left(bar) : spec;
        const bool on = bar <= 0 || spec.mid(bar + 1).compare(QLatin1String("on"),
                                                              Qt::CaseInsensitive) == 0;
        const bool okTable = window.setTableEnabled(name, on);
        QTextStream ts(okTable ? stdout : stderr);
        ts << (okTable ? "OK: " : "FAIL: ") << (on ? "added " : "removed ") << name << "\n";
        ts.flush();
        return okTable ? 0 : 1;
    }

    // `--remove-param <path>` deletes a parameter from the shown file. Combine
    // with `--screenshot` to look at the result.
    const int rpIdx = args.indexOf(QStringLiteral("--remove-param"));
    if (rpIdx >= 0 && rpIdx + 1 < args.size()) {
        const bool ok = window.removeParameter(args.at(rpIdx + 1));
        QTextStream ts(ok ? stdout : stderr);
        ts << (ok ? "OK: removed " : "FAIL: cannot remove ") << args.at(rpIdx + 1) << "\n";
        ts.flush();
        if (!args.contains(QStringLiteral("--screenshot")))
            return ok ? 0 : 1;
    }

    window.show();

    // Headless render mode: `FortsModStudio --screenshot <file.png>` draws the
    // window once and exits - handy for CI and design comparison.
    const int idx = args.indexOf(QStringLiteral("--screenshot"));
    if (idx >= 0 && idx + 1 < args.size()) {
        const QString out = args.at(idx + 1);
        QTimer::singleShot(900, &app, [&window, out] {
            window.grab().save(out);
            QApplication::quit();
        });
    }

    return app.exec();
}
