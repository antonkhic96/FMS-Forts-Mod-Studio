@echo off
REM Запуск Forts Mod Studio.
REM Qt-библиотеки уже разложены рядом с .exe (windeployqt), ничего настраивать не нужно.

set EXE=%~dp0build\FortsModStudio.exe
if not exist "%EXE%" (
    echo Не найден "%EXE%"
    echo Сначала соберите проект: build.bat
    pause
    exit /b 1
)

start "" "%EXE%"
