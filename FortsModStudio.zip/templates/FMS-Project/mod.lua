-- FMS-Project — мод для Forts, созданный в Forts Mod Studio.
--
-- Этот файл игра читает при загрузке мода:
--   Selectable  — мод появляется в списке модов игры;
--   Priority    — при конфликте файлов побеждает мод с большим числом;
--   Category    — раздел, в котором мод показан в списке.

Selectable = true
Priority = 10
Category = "Misc"
