-- Скрипт мода FMS-Project.
--
-- Движок вызывает эти функции, если они определены. Файл подключается один раз
-- при загрузке мода, отдельно от data-файлов (weapons/, devices/, materials/).

dofile("scripts/forts.lua")

-- Вызывается при старте и перезапуске игры.
-- function Load(gameStart)
-- end

-- Вызывается каждый кадр.
-- function Update(frame)
-- end

-- Выстрел: teamId, saveName оружия, id оружия, id снаряда.
-- function OnWeaponFired(teamId, saveName, weaponId, projectileNodeId, projectileNodeIdFrom)
-- end

-- Уничтожение устройства: teamId, deviceId, saveName, nodeA, nodeB, t.
-- function OnDeviceDestroyed(teamId, deviceId, saveName, nodeA, nodeB, t)
-- end
