-- Отображаемое имя мода в списке модов игры.
-- Подставьте свои названия для нужных языков.

DisplayName =
{
    ["English"] = L"FMS-Project",
    ["Russian"] = L"FMS-Project",
}
