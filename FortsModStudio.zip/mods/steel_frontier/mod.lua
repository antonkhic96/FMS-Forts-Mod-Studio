-- Steel Frontier / Стальной рубеж
-- Мод-пак со стальными орудиями для Forts.
-- Файл читает движок при загрузке мода: Selectable, Priority, Category.

mod = {
    Name = "Steel Frontier",
    Version = "0.3.0",
    Author = "Forts Mod Studio",
    Priority = 100,
    Category = "Weapons",
    Selectable = true,
    RequiresHighSeas = false,
    RequiresMoonshot = false,
}
