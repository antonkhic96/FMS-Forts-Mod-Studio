-- Локализованное имя мода, которое видит игрок в списке модов.
DisplayName = {
    ["English"] = L"Steel Frontier",
    ["Russian"] = L"Стальной рубеж",
}
