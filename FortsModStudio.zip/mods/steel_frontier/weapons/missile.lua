-- Стальной рубеж: ракетная установка
-- Залп по площади.

weapon = {
    Name = "Missile",

    Explosion = {
        Damage = 200,
        DamageRadius = 4.0,
        Incendiary = 0.6,
        IncendiaryRadius = 2.4,
    },

    Overheat = {
        Enabled = true,
        CooldownTime = 14.0,
        FullCooldownTime = 60.0,
    },
}
