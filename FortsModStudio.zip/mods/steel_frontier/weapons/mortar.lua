-- Стальной рубеж: миномёт
-- Навесной огонь по укреплениям.

weapon = {
    Name = "Mortar",

    Explosion = {
        Damage = 160,
        DamageRadius = 3.2,
        Incendiary = 0.4,
        IncendiaryRadius = 1.6,
    },

    Overheat = {
        Enabled = true,
        CooldownTime = 10.0,
        FullCooldownTime = 45.0,
    },
}
