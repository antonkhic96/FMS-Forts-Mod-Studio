-- Стальной рубеж: дробовик
-- Ближний бой, широкий разброс.

weapon = {
    Name = "Shotgun",

    Explosion = {
        Damage = 60,
        DamageRadius = 1.8,
        Incendiary = 0.0,
        IncendiaryRadius = 0.0,
    },

    Overheat = {
        Enabled = false,
        CooldownTime = 2.0,
        FullCooldownTime = 8.0,
    },
}
