-- Стальной рубеж: пушка
-- Тяжёлая артиллерия. Заменяет стандартную пушку Forts.

weapon = {
    Name = "Cannon",

    Explosion = {
        Damage = 240,
        DamageRadius = 2.5,
        Incendiary = 0.2,
        IncendiaryRadius = 1.0,
    },

    Overheat = {
        Enabled = true,
        CooldownTime = 8.0,
        FullCooldownTime = 40.0,
    },
}
