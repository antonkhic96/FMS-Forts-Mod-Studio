-- Стальной рубеж: пулемёт
-- Быстрое оружие подавления.

weapon = {
    Name = "Machinegun",

    Explosion = {
        Damage = 12,
        DamageRadius = 0.6,
        Incendiary = 0.0,
        IncendiaryRadius = 0.0,
    },

    Overheat = {
        Enabled = true,
        CooldownTime = 3.0,
        FullCooldownTime = 12.0,
    },
}
