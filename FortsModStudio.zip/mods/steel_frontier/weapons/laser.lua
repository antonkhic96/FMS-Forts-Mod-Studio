-- Стальной рубеж: лазер
-- Режет броню, не оставляет огня.

weapon = {
    Name = "Laser",

    Explosion = {
        Damage = 70,
        DamageRadius = 0.3,
        Incendiary = 0.0,
        IncendiaryRadius = 0.0,
    },

    Overheat = {
        Enabled = true,
        CooldownTime = 6.0,
        FullCooldownTime = 22.0,
    },
}
