-- Стальной рубеж: снайперская винтовка
-- Точный выстрел на большую дистанцию.

weapon = {
    Name = "Sniper",

    Explosion = {
        Damage = 90,
        DamageRadius = 0.4,
        Incendiary = 0.0,
        IncendiaryRadius = 0.0,
    },

    Overheat = {
        Enabled = true,
        CooldownTime = 5.0,
        FullCooldownTime = 18.0,
    },
}
