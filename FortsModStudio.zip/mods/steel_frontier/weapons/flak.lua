-- Стальной рубеж: зенитка
-- Заградительный огонь по воздуху.

weapon = {
    Name = "Flak",

    Explosion = {
        Damage = 45,
        DamageRadius = 1.4,
        Incendiary = 0.1,
        IncendiaryRadius = 0.8,
    },

    Overheat = {
        Enabled = false,
        CooldownTime = 4.0,
        FullCooldownTime = 16.0,
    },
}
