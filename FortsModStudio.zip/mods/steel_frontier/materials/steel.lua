-- Стальной рубеж: сталь
-- Материал брони.

material = {
    Name = "Steel",

    Armor = 0.85,
    ReflectionMomentumThreshold = 120.0,
    PenetrationMomentumThreshold = 340.0,
}
