-- Стальной рубеж: бетон
-- Дешёвый, но хрупкий материал.

material = {
    Name = "Concrete",

    Armor = 0.55,
    ReflectionMomentumThreshold = 80.0,
    PenetrationMomentumThreshold = 200.0,
}
