-- Стальной рубеж: дерево
-- Лёгкие конструкции, легко горит.

material = {
    Name = "Wood",

    Armor = 0.25,
    ReflectionMomentumThreshold = 30.0,
    PenetrationMomentumThreshold = 90.0,
}
