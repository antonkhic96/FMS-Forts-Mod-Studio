-- Строки интерфейса мода.

strings = {
    ModName = "Steel Frontier",
    CategoryWeapons = "Steel Weapons",
    CategoryDevices = "Support Devices",
}
