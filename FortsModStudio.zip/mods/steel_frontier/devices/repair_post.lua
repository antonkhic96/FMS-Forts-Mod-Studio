-- Стальной рубеж: ремонтный пост
-- Восстанавливает прочность ближайших построек.

device = {
    Name = "RepairPost",

    Health = 350,
    Cost = 300,
    RepairRate = 18.0,
    RepairRadius = 8.0,
}
