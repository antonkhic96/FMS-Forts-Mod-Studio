-- Стальной рубеж: генератор щита
-- Устройство поддержки.

device = {
    Name = "ShieldGenerator",

    Health = 600,
    Cost = 450,
    RechargeTime = 12.0,
    ShieldRadius = 6.0,
}
