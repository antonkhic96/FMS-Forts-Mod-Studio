-- Стальной рубеж: бункер
-- Усиленное укрытие для пехоты.

device = {
    Name = "Bunker",

    Health = 900,
    Cost = 380,
    Armor = 0.45,
    Capacity = 6,
}
