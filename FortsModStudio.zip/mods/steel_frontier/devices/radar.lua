-- Стальной рубеж: радар
-- Раскрывает туман войны в радиусе действия.

device = {
    Name = "Radar",

    Health = 250,
    Cost = 200,
    ScanRadius = 22.0,
    ScanInterval = 1.5,
}
