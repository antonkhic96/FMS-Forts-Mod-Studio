// Headless smoke test for the data layer (Lua parsing + mod project + saving).
//
//   fms_selftest <mod-folder>   parses the mod and tests an edit/save round-trip
//   fms_selftest <file.lua>     dumps every property found in one file
//
// Build target: fms_selftest.

#include "../src/GameCatalog.h"
#include "../src/LuaFile.h"
#include "../src/ModModel.h"
#include "../src/ParamCatalog.h"

#include <QCoreApplication>
#include <QDir>
#include <QFileInfo>
#include <QRegularExpression>
#include <QTextStream>

static QTextStream out(stdout);

static int fail(const QString &msg)
{
    out << "FAIL: " << msg << "\n";
    out.flush();
    return 1;
}

static int dumpFile(const QString &path)
{
    LuaFile f;
    if (!f.load(path))
        return fail(QStringLiteral("cannot load %1").arg(path));

    out << "file      : " << path << "\n";
    out << "script    : " << (f.looksLikeScript() ? "yes" : "no") << "\n";
    out << "properties: " << f.properties().size() << "\n";

    int withHint = 0;
    for (const LuaProp &p : f.properties()) {
        if (!ParamCatalog::hint(p.key).isEmpty())
            ++withHint;
    }
    out << "help text : " << withHint << " / " << f.properties().size()
        << " parameters have a description\n";

    if (!f.textures().isEmpty()) {
        out << "textures  : " << f.textures().size() << "\n";
        for (const TextureRef &t : f.textures())
            out << QStringLiteral("  %1 | %2 | line %3 | %4\n")
                       .arg(LuaFile::textureRole(t).isEmpty() ? QStringLiteral("?")
                                                              : LuaFile::textureRole(t),
                            -8)
                       .arg(t.sprite, -22)
                       .arg(t.line)
                       .arg(t.value);
    }
    out << "\n";

    // Same component/kind logic the UI uses, so the dump reflects the panel.
    QString component;
    {
        static const QRegularExpression arrRe(
            QStringLiteral(R"(([A-Za-z_][A-Za-z0-9_]*)\[\d+\]$)"));
        for (const LuaProp &p : f.properties()) {
            const QRegularExpressionMatch m = arrRe.match(p.table);
            if (m.hasMatch()) {
                component = p.table;
                break;
            }
        }
    }
    const ParamCatalog::Kind kind = ParamCatalog::kindFor(path, component.section(QLatin1Char('['), 0, 0));

    for (const LuaProp &p : f.properties()) {
        if (p.table.startsWith(QLatin1Char('@')) || p.table.startsWith(QLatin1Char('[')))
            continue;
        if (p.table.isEmpty()) {
            if (!ParamCatalog::isConstantName(p.key))
                continue;   // constants stay visible, other top-level noise does not
        } else if (!component.isEmpty() && p.table != component
                   && !p.table.startsWith(component + QLatin1Char('.'))) {
            continue;
        }

        QString table = p.table;
        if (!component.isEmpty() && table.startsWith(component)) {
            table = table.mid(component.size());
            if (table.startsWith(QLatin1Char('.')))
                table = table.mid(1);
        }

        const QString group = table.isEmpty()
                                  ? ParamCatalog::categoryTitle(
                                        ParamCatalog::categoryFor(kind, p.key))
                                  : ParamCatalog::tableTitle(table.section(QLatin1Char('.'), -1));
        const QStringList choices = GameCatalog::instance().choicesFor(p.key);
        out << QStringLiteral("  %1 | %2 | %3 = %4%5\n")
                   .arg(group, -20)
                   .arg(ParamCatalog::label(p.key), -32)
                   .arg(p.path, -34)
                   .arg(p.value.left(30))
                   .arg(choices.isEmpty()
                            ? QString()
                            : QStringLiteral("   [выбор из %1]").arg(choices.size()));
    }

    // Settings the component could have but the file does not define yet.
    const QString folder = QFileInfo(path).dir().dirName();
    const QVector<ParamCatalog::TemplateParam> &tmpl = ParamCatalog::templateFor(folder);
    if (!tmpl.isEmpty()) {
        int missing = 0;
        int described = 0;
        QStringList lines;
        for (const ParamCatalog::TemplateParam &t : tmpl) {
            if (!ParamCatalog::hint(t.key).isEmpty())
                ++described;
            bool present = false;
            for (const LuaProp &p : f.properties()) {
                if (p.path == t.key) {
                    present = true;
                    break;
                }
            }
            if (present)
                continue;
            ++missing;
            lines << QStringLiteral("  %1 | %2 (%3)\n")
                         .arg(ParamCatalog::categoryTitle(ParamCatalog::categoryOf(t.key)), -20)
                         .arg(ParamCatalog::label(t.key), -32)
                         .arg(t.key);
        }
        out << "\nmissing (offered from the " << folder << " template): " << missing << "\n";
        out << "described: " << described << " / " << tmpl.size()
            << " template parameters have a help text\n";
        for (const QString &l : lines)
            out << l;
    }
    out.flush();
    return 0;
}

int main(int argc, char *argv[])
{
    QCoreApplication app(argc, argv);

    // The game data path lets the pick-lists be filled in.
    const int dataIdx = app.arguments().indexOf(QStringLiteral("--data"));
    if (dataIdx >= 0 && dataIdx + 1 < app.arguments().size())
        GameCatalog::instance().setDataPath(app.arguments().at(dataIdx + 1));

    QString target = argc > 1 ? QString::fromLocal8Bit(argv[1]) : QString();
    if (target.isEmpty())
        target = QDir(QCoreApplication::applicationDirPath()).absoluteFilePath("../mods/steel_frontier");

    if (target.endsWith(QLatin1String(".lua"), Qt::CaseInsensitive)) {
        // Optional: `--add Key=value` appends a setting the file lacks.
        const int addIdx = app.arguments().indexOf(QStringLiteral("--add"));
        if (addIdx >= 0 && addIdx + 1 < app.arguments().size()) {
            const QString spec = app.arguments().at(addIdx + 1);
            const int eq = spec.indexOf(QLatin1Char('='));
            if (eq <= 0)
                return fail(QStringLiteral("--add expects Key=value"));
            const QString key = spec.left(eq);
            const QString value = spec.mid(eq + 1);

            const int intoIdx = app.arguments().indexOf(QStringLiteral("--into"));
            const QString table = (intoIdx >= 0 && intoIdx + 1 < app.arguments().size())
                                      ? app.arguments().at(intoIdx + 1)
                                      : QString();

            LuaFile w;
            if (!w.load(target))
                return fail(QStringLiteral("cannot load %1").arg(target));
            if (!w.addProperty(key, value, table))
                return fail(QStringLiteral("addProperty refused %1").arg(key));
            if (!w.save())
                return fail(QStringLiteral("save failed"));

            LuaFile check;
            check.load(target);
            const QString full = table.isEmpty() ? key : table + QLatin1Char('.') + key;
            const QString got = check.value(full);
            out << "added       : " << full << " = " << got << "\n";
            if (got != value)
                return fail(QStringLiteral("added value not persisted"));
        }
        // Optional: `--remove <path>` deletes a parameter and saves.
        const int rmIdx = app.arguments().indexOf(QStringLiteral("--remove"));
        if (rmIdx >= 0 && rmIdx + 1 < app.arguments().size()) {
            const QString prop = app.arguments().at(rmIdx + 1);
            LuaFile w;
            if (!w.load(target))
                return fail(QStringLiteral("cannot load %1").arg(target));
            if (!w.value(prop).isEmpty())
                out << "before      : " << prop << " = " << w.value(prop) << QLatin1Char(10);
            if (!w.removeProperty(prop))
                return fail(QStringLiteral("removeProperty refused %1").arg(prop));
            if (!w.save())
                return fail(QStringLiteral("save failed"));

            LuaFile check;
            check.load(target);
            out << "removed     : " << prop << " (now '" << check.value(prop)
                << "', " << check.properties().size() << " params left)" << QLatin1Char(10);
            if (!check.value(prop).isEmpty())
                return fail(QStringLiteral("property still present"));
        }

        // Optional: `--add-component <Array>` appends a new entry to an array.
        const int acIdx = app.arguments().indexOf(QStringLiteral("--add-component"));
        if (acIdx >= 0 && acIdx + 1 < app.arguments().size()) {
            const QString array = app.arguments().at(acIdx + 1);
            LuaFile w;
            if (!w.load(target))
                return fail(QStringLiteral("cannot load %1").arg(target));

            QVector<QPair<QString, QString>> props;
            props.append(qMakePair(QStringLiteral("SaveName"), QStringLiteral("\"new_proj\"")));
            const QVector<ParamCatalog::TemplateParam> &tmpl =
                ParamCatalog::templateForFile(target, array);
            for (const ParamCatalog::TemplateParam &t : tmpl)
                props.append(qMakePair(t.key, t.value));

            const QString created = w.addComponent(array, props);
            if (created.isEmpty())
                return fail(QStringLiteral("addComponent failed"));
            if (!w.save())
                return fail(QStringLiteral("save failed"));

            LuaFile check;
            check.load(target);
            const QString name = check.value(created + QStringLiteral(".SaveName"));
            out << "component   : " << created << " (SaveName=" << name << ", "
                << props.size() << " props)\n";
            if (name != QLatin1String("new_proj"))
                return fail(QStringLiteral("new component not persisted"));
        }
        return dumpFile(target);
    }

    ModProject project;
    if (!project.open(target))
        return fail(QStringLiteral("cannot open mod: %1").arg(target));

    out << "mod name    : " << project.name() << "\n";
    out << "mod version : " << project.version() << "\n";

    LuaFile &f = project.file(QStringLiteral("weapons/cannon.lua"));
    const int params = f.properties().size();
    out << "properties  : " << params << "\n";
    for (const LuaProp &p : f.properties())
        out << QStringLiteral("  [%1] %2 = %3\n")
                   .arg(p.table.isEmpty() ? QStringLiteral("-") : p.table, -10)
                   .arg(ParamCatalog::label(p.key), -24)
                   .arg(p.value);

    if (params == 0)
        return fail(QStringLiteral("parser found no parameters"));

    // Round-trip the first plain numeric property we can find.
    QString path;
    QString before;
    for (const LuaProp &p : f.properties()) {
        if (p.kind == LuaKind::Number && !p.value.startsWith(QLatin1Char('-'))) {
            path = p.path;
            before = p.value;
            break;
        }
    }
    if (path.isEmpty())
        return fail(QStringLiteral("no numeric property to test"));

    // Undo / redo must restore the previous value exactly.
    {
        const QString original = f.value(path);
        if (!f.setValue(path, QStringLiteral("4242")))
            return fail(QStringLiteral("setValue failed"));
        const QString edited = f.value(path);
        if (!f.undo() || f.value(path) != original)
            return fail(QStringLiteral("undo did not restore %1").arg(original));
        if (!f.redo() || f.value(path) != edited)
            return fail(QStringLiteral("redo did not restore %1").arg(edited));
        f.undo();   // back to the original before the rest of the test
        out << "undo/redo   : " << original << " -> " << edited << " -> " << f.value(path)
            << QStringLiteral(" (OK)") << QLatin1Char(10);
    }

    if (!f.setValue(path, QStringLiteral("999")))
        return fail(QStringLiteral("setValue failed"));
    project.markDirty(QStringLiteral("weapons/cannon.lua"));
    if (project.dirtyCount() != 1)
        return fail(QStringLiteral("dirty counter not updated"));

    QStringList errors;
    if (!project.saveAll(&errors))
        return fail(QStringLiteral("saveAll failed: %1").arg(errors.join(QLatin1Char(','))));
    if (project.dirtyCount() != 0)
        return fail(QStringLiteral("dirty counter not cleared after save"));

    LuaFile reread;
    if (!reread.load(project.rootPath() + QStringLiteral("/weapons/cannon.lua")))
        return fail(QStringLiteral("reload failed"));
    const QString after = reread.value(path);
    out << "round-trip  : " << path << " " << before << " -> " << after << "\n";
    if (after != QLatin1String("999"))
        return fail(QStringLiteral("saved value not persisted"));

    // Restore so the file stays pristine.
    LuaFile &again = project.file(QStringLiteral("weapons/cannon.lua"));
    again.setValue(path, before);
    project.markDirty(QStringLiteral("weapons/cannon.lua"));
    project.saveAll();

    LuaFile finalCheck;
    finalCheck.load(project.rootPath() + QStringLiteral("/weapons/cannon.lua"));
    if (finalCheck.value(path) != before)
        return fail(QStringLiteral("file not restored to its original value"));

    out << "self-test   : OK (" << params << " parameters parsed)\n";
    out.flush();
    return 0;
}
